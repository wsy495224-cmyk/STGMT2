import time,math,json,os
class Movement:
 def __init__(self,db):
  self.db=db;self.last={}
  with open(os.path.join(os.path.dirname(__file__),"maps_v21.json"),encoding="utf-8") as f:self.maps={m["name"]:m for m in json.load(f)}
 def validate(self,cid,x,y,z):
  c=self.db.character(cid)
  if not c:return None
  now=time.monotonic();prev=self.last.get(cid,(now,c["x"],c["y"],c["z"]))
  dt=max(.035,min(1.0,now-prev[0]));max_speed=12.0 # includes mount tolerance
  dist=math.hypot(x-prev[1],z-prev[3])
  if dist>max_speed*dt+1.5:return None
  m=self.maps.get(c["map_name"])
  if m:
   xmin,xmax,zmin,zmax=m["bounds"];x=max(xmin,min(xmax,x));z=max(zmin,min(zmax,z))
  y=max(-20,min(100,y));self.last[cid]=(now,x,y,z);return x,y,z
 def clear(self,cid):self.last.pop(cid,None)
