import time, random, math
SKILLS={
"Blade":[
 {"id":"quick_slash","mana":12,"cd":2.0,"mult":1.25,"range":4.0},
 {"id":"heavy_cut","mana":20,"cd":4.0,"mult":1.75,"range":4.0,"status":{"bleed":4.0}},
 {"id":"twin_edge","mana":24,"cd":5.0,"mult":1.95,"range":4.2},
 {"id":"whirlwind","mana":30,"cd":7.0,"mult":2.2,"range":5.0},
 {"id":"earth_break","mana":38,"cd":10.0,"mult":2.65,"range":5.5,"status":{"stun":1.2}},
 {"id":"dragon_pulse","mana":52,"cd":16.0,"mult":3.4,"range":6.0}],
"Archer":[
 {"id":"arrow_burst","mana":13,"cd":2.0,"mult":1.2,"range":14.0},
 {"id":"piercing_shot","mana":22,"cd":4.0,"mult":1.7,"range":16.0},
 {"id":"wind_volley","mana":27,"cd":6.0,"mult":2.0,"range":14.0,"status":{"slow":3.0}},
 {"id":"hawk_eye","mana":32,"cd":8.0,"mult":2.35,"range":16.0},
 {"id":"rain_of_arrows","mana":42,"cd":11.0,"mult":2.7,"range":15.0},
 {"id":"sky_breaker","mana":58,"cd":17.0,"mult":3.5,"range":18.0}],
"Mystic":[
 {"id":"spark","mana":14,"cd":2.0,"mult":1.3,"range":10.0},
 {"id":"frost_orb","mana":23,"cd":4.0,"mult":1.75,"range":11.0,"status":{"slow":4.0}},
 {"id":"arc_wave","mana":28,"cd":6.0,"mult":2.05,"range":10.0},
 {"id":"stone_pulse","mana":34,"cd":8.0,"mult":2.3,"range":10.0,"status":{"stun":1.0}},
 {"id":"void_ring","mana":40,"cd":11.0,"mult":2.75,"range":9.0},
 {"id":"astral_burst","mana":62,"cd":18.0,"mult":3.65,"range":12.0}]
}
BASE={"Blade":{"hp":420,"mp":170,"atk":42,"def":12,"crit":.08,"dodge":.04},
      "Archer":{"hp":320,"mp":250,"atk":36,"def":7,"crit":.12,"dodge":.08},
      "Mystic":{"hp":285,"mp":350,"atk":33,"def":6,"crit":.09,"dodge":.05}}
RECIPES={
"greater_hp":{"ingredients":{"HP Potion":3,"Crystal Shard":1},"result":{"Greater HP Potion":1}},
"upgrade_stone":{"ingredients":{"Crystal Shard":3,"Gem Fragment":2},"result":{"Upgrade Stone":1}},
"rare_gem":{"ingredients":{"Gem Fragment":8,"Crystal Shard":2},"result":{"Rare Gem":1}}
}
QUESTS={
"first_hunt":{"kind":"kill","goal":5,"target":"normal","gold":150,"xp":100},
"boss_trial":{"kind":"kill","goal":1,"target":"boss","gold":550,"xp":400},
"crystal_collector":{"kind":"collect","goal":5,"target":"Crystal Shard","gold":250,"xp":180}
}
class Runtime:
 def __init__(self):
  self.players={} # cid -> runtime
 def enter(self,c):
  b=BASE[c["class_name"]]
  self.players[c["id"]]={"hp":b["hp"],"max_hp":b["hp"],"mp":b["mp"],"max_mp":b["mp"],
    "cooldowns":{},"statuses":{},"last_regen":time.monotonic()}
  return self.players[c["id"]]
 def get(self,cid):return self.players.get(cid)
 def leave(self,cid):self.players.pop(cid,None)
 def regen(self,cid):
  r=self.get(cid)
  if not r:return
  now=time.monotonic();dt=max(0,now-r["last_regen"]);r["last_regen"]=now
  r["mp"]=min(r["max_mp"],r["mp"]+dt*2.5);r["hp"]=min(r["max_hp"],r["hp"]+dt*.8)
 def skill(self,db,world,cid,mob_id,index):
  c=db.character(cid);r=self.get(cid)
  if not c or not r:return {"ok":False,"error":"not in world"}
  skills=SKILLS[c["class_name"]]
  if index<0 or index>=len(skills):return {"ok":False,"error":"invalid skill"}
  s=skills[index];now=time.monotonic();self.regen(cid)
  if now<r["cooldowns"].get(s["id"],0):return {"ok":False,"error":"cooldown","remaining":r["cooldowns"][s["id"]]-now}
  if r["mp"]<s["mana"]:return {"ok":False,"error":"mana"}
  mob=world.mobs.get(mob_id)
  if not mob or not mob["alive"]:return {"ok":False,"error":"target"}
  if mob.get("map_name",c.get("map_name"))!=c.get("map_name"):return {"ok":False,"error":"wrong map"}
  if math.hypot(c["x"]-mob["x"],c["z"]-mob["z"])>s["range"]:return {"ok":False,"error":"range"}
  r["mp"]-=s["mana"];r["cooldowns"][s["id"]]=now+s["cd"]
  b=BASE[c["class_name"]];crit=random.random()<b["crit"]
  dmg=int((b["atk"]+c["level"]*4)*s["mult"]*(1.65 if crit else 1.0))
  mob["hp"]=max(0,mob["hp"]-dmg);dead=mob["hp"]<=0
  out={"ok":True,"skill":s["id"],"damage":dmg,"critical":crit,"mp":int(r["mp"]),"hp":mob["hp"],"dead":dead,"mob_id":mob_id}
  if s.get("status") and not dead:
   mob.setdefault("statuses",{}).update({k:now+float(v) for k,v in s["status"].items()});out["status"]=s["status"]
  if dead:
   mob["alive"]=False;out["reward"]=db.grant_drop(cid,mob["kind"]);db.quest_event(cid,"kill",mob["kind"],1)
  return out
runtime=Runtime()
