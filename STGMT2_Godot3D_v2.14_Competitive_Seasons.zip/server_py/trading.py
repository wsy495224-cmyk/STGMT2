import time
class Trades:
 def __init__(self,db):
  self.db=db;self.sessions={};self.next_id=1
 def open(self,a,b):
  if a==b:return None
  tid=self.next_id;self.next_id+=1
  self.sessions[tid]={"a":a,"b":b,"offers":{a:{"gold":0,"items":[]},b:{"gold":0,"items":[]}},"accepted":set(),"created":time.monotonic()}
  return tid
 def offer(self,tid,cid,gold,items):
  t=self.sessions.get(tid)
  if not t or cid not in (t["a"],t["b"]) or gold<0:return False
  if self.db.wallet(cid)<gold:return False
  for x in items:
   if self.db._count(cid,str(x["item"]),int(x.get("upgrade",0)))<int(x["count"]):return False
  t["offers"][cid]={"gold":gold,"items":items[:12]};t["accepted"].clear();return True
 def accept(self,tid,cid):
  t=self.sessions.get(tid)
  if not t or cid not in (t["a"],t["b"]):return False
  t["accepted"].add(cid)
  if len(t["accepted"])<2:return True
  a,b=t["a"],t["b"];oa,ob=t["offers"][a],t["offers"][b]
  with self.db.cx:
   if self.db.wallet(a)<oa["gold"] or self.db.wallet(b)<ob["gold"]:return False
   for owner,o in ((a,oa),(b,ob)):
    for x in o["items"]:
     if self.db._count(owner,x["item"],int(x.get("upgrade",0)))<int(x["count"]):return False
   self.db.cx.execute("UPDATE characters SET gold=gold-?+? WHERE id=?",(oa["gold"],ob["gold"],a))
   self.db.cx.execute("UPDATE characters SET gold=gold-?+? WHERE id=?",(ob["gold"],oa["gold"],b))
   for owner,receiver,o in ((a,b,oa),(b,a,ob)):
    for x in o["items"]:
     up=int(x.get("upgrade",0));cnt=int(x["count"]);self.db._take(owner,x["item"],cnt,up);self.db._add(receiver,x["item"],cnt,up)
  del self.sessions[tid];return True
