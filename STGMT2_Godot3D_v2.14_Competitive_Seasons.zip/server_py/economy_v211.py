import random, time
RARITIES={
 'Common':{'weight':60,'mult':1.0},'Medium':{'weight':25,'mult':1.25},'Rare':{'weight':10,'mult':1.65},
 'Legendary':{'weight':4,'mult':2.25},'Mythic':{'weight':0.8,'mult':3.1},'Relic':{'weight':0.2,'mult':4.2}}
BOSS_BONUS={'Legendary':8.0,'Mythic':3.0,'Relic':1.0}
MARKET_TAX_RATE=.03
MARKET_TTL=7*24*3600

def roll_rarity(is_boss=False,rng=None):
 rng=rng or random
 names=list(RARITIES); weights=[]
 for n in names:
  w=RARITIES[n]['weight']
  if is_boss:w+=BOSS_BONUS.get(n,0)
  weights.append(w)
 return rng.choices(names,weights=weights,k=1)[0]

def market_tax(total): return max(1,int(total*MARKET_TAX_RATE)) if total>0 else 0

def expired(created_at,now=None): return int(now or time.time())-int(created_at)>=MARKET_TTL
