import os,tempfile,time
fd,path=tempfile.mkstemp();os.close(fd);os.unlink(path)
import database as d
from world import World
from gameplay import runtime,SKILLS
from world_v21 import populate
db=d.DB(path);a,_=db.register('tester23','password23');cid=db.create_character(a,'Hero23','Blade');c=db.character(cid);runtime.enter(c)
assert all(len(SKILLS[k])==6 for k in ('Blade','Archer','Mystic'))
w=World(db);populate(w)
# Level-up is server-owned.
with db.cx: db.cx.execute('UPDATE characters SET xp=95 WHERE id=?',(cid,))
r=db.grant_drop(cid,'boss');assert db.character(cid)['level']>=2 and r['level_ups']
# Monster aggro/attack/death respawn foundation.
m={'kind':'normal','name':'Test','map_name':'Green Valley','hp':50,'max_hp':50,'x':0.5,'z':0.5,'spawn_x':3.0,'spawn_z':4.0,'alive':True,'statuses':{},'target_id':None,'next_attack':0}
w.mobs={'t':m};events=w.tick(runtime,.2);assert any(e['type']=='mob_attack' for e in events)
m['alive']=False;m['dead_at']=time.monotonic()-20;m['hp']=0;events=w.tick(runtime,.2);assert m['alive'] and m['hp']==50 and m['x']==3.0
print('v2.3 AI/progression/18-skills smoke PASS')
os.unlink(path)
