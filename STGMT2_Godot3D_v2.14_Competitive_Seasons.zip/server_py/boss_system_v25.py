import math,time,random

BOSS_SPECIALS={
 'Green Valley':('Guardian Slam','stun'), 'Red Dunes':('Sandstorm','bleed'),
 'Mist Forest':('Root Burst','slow'), 'Frozen Pass':('Frozen Nova','slow'),
 'Sunset Ruins':('Colossus Quake','stun'), 'Dark Marsh':('Toxic Mire','bleed'),
 'Sky Plateau':('Storm Judgment','burn')}

def phase_for(m):
    ratio=m['hp']/max(1,m['max_hp'])
    return 1 if ratio>.66 else (2 if ratio>.33 else 3)

def boss_special(world,mid,m,runtime,db,now):
    if m.get('kind')!='boss' or now<m.get('next_special',0): return []
    phase=phase_for(m); m['phase']=phase
    name,effect=BOSS_SPECIALS.get(m.get('map_name'),('Boss Nova','burn'))
    radius=5.0+phase*1.5; events=[]; hits=[]
    for cid,r in runtime.players.items():
        c=db.character(cid)
        if not c or c['map_name']!=m.get('map_name') or r.get('hp',0)<=0: continue
        d=math.hypot(c['x']-m['x'],c['z']-m['z'])
        if d<=radius:
            stats=db.server_stats(cid); raw=24+phase*14+int(m['max_hp']/900); dmg=max(1,int(raw-stats.get('def',0)*.25))
            r['hp']=max(0,r['hp']-dmg); dead=r['hp']<=0
            if not dead: r.setdefault('statuses',{})[effect]=now+(1.5+phase*.8)
            hits.append({'id':cid,'damage':dmg,'hp':int(r['hp']),'dead':dead,'effect':effect})
            if dead:
                r['hp']=r['max_hp'];r['mp']=r['max_mp'];db.save_position(cid,0,1,0)
                events.append({'type':'player_respawn','id':cid,'hp':int(r['hp']),'mp':int(r['mp']),'x':0,'y':1,'z':0,'map_name':m.get('map_name')})
    m['next_special']=now+max(4.0,8.5-phase*1.2)
    if hits: events.insert(0,{'type':'boss_special','mob_id':mid,'name':name,'phase':phase,'radius':radius,'hits':hits,'map_name':m.get('map_name')})
    return events
