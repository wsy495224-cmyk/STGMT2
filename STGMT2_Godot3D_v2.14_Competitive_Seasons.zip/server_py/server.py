import asyncio, json, time
from config import HOST,PORT,MAX_MESSAGE,PROTOCOL_VERSION
from database import DB
from world import World
from gameplay import runtime
from trading import Trades
from session_tokens import issue,resume
from pvp import PvP
from movement import Movement
from world_v21 import populate
from world_features_v24 import teleport, leaderboard, DungeonManager, PORTALS
db=DB()
world=World(db);populate(world)
trades=Trades(db)
pvp=PvP(db,runtime)
movement=Movement(db)
dungeons=DungeonManager()
sessions={}      # writer -> session
players={}       # character_id -> writer

async def send(w,obj):
    w.write((json.dumps(obj,separators=(",",":"))+"\n").encode());await w.drain()

async def broadcast(obj,exclude=None):
    for w,s in list(sessions.items()):
        if w is not exclude and s.get("character_id"):
            try: await send(w,obj)
            except Exception: pass


async def broadcast_map(map_name,obj):
    for w,ss in list(sessions.items()):
        cid=ss.get("character_id")
        if cid:
            c=db.character(cid)
            if c and c.get("map_name")==map_name:
                try: await send(w,obj)
                except Exception: pass

async def world_loop():
    while True:
        await asyncio.sleep(0.2)
        for ev in world.tick(runtime,0.2):
            await broadcast_map(ev.get("map_name"),ev)

async def handle(reader,writer):
    sessions[writer]={"account_id":None,"character_id":None,"name":None,"last_move":0.0}
    await send(writer,{"type":"hello","protocol":PROTOCOL_VERSION})
    try:
        while not reader.at_eof():
            raw=await reader.readline()
            if not raw or len(raw)>MAX_MESSAGE:break
            try:m=json.loads(raw)
            except Exception:continue
            s=sessions[writer];t=m.get("type","")
            if t=="register":
                aid,err=db.register(str(m.get("username","")),str(m.get("password","")))
                await send(writer,{"type":"register_result","ok":bool(aid),"error":err or ""})
            elif t=="login":
                a=db.login(str(m.get("username","")),str(m.get("password","")))
                token="";expires=0
                if a:
                    s["account_id"]=a["id"];token,expires=issue(db,a["id"])
                await send(writer,{"type":"login_result","ok":bool(a),"characters":db.characters(a["id"]) if a else [],"session_token":token,"expires_at":expires})
            elif t=="resume":
                aid=resume(db,str(m.get("token","")))
                if aid:s["account_id"]=aid
                await send(writer,{"type":"resume_result","ok":bool(aid),"characters":db.characters(aid) if aid else []})
            elif t=="create_character" and s["account_id"]:
                cid=db.create_character(s["account_id"],str(m.get("name","")),str(m.get("class_name","")))
                await send(writer,{"type":"create_character_result","ok":bool(cid),"characters":db.characters(s["account_id"])})
            elif t=="enter_world" and s["account_id"]:
                cid=int(m.get("character_id",0))
                chars=db.characters(s["account_id"]);c=next((x for x in chars if x["id"]==cid),None)
                if not c:continue
                s["character_id"]=cid;s["name"]=c["name"];players[cid]=writer
                rt=runtime.enter(db.character(cid))
                await send(writer,{"type":"enter_result","ok":True,"character":c,"runtime":rt})
                await broadcast({"type":"player_join","id":cid,"name":c["name"],"class_name":c["class_name"],"x":c["x"],"y":c["y"],"z":c["z"]},writer)
            elif t=="move" and s["character_id"]:
                now=time.monotonic()
                if now-s["last_move"]<0.035:continue
                s["last_move"]=now
                x=float(m.get("x",0));y=float(m.get("y",1));z=float(m.get("z",0))
                pos=movement.validate(s["character_id"],x,y,z)
                if not pos:
                    c=db.character(s["character_id"]);await send(writer,{"type":"position_correction","x":c["x"],"y":c["y"],"z":c["z"]});continue
                x,y,z=pos;db.save_position(s["character_id"],x,y,z)
                await broadcast({"type":"player_move","id":s["character_id"],"x":x,"y":y,"z":z},writer)
            elif t=="whisper" and s["character_id"]:
                target=str(m.get("to",""));msg=str(m.get("message",""))[:300]
                tw=next((w for w,ss in sessions.items() if ss.get("name")==target),None)
                if tw and msg:await send(tw,{"type":"whisper","from":s["name"],"message":msg})
            elif t=="chat" and s["character_id"]:
                msg=str(m.get("message",""))[:300]
                if msg:await broadcast({"type":"chat","from":s["name"],"message":msg})
            elif t=="equip" and s["character_id"]:
                ok=db.equip_item(s["character_id"],str(m.get("item","")),int(m.get("upgrade",0)))
                await send(writer,{"type":"equipment_result","ok":ok,"equipment":db.equipped_rows(s["character_id"]),"stats":db.server_stats(s["character_id"]),"inventory":db.inventory(s["character_id"])})
            elif t=="pvp_attack" and s["character_id"]:
                result=pvp.attack(s["character_id"],int(m.get("target_id",0)))
                await send(writer,{"type":"pvp_result",**result})
                if result.get("ok"):await broadcast({"type":"pvp_state","attacker":s["character_id"],**result},writer)
            elif t=="guild_invite" and s["character_id"]:
                target=str(m.get("target",""));tw=next((w for w,ss in sessions.items() if ss.get("name")==target),None)
                ok=db.guild_invite(s["character_id"],sessions[tw]["character_id"]) if tw else False
                await send(writer,{"type":"guild_result","ok":ok,"guild":db.guild_for(s["character_id"])})
            elif t=="guild_rank" and s["character_id"]:
                ok=db.guild_set_rank(s["character_id"],str(m.get("target","")),str(m.get("rank","Member")))
                await send(writer,{"type":"guild_result","ok":ok,"guild":db.guild_for(s["character_id"])})
            elif t=="guild_withdraw_item" and s["character_id"]:
                ok=db.guild_withdraw_item(s["character_id"],str(m.get("item","")),int(m.get("count",1)),int(m.get("upgrade",0)))
                await send(writer,{"type":"guild_result","ok":ok,"guild":db.guild_for(s["character_id"]),"bank":db.guild_bank_rows(s["character_id"]),"inventory":db.inventory(s["character_id"])})
            elif t=="guild_war_start" and s["character_id"]:
                wid=db.war_start(s["character_id"],str(m.get("enemy_guild","")))
                await send(writer,{"type":"guild_war_result","ok":bool(wid),"war_id":wid})
            elif t=="skill" and s["character_id"]:
                result=runtime.skill(db,world,s["character_id"],str(m.get("mob_id","")),int(m.get("index",-1)))
                await send(writer,{"type":"skill_result",**result})
                if result.get("ok"):
                    c=db.character(s["character_id"]);await broadcast_map(c["map_name"],{"type":"mob_state","mob_id":result["mob_id"],"hp":result["hp"],"dead":result["dead"]})
            elif t=="craft" and s["character_id"]:
                ok=db.craft(s["character_id"],str(m.get("recipe_id","")))
                await send(writer,{"type":"craft_result","ok":ok,"inventory":db.inventory(s["character_id"])})
            elif t=="quests" and s["character_id"]:
                await send(writer,{"type":"quest_rows","rows":db.quest_rows(s["character_id"])})
            elif t=="quest_claim" and s["character_id"]:
                ok=db.quest_claim(s["character_id"],str(m.get("quest_id","")))
                await send(writer,{"type":"quest_claim_result","ok":ok,"quests":db.quest_rows(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="trade_open" and s["character_id"]:
                target=str(m.get("target",""));tw=next((w for w,ss in sessions.items() if ss.get("name")==target),None)
                tid=trades.open(s["character_id"],sessions[tw]["character_id"]) if tw else None
                await send(writer,{"type":"trade_open_result","ok":bool(tid),"trade_id":tid})
                if tw and tid:await send(tw,{"type":"trade_invite","trade_id":tid,"from":s["name"]})
            elif t=="trade_offer" and s["character_id"]:
                ok=trades.offer(int(m.get("trade_id",0)),s["character_id"],int(m.get("gold",0)),m.get("items",[]))
                await send(writer,{"type":"trade_offer_result","ok":ok})
            elif t=="trade_accept" and s["character_id"]:
                tid=int(m.get("trade_id",0));ok=trades.accept(tid,s["character_id"])
                await send(writer,{"type":"trade_accept_result","ok":ok,"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="guild_create" and s["character_id"]:
                gid=db.guild_create(s["character_id"],str(m.get("name","")))
                await send(writer,{"type":"guild_result","ok":bool(gid),"guild":db.guild_for(s["character_id"])})
            elif t=="guild_deposit_gold" and s["character_id"]:
                ok=db.guild_deposit_gold(s["character_id"],int(m.get("gold",0)))
                await send(writer,{"type":"guild_result","ok":ok,"guild":db.guild_for(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="guild_deposit_item" and s["character_id"]:
                ok=db.guild_deposit_item(s["character_id"],str(m.get("item","")),int(m.get("count",1)),int(m.get("upgrade",0)))
                await send(writer,{"type":"guild_result","ok":ok,"guild":db.guild_for(s["character_id"]),"bank":db.guild_bank_rows(s["character_id"]),"inventory":db.inventory(s["character_id"])})
            elif t=="guild_info" and s["character_id"]:
                await send(writer,{"type":"guild_result","ok":True,"guild":db.guild_for(s["character_id"]),"bank":db.guild_bank_rows(s["character_id"])})
            elif t=="portal_travel" and s["character_id"]:
                result=teleport(db,s["character_id"],str(m.get("destination","")))
                await send(writer,{"type":"portal_result",**result})
                if result.get("ok"):
                    movement.clear(s["character_id"])
                    await send(writer,{"type":"world_snapshot","mobs":world.snapshot(result["map_name"]),"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="portal_list" and s["character_id"]:
                c=db.character(s["character_id"]);await send(writer,{"type":"portal_rows","rows":PORTALS.get(c["map_name"],[])})
            elif t=="leaderboard" and s["character_id"]:
                await send(writer,{"type":"leaderboard_rows","rows":leaderboard(db,int(m.get("limit",20)))})
            elif t=="dungeon_create" and s["character_id"]:
                inst=dungeons.create(s["character_id"],m.get("member_ids",[]),db.character(s["character_id"])["map_name"])
                await send(writer,{"type":"dungeon_result","ok":bool(inst),"dungeon":inst})
            elif t=="dungeon_progress" and s["character_id"]:
                inst=dungeons.progress(int(m.get("dungeon_id",0)),s["character_id"])
                await send(writer,{"type":"dungeon_result","ok":bool(inst),"dungeon":inst})
            elif t=="world_snapshot" and s["character_id"]:
                await send(writer,{"type":"world_snapshot","mobs":world.snapshot(db.character(s["character_id"])["map_name"]),"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="attack" and s["character_id"]:
                result=world.attack(s["character_id"],str(m.get("mob_id","")))
                await send(writer,{"type":"attack_result",**result})
                if result.get("ok"):
                    c=db.character(s["character_id"]);await broadcast_map(c["map_name"],{"type":"mob_state","mob_id":result["mob_id"],"hp":result["hp"],"dead":result["dead"]})
            elif t=="refine" and s["character_id"]:
                result=db.refine(s["character_id"],str(m.get("item","")),int(m.get("upgrade",0)))
                await send(writer,{"type":"refine_result",**result,"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="market_list" and s["character_id"]:
                lid=db.market_list(s["character_id"],str(m.get("item","")),int(m.get("count",1)),int(m.get("upgrade",0)),int(m.get("unit_price",0)))
                await send(writer,{"type":"market_list_result","ok":bool(lid),"listing_id":lid})
            elif t=="market_browse" and s["character_id"]:
                await send(writer,{"type":"market_rows","rows":db.market_rows(str(m.get("term","")))})
            elif t=="market_cancel" and s["character_id"]:
                ok=db.market_cancel(s["character_id"],int(m.get("listing_id",0)))
                await send(writer,{"type":"market_cancel_result","ok":ok,"inventory":db.inventory(s["character_id"])})
            elif t=="market_buy" and s["character_id"]:
                ok=db.market_buy(s["character_id"],int(m.get("listing_id",0)),int(m.get("count",1)))
                await send(writer,{"type":"market_buy_result","ok":ok,"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="mail_send" and s["character_id"]:
                ok=db.send_mail(s["character_id"],str(m.get("to","")),str(m.get("subject","")),str(m.get("body","")),str(m.get("item","")),int(m.get("count",0)),int(m.get("upgrade",0)),int(m.get("gold",0)))
                await send(writer,{"type":"mail_send_result","ok":ok,"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
            elif t=="mail_list" and s["character_id"]:
                await send(writer,{"type":"mail_rows","rows":db.mail_list(s["character_id"])})
            elif t=="mail_claim" and s["character_id"]:
                ok=db.claim_mail(s["character_id"],int(m.get("mail_id",0)))
                await send(writer,{"type":"mail_claim_result","ok":ok,"inventory":db.inventory(s["character_id"]),"gold":db.wallet(s["character_id"])})
    finally:
        s=sessions.pop(writer,{})
        cid=s.get("character_id")
        if cid:
            runtime.leave(cid)
            movement.clear(cid)
            players.pop(cid,None)
            await broadcast({"type":"player_leave","id":cid})
        writer.close()
        try:await writer.wait_closed()
        except Exception:pass

async def main():
    srv=await asyncio.start_server(handle,HOST,PORT)
    asyncio.create_task(world_loop())
    print("STGMT2 server listening on",HOST,PORT)
    async with srv:await srv.serve_forever()
if __name__=="__main__":asyncio.run(main())
