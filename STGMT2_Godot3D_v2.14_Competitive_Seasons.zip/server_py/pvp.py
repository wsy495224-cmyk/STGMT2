import time,random,math,json,os
class PvP:
 def __init__(self,db,runtime):
  self.db=db;self.runtime=runtime;self.last={}
  with open(os.path.join(os.path.dirname(__file__),"maps_v21.json"),encoding="utf-8") as f:self.maps={m["name"]:m for m in json.load(f)}
 def safe(self,c):
  m=self.maps.get(c["map_name"])
  if not m:return True
  for x1,x2,z1,z2 in m["safe_zones"]:
   if x1<=c["x"]<=x2 and z1<=c["z"]<=z2:return True
  return False
 def attack(self,a,b):
  if a==b:return {"ok":False,"error":"self"}
  ca=self.db.character(a);cb=self.db.character(b);ra=self.runtime.get(a);rb=self.runtime.get(b)
  if not ca or not cb or not ra or not rb:return {"ok":False,"error":"offline"}
  if ca["map_name"]!=cb["map_name"] or self.safe(ca) or self.safe(cb):return {"ok":False,"error":"safe zone"}
  if math.hypot(ca["x"]-cb["x"],ca["z"]-cb["z"])>4.5:return {"ok":False,"error":"range"}
  now=time.monotonic()
  if now-self.last.get(a,0)<1.0:return {"ok":False,"error":"cooldown"}
  self.last[a]=now
  sa=self.db.server_stats(a);sb=self.db.server_stats(b)
  if random.random()<sb.get("dodge",0):return {"ok":True,"dodged":True,"victim":b,"hp":int(rb["hp"])}
  crit=random.random()<sa.get("crit",0);dmg=max(1,int((sa["atk"]-sb["def"]*.55)*(1.65 if crit else 1.0)))
  rb["hp"]=max(0,rb["hp"]-dmg);dead=rb["hp"]<=0
  if dead:
   self.db.war_add_kill(a,b);rb["hp"]=rb["max_hp"];cb=self.db.character(b);self.db.save_position(b,0,1,0)
  return {"ok":True,"dodged":False,"damage":dmg,"critical":crit,"victim":b,"hp":int(rb["hp"]),"dead":dead}
