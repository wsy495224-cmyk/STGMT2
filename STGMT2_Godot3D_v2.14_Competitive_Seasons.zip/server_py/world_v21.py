import random
BOSSES={"Green Valley":"Valley Guardian","Red Dunes":"Sand Tyrant","Mist Forest":"Ancient Treant","Frozen Pass":"Ice Warden","Sunset Ruins":"Sunset Colossus","Dark Marsh":"Bog Sovereign","Sky Plateau":"Storm Emperor"}
NORMAL={"Green Valley":"Wildling","Red Dunes":"Dune Raider","Mist Forest":"Mist Stalker","Frozen Pass":"Frost Fang","Sunset Ruins":"Ruin Sentinel","Dark Marsh":"Marsh Fiend","Sky Plateau":"Sky Marauder"}
def populate(world):
 world.mobs={}
 idx=0
 for mi,map_name in enumerate(NORMAL):
  for n in range(12):
   idx+=1;world.mobs["m%d"%idx]={"kind":"normal","name":NORMAL[map_name],"map_name":map_name,"hp":100+mi*90,"max_hp":100+mi*90,"x":random.uniform(25,90),"z":random.uniform(-90,90),"alive":True}
  idx+=1;hp=700+mi*1500;world.mobs["m%d"%idx]={"kind":"boss","name":BOSSES[map_name],"map_name":map_name,"hp":hp,"max_hp":hp,"x":85.0,"z":85.0,"alive":True}
 for mob in world.mobs.values():
  mob.setdefault("spawn_x",mob["x"]);mob.setdefault("spawn_z",mob["z"]);mob.setdefault("statuses",{});mob.setdefault("target_id",None)

# Spawn origins are authoritative respawn anchors.
