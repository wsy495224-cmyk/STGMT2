import tempfile,os
from database import DB
from endgame_v213 import dungeon_reward,pvp_leaderboard,guild_leaderboard,record_pvp
from world_features_v24 import DungeonManager
p=tempfile.mktemp('.db');db=DB(p)
a,_=db.register('endgame1','password123');b,_=db.register('endgame2','password123')
c1=db.create_character(a,'EndHero','Blade');c2=db.create_character(b,'EndRival','Archer')
with db.cx:
 db.cx.execute("UPDATE characters SET level=35,map_name='Sky Plateau' WHERE id IN (?,?)",(c1,c2))
d=DungeonManager();run=d.create(c1,[c2],'Sky Plateau')
for _ in range(3):d.progress(run['id'],c1)
assert run['complete']
r=dungeon_reward(db,c1,'Sky Plateau',run['id']);assert r['ok'] and db._count(c1,'Relic Core')>=1
assert not dungeon_reward(db,c1,'Sky Plateau',run['id'])['ok']
record_pvp(db,c1,c2);assert pvp_leaderboard(db)[0]['name']=='EndHero'
assert db.guild_create(c1,'SkyGuild');assert guild_leaderboard(db)[0]['name']=='SkyGuild'
db.cx.close();os.remove(p);print('v2.13 dungeon/PvP/guild ranking smoke PASS')
