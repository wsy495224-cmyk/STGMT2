import secrets,hashlib,time
TTL=60*60*12
def digest(token):return hashlib.sha256(token.encode()).hexdigest()
def issue(db,account_id):
 token=secrets.token_urlsafe(32);h=digest(token);exp=int(time.time())+TTL
 with db.cx:
  db.cx.execute("DELETE FROM sessions WHERE account_id=? OR expires_at<?",(account_id,int(time.time())))
  db.cx.execute("INSERT INTO sessions(token_hash,account_id,expires_at) VALUES(?,?,?)",(h,account_id,exp))
 return token,exp
def resume(db,token):
 r=db.cx.execute("SELECT account_id,expires_at FROM sessions WHERE token_hash=?",(digest(token),)).fetchone()
 if not r or r["expires_at"]<int(time.time()):return None
 return int(r["account_id"])
