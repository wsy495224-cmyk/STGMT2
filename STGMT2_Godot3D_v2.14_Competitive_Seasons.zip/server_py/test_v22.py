import os,tempfile
fd,path=tempfile.mkstemp();os.close(fd);os.unlink(path)
import database as d
db=d.DB(path)
a,_=db.register("tester22","password22");cid=db.create_character(a,"Hero22","Blade")
from world import World
w=World(db);w.mobs={"near":{"kind":"normal","map_name":"Green Valley","hp":100,"max_hp":100,"x":1,"z":1,"alive":True},"far":{"kind":"normal","map_name":"Red Dunes","hp":100,"max_hp":100,"x":1,"z":1,"alive":True}}
assert len(w.snapshot("Green Valley"))==1
assert w.attack(cid,"far")["error"]=="wrong map"
from gameplay import runtime
runtime.enter(db.character(cid));assert runtime.skill(db,w,cid,"far",0)["error"]=="wrong map"
assert db.market_list(cid,"HACK_ITEM",1,0,1) is None
assert db.refine(cid,"HP Potion",0)["error"]=="not refineable"
print("v2.2 map/security smoke PASS")
os.unlink(path)
