import hashlib, hmac, os, base64
from config import PBKDF2_ROUNDS
def hash_password(password:str)->str:
    salt=os.urandom(16)
    digest=hashlib.pbkdf2_hmac("sha256",password.encode(),salt,PBKDF2_ROUNDS)
    return "pbkdf2_sha256$%d$%s$%s"%(PBKDF2_ROUNDS,base64.b64encode(salt).decode(),base64.b64encode(digest).decode())
def verify_password(password:str, encoded:str)->bool:
    try:
        scheme, rounds, salt_b64, digest_b64=encoded.split("$",3)
        if scheme!="pbkdf2_sha256": return False
        salt=base64.b64decode(salt_b64); expected=base64.b64decode(digest_b64)
        actual=hashlib.pbkdf2_hmac("sha256",password.encode(),salt,int(rounds))
        return hmac.compare_digest(actual,expected)
    except Exception:
        return False
