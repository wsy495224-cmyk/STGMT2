import tempfile,os,time
import config
fd,path=tempfile.mkstemp(suffix='.db');os.close(fd);config.DB_PATH=path
from database import DB
from competitive_v214 import Matchmaker,record_match,season_leaderboard,ensure_schema

db=DB();ensure_schema(db)
ids=[]
for i in range(2):
 aid,err=db.register('user'+str(i),'password123'); assert aid and not err
 cid=db.create_character(aid,'Hero'+str(i),'Blade');ids.append(cid)
mm=Matchmaker(db)
assert mm.join(ids[0])['queued']
r=mm.join(ids[1]);assert r['match']['mode']=='1v1'
assert record_match(db,[ids[0]],[ids[1]])
lb=season_leaderboard(db);assert lb['rows'][0]['name']=='Hero0' and lb['rows'][0]['points']==25
print('v2.14 competitive smoke PASS')
db.cx.close();os.unlink(path)
