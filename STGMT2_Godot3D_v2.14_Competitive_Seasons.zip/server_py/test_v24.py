import tempfile,os
from database import DB
from world_features_v24 import teleport,leaderboard,DungeonManager,boss_phase
p=tempfile.mktemp('.db');db=DB(p)
a,_=db.register('tester24','password24');cid=db.create_character(a,'Hero24','Blade')
assert teleport(db,cid,'Red Dunes')['error']=='level too low'
with db.cx:db.cx.execute('UPDATE characters SET level=30 WHERE id=?',(cid,))
r=teleport(db,cid,'Red Dunes');assert r['ok'] and db.character(cid)['map_name']=='Red Dunes'
assert teleport(db,cid,'Sky Plateau')['error']=='portal not connected'
assert leaderboard(db)[0]['name']=='Hero24'
d=DungeonManager();inst=d.create(cid,[],'Red Dunes');assert inst and not inst['complete']
d.progress(inst['id'],cid);d.progress(inst['id'],cid);d.progress(inst['id'],cid);assert inst['complete']
assert boss_phase({'kind':'boss','hp':20,'max_hp':100})==4
db.cx.close();os.remove(p);print('v2.4 world features smoke PASS')
