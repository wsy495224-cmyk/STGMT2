import sqlite3, time, json, random
from config import DB_PATH
from security import hash_password, verify_password

SCHEMA="""
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS accounts(
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, created_at INTEGER NOT NULL, banned INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS characters(
 id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL,
 name TEXT UNIQUE NOT NULL, class_name TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1,
 xp INTEGER NOT NULL DEFAULT 0, gold INTEGER NOT NULL DEFAULT 250,
 map_name TEXT NOT NULL DEFAULT 'Green Valley', x REAL NOT NULL DEFAULT 0,
 y REAL NOT NULL DEFAULT 1, z REAL NOT NULL DEFAULT 0,
 FOREIGN KEY(account_id) REFERENCES accounts(id)
);
CREATE TABLE IF NOT EXISTS inventory(
 character_id INTEGER NOT NULL, item_id TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0,
 upgrade INTEGER NOT NULL DEFAULT 0, bound INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(character_id,item_id,upgrade)
);
CREATE TABLE IF NOT EXISTS market(
 id INTEGER PRIMARY KEY AUTOINCREMENT, seller_character_id INTEGER NOT NULL,
 item_id TEXT NOT NULL, count INTEGER NOT NULL, upgrade INTEGER NOT NULL DEFAULT 0,
 unit_price INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS mail(
 id INTEGER PRIMARY KEY AUTOINCREMENT, recipient_character_id INTEGER NOT NULL,
 sender_character_id INTEGER, sender_name TEXT NOT NULL, subject TEXT NOT NULL,
 body TEXT NOT NULL, item_id TEXT NOT NULL DEFAULT '', item_count INTEGER NOT NULL DEFAULT 0,
 item_upgrade INTEGER NOT NULL DEFAULT 0, gold INTEGER NOT NULL DEFAULT 0,
 claimed INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS trade_sessions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, a_character INTEGER NOT NULL,
 b_character INTEGER NOT NULL, state TEXT NOT NULL DEFAULT 'open', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS quest_progress(
 character_id INTEGER NOT NULL, quest_id TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
 claimed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(character_id,quest_id)
);
CREATE TABLE IF NOT EXISTS guilds(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, master_character_id INTEGER NOT NULL,
 level INTEGER NOT NULL DEFAULT 1, xp INTEGER NOT NULL DEFAULT 0, gold INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS guild_members(
 guild_id INTEGER NOT NULL, character_id INTEGER UNIQUE NOT NULL, rank TEXT NOT NULL DEFAULT 'Member'
);
CREATE TABLE IF NOT EXISTS guild_bank(
 guild_id INTEGER NOT NULL, item_id TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0,
 upgrade INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(guild_id,item_id,upgrade)
);
CREATE TABLE IF NOT EXISTS equipped(
 character_id INTEGER NOT NULL, slot TEXT NOT NULL, item_id TEXT NOT NULL, upgrade INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(character_id,slot)
);
CREATE TABLE IF NOT EXISTS guild_wars(
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_a INTEGER NOT NULL, guild_b INTEGER NOT NULL,
 score_a INTEGER NOT NULL DEFAULT 0, score_b INTEGER NOT NULL DEFAULT 0,
 state TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
 token_hash TEXT PRIMARY KEY, account_id INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS equipment_sockets(
 character_id INTEGER NOT NULL, slot TEXT NOT NULL, socket_index INTEGER NOT NULL, gem_id TEXT NOT NULL,
 PRIMARY KEY(character_id,slot,socket_index)
);
CREATE TABLE IF NOT EXISTS dungeon_claims(
 run_id INTEGER NOT NULL, character_id INTEGER NOT NULL, claimed_at INTEGER NOT NULL,
 PRIMARY KEY(run_id,character_id)
);
CREATE TABLE IF NOT EXISTS pvp_stats(
 character_id INTEGER PRIMARY KEY, kills INTEGER NOT NULL DEFAULT 0, deaths INTEGER NOT NULL DEFAULT 0, rating INTEGER NOT NULL DEFAULT 1000
);
"""
ITEMS={
 "HP Potion":{"value":20,"trade":1,"kind":"consumable"},"MP Potion":{"value":25,"trade":1,"kind":"consumable"},
 "Crystal Shard":{"value":45,"trade":1,"kind":"material"},"Gem Fragment":{"value":55,"trade":1,"kind":"material"},
 "Upgrade Stone":{"value":120,"trade":1,"kind":"material"},"Rare Gem":{"value":600,"trade":1,"kind":"gem"},
 "Legendary Fragment":{"value":1800,"trade":1,"kind":"material"},
 "Mythic Essence":{"value":4500,"trade":1,"kind":"material"},"Relic Core":{"value":12000,"trade":1,"kind":"material"},
 "Ruby Gem":{"value":900,"trade":1,"kind":"gem"},"Sapphire Gem":{"value":900,"trade":1,"kind":"gem"},
 "Emerald Gem":{"value":900,"trade":1,"kind":"gem"},"Onyx Gem":{"value":900,"trade":1,"kind":"gem"},
 "Falcon Gem":{"value":1200,"trade":1,"kind":"gem"},"Shadow Gem":{"value":1200,"trade":1,"kind":"gem"},
}
from equipment_rules import EQUIPMENT
for _name,_rule in EQUIPMENT.items():
 ITEMS[_name]={"value":max(80,80+_rule["level"]*35),"trade":1,"kind":"equipment"}

UPGRADE_CHANCE={0:1.0,1:1.0,2:.95,3:.90,4:.82,5:.74,6:.66,7:.58,8:.50,9:.42,10:.34,11:.27,12:.20,13:.14,14:.09}
UPGRADE_COST={i:100+int(i*i*55) for i in range(15)}

class DB:
 def __init__(self,path=DB_PATH):
  self.cx=sqlite3.connect(path,check_same_thread=False);self.cx.row_factory=sqlite3.Row
  self.cx.executescript(SCHEMA);self.cx.commit()
 def tx(self): return self.cx
 def register(self,u,p):
  if len(u)<3 or len(p)<8:return None,"username/password too short"
  try:
   cur=self.cx.execute("INSERT INTO accounts(username,password_hash,created_at) VALUES(?,?,?)",(u,hash_password(p),int(time.time())));self.cx.commit();return cur.lastrowid,None
  except sqlite3.IntegrityError:return None,"username exists"
 def login(self,u,p):
  r=self.cx.execute("SELECT * FROM accounts WHERE username=?",(u,)).fetchone()
  return dict(r) if r and not r["banned"] and verify_password(p,r["password_hash"]) else None
 def characters(self,aid):
  return [dict(r) for r in self.cx.execute("SELECT id,name,class_name,level,xp,gold,map_name,x,y,z FROM characters WHERE account_id=?",(aid,))]
 def create_character(self,aid,name,c):
  if c not in ("Blade","Archer","Mystic") or len(name)<3:return None
  try:
   cur=self.cx.execute("INSERT INTO characters(account_id,name,class_name) VALUES(?,?,?)",(aid,name,c));cid=cur.lastrowid
   self.cx.execute("INSERT INTO inventory(character_id,item_id,count) VALUES(?,?,?)",(cid,"HP Potion",5))
   self.cx.commit();return cid
  except sqlite3.IntegrityError:return None
 def owns_character(self,aid,cid):
  return self.cx.execute("SELECT 1 FROM characters WHERE account_id=? AND id=?",(aid,cid)).fetchone() is not None
 def character(self,cid):
  r=self.cx.execute("SELECT * FROM characters WHERE id=?",(cid,)).fetchone();return dict(r) if r else None
 def save_position(self,cid,x,y,z):
  self.cx.execute("UPDATE characters SET x=?,y=?,z=? WHERE id=?",(x,y,z,cid));self.cx.commit()
 def inventory(self,cid):
  return [dict(r) for r in self.cx.execute("SELECT item_id,count,upgrade,bound FROM inventory WHERE character_id=? AND count>0 ORDER BY item_id,upgrade",(cid,))]
 def _count(self,cid,item,up=0):
  r=self.cx.execute("SELECT count FROM inventory WHERE character_id=? AND item_id=? AND upgrade=?",(cid,item,up)).fetchone();return int(r["count"]) if r else 0
 def _add(self,cid,item,count,up=0):
  self.cx.execute("""INSERT INTO inventory(character_id,item_id,count,upgrade) VALUES(?,?,?,?)
  ON CONFLICT(character_id,item_id,upgrade) DO UPDATE SET count=count+excluded.count""",(cid,item,count,up))
 def _take(self,cid,item,count,up=0):
  if count<1 or self._count(cid,item,up)<count:return False
  self.cx.execute("UPDATE inventory SET count=count-? WHERE character_id=? AND item_id=? AND upgrade=?",(count,cid,item,up));return True
 def wallet(self,cid):
  r=self.cx.execute("SELECT gold FROM characters WHERE id=?",(cid,)).fetchone();return int(r["gold"]) if r else 0
 def grant_drop(self,cid,enemy_kind):
  # v2.11: server-only rarity roll; clients never choose rewards.
  from economy_v211 import roll_rarity
  boss=enemy_kind=="boss"
  tables={"normal":[("HP Potion",.45,1),("Crystal Shard",.18,1),("Gem Fragment",.08,1)],
          "boss":[("Upgrade Stone",.75,2),("Rare Gem",.25,1),("Legendary Fragment",.10,1)]}
  gold=random.randint(8,18) if not boss else random.randint(100,220)
  xp=random.randint(12,24) if not boss else random.randint(180,300)
  rarity=roll_rarity(boss)
  drops=[]
  with self.cx:
   self.cx.execute("UPDATE characters SET gold=gold+?,xp=xp+? WHERE id=?",(gold,xp,cid))
   for item,chance,count in tables["boss" if boss else "normal"]:
    if random.random()<chance:self._add(cid,item,count);drops.append({"item":item,"count":count})
   if boss and rarity=="Mythic":self._add(cid,"Mythic Essence",1);drops.append({"item":"Mythic Essence","count":1})
   if boss and rarity=="Relic":self._add(cid,"Relic Core",1);drops.append({"item":"Relic Core","count":1})
  levels=[]
  while True:
   c=self.character(cid);need=100+max(0,c["level"]-1)*125
   if c["xp"]<need:break
   with self.cx:self.cx.execute("UPDATE characters SET xp=xp-?,level=level+1 WHERE id=?",(need,cid))
   levels.append(self.character(cid)["level"])
  return {"gold":gold,"xp":xp,"drops":drops,"rarity_roll":rarity,"level_ups":levels,"level":self.character(cid)["level"]}
 def refine(self,cid,item,up):
  from equipment_rules import EQUIPMENT
  if item not in EQUIPMENT:return {"ok":False,"accepted":False,"error":"not refineable"}
  if up<0 or up>=15:return {"ok":False,"accepted":False,"error":"max/invalid"}
  cost=UPGRADE_COST[up]; stone_cost=0 if up<4 else (1 if up<10 else 2)
  with self.cx:
   if self.wallet(cid)<cost:return {"ok":False,"accepted":False,"error":"not enough gold"}
   if self._count(cid,item,up)<1:return {"ok":False,"accepted":False,"error":"item missing"}
   if stone_cost and self._count(cid,"Upgrade Stone",0)<stone_cost:return {"ok":False,"accepted":False,"error":"upgrade stones missing"}
   self._take(cid,item,1,up)
   if stone_cost:self._take(cid,"Upgrade Stone",stone_cost,0)
   self.cx.execute("UPDATE characters SET gold=gold-? WHERE id=?",(cost,cid))
   success=random.random()<UPGRADE_CHANCE[up];new_up=up+1 if success else (up if up<5 else max(0,up-1));self._add(cid,item,1,new_up)
  return {"ok":success,"accepted":True,"success":success,"upgrade":new_up,"cost":cost,"stones":stone_cost}
 def market_list(self,cid,item,count,up,price):
  if price<1 or count<1 or item not in ITEMS or ITEMS[item].get("trade",0)!=1:return None
  with self.cx:
   if not self._take(cid,item,count,up):return None
   cur=self.cx.execute("INSERT INTO market(seller_character_id,item_id,count,upgrade,unit_price,created_at) VALUES(?,?,?,?,?,?)",(cid,item,count,up,price,int(time.time())))
  return cur.lastrowid
 def market_rows(self,term=""):
  from economy_v211 import MARKET_TTL
  cutoff=int(time.time())-MARKET_TTL
  q="SELECT m.*,c.name seller FROM market m JOIN characters c ON c.id=m.seller_character_id WHERE m.count>0 AND m.created_at>?"
  args=[cutoff]
  if term:q+=" AND m.item_id LIKE ?";args.append("%"+term[:40]+"%")
  q+=" ORDER BY m.id DESC LIMIT 100"
  return [dict(r) for r in self.cx.execute(q,args)]
 def market_buy(self,buyer,lid,count):
  if count<1:return False
  with self.cx:
   r=self.cx.execute("SELECT * FROM market WHERE id=?",(lid,)).fetchone()
   if not r or r["seller_character_id"]==buyer:return False
   qty=min(count,int(r["count"]));cost=qty*int(r["unit_price"])
   if self.wallet(buyer)<cost:return False
   self.cx.execute("UPDATE characters SET gold=gold-? WHERE id=?",(cost,buyer))
   from economy_v211 import market_tax, expired
   if expired(r["created_at"]):return False
   tax=market_tax(cost)
   self.cx.execute("UPDATE characters SET gold=gold+? WHERE id=?",(cost-tax,r["seller_character_id"]))
   self._add(buyer,r["item_id"],qty,r["upgrade"])
   self.cx.execute("UPDATE market SET count=count-? WHERE id=?",(qty,lid))
  return True

 def market_cancel(self,cid,lid):
  with self.cx:
   r=self.cx.execute("SELECT * FROM market WHERE id=? AND seller_character_id=? AND count>0",(lid,cid)).fetchone()
   if not r:return False
   self._add(cid,r["item_id"],int(r["count"]),int(r["upgrade"]))
   self.cx.execute("UPDATE market SET count=0 WHERE id=?",(lid,))
  return True
 def send_mail(self,sender,recipient_name,subject,body,item="",count=0,up=0,gold=0):
  rr=self.cx.execute("SELECT id FROM characters WHERE name=?",(recipient_name,)).fetchone()
  sr=self.character(sender)
  if not rr or not sr or gold<0 or count<0:return False
  with self.cx:
   if gold and self.wallet(sender)<gold:return False
   if item and not self._take(sender,item,count,up):return False
   if gold:self.cx.execute("UPDATE characters SET gold=gold-? WHERE id=?",(gold,sender))
   self.cx.execute("""INSERT INTO mail(recipient_character_id,sender_character_id,sender_name,subject,body,item_id,item_count,item_upgrade,gold,created_at)
   VALUES(?,?,?,?,?,?,?,?,?,?)""",(rr["id"],sender,sr["name"],subject[:80],body[:500],item,count,up,gold,int(time.time())))
  return True
 def mail_list(self,cid):
  return [dict(r) for r in self.cx.execute("SELECT id,sender_name,subject,body,item_id,item_count,item_upgrade,gold,claimed,created_at FROM mail WHERE recipient_character_id=? ORDER BY id DESC LIMIT 100",(cid,))]
 def claim_mail(self,cid,mid):
  with self.cx:
   r=self.cx.execute("SELECT * FROM mail WHERE id=? AND recipient_character_id=? AND claimed=0",(mid,cid)).fetchone()
   if not r:return False
   if r["item_id"] and r["item_count"]>0:self._add(cid,r["item_id"],r["item_count"],r["item_upgrade"])
   if r["gold"]>0:self.cx.execute("UPDATE characters SET gold=gold+? WHERE id=?",(r["gold"],cid))
   self.cx.execute("UPDATE mail SET claimed=1 WHERE id=?",(mid,))
  return True

 def craft(self,cid,recipe_id):
  from gameplay import RECIPES
  r=RECIPES.get(recipe_id)
  if not r:return False
  with self.cx:
   for item,n in r["ingredients"].items():
    if self._count(cid,item,0)<n:return False
   for item,n in r["ingredients"].items():self._take(cid,item,n,0)
   for item,n in r["result"].items():self._add(cid,item,n,0)
  return True
 def quest_event(self,cid,kind,target,n=1):
  from gameplay import QUESTS
  with self.cx:
   for qid,q in QUESTS.items():
    if q["kind"]==kind and q["target"]==target:
     self.cx.execute("""INSERT INTO quest_progress(character_id,quest_id,progress) VALUES(?,?,?)
     ON CONFLICT(character_id,quest_id) DO UPDATE SET progress=MIN(progress+excluded.progress,?)""",(cid,qid,n,q["goal"]))
 def quest_rows(self,cid):
  from gameplay import QUESTS
  rows={r["quest_id"]:dict(r) for r in self.cx.execute("SELECT * FROM quest_progress WHERE character_id=?",(cid,))}
  return [{"id":qid,**q,"progress":rows.get(qid,{}).get("progress",0),"claimed":rows.get(qid,{}).get("claimed",0)} for qid,q in QUESTS.items()]
 def quest_claim(self,cid,qid):
  from gameplay import QUESTS
  q=QUESTS.get(qid)
  if not q:return False
  r=self.cx.execute("SELECT progress,claimed FROM quest_progress WHERE character_id=? AND quest_id=?",(cid,qid)).fetchone()
  if not r or r["claimed"] or r["progress"]<q["goal"]:return False
  with self.cx:
   self.cx.execute("UPDATE quest_progress SET claimed=1 WHERE character_id=? AND quest_id=?",(cid,qid))
   self.cx.execute("UPDATE characters SET gold=gold+?,xp=xp+? WHERE id=?",(q["gold"],q["xp"],cid))
  return True
 def pvp_rating(self,cid):
  r=self.cx.execute("SELECT rating FROM pvp_stats WHERE character_id=?",(cid,)).fetchone()
  return int(r["rating"]) if r else 1000

 def guild_create(self,cid,name):
  if len(name)<3:return None
  try:
   with self.cx:
    cur=self.cx.execute("INSERT INTO guilds(name,master_character_id) VALUES(?,?)",(name,cid));gid=cur.lastrowid
    self.cx.execute("INSERT INTO guild_members(guild_id,character_id,rank) VALUES(?,?,?)",(gid,cid,"Master"))
   return gid
  except sqlite3.IntegrityError:return None
 def guild_for(self,cid):
  r=self.cx.execute("""SELECT g.* ,gm.rank FROM guild_members gm JOIN guilds g ON g.id=gm.guild_id WHERE gm.character_id=?""",(cid,)).fetchone()
  return dict(r) if r else None
 def guild_deposit_gold(self,cid,n):
  g=self.guild_for(cid)
  if not g or n<1 or self.wallet(cid)<n:return False
  with self.cx:
   self.cx.execute("UPDATE characters SET gold=gold-? WHERE id=?",(n,cid))
   self.cx.execute("UPDATE guilds SET gold=gold+?,xp=xp+? WHERE id=?",(n,max(1,n//10),g["id"]))
  return True
 def guild_deposit_item(self,cid,item,count,up=0):
  g=self.guild_for(cid)
  if not g or count<1:return False
  with self.cx:
   if not self._take(cid,item,count,up):return False
   self.cx.execute("""INSERT INTO guild_bank(guild_id,item_id,count,upgrade) VALUES(?,?,?,?)
   ON CONFLICT(guild_id,item_id,upgrade) DO UPDATE SET count=count+excluded.count""",(g["id"],item,count,up))
  return True
 def guild_bank_rows(self,cid):
  g=self.guild_for(cid)
  if not g:return []
  return [dict(r) for r in self.cx.execute("SELECT item_id,count,upgrade FROM guild_bank WHERE guild_id=? AND count>0",(g["id"],))]

 def equipped_rows(self,cid):
  return [dict(r) for r in self.cx.execute("SELECT slot,item_id,upgrade FROM equipped WHERE character_id=?",(cid,))]
 def equip_item(self,cid,item,up=0):
  from equipment_rules import EQUIPMENT
  c=self.character(cid);rule=EQUIPMENT.get(item)
  if not c or not rule or rule["class"]!=c["class_name"] or self._count(cid,item,up)<1:return False
  slot=rule["slot"]
  with self.cx:
   old=self.cx.execute("SELECT item_id,upgrade FROM equipped WHERE character_id=? AND slot=?",(cid,slot)).fetchone()
   if old:self._add(cid,old["item_id"],1,old["upgrade"])
   if not self._take(cid,item,1,up):return False
   self.cx.execute("""INSERT INTO equipped(character_id,slot,item_id,upgrade) VALUES(?,?,?,?)
   ON CONFLICT(character_id,slot) DO UPDATE SET item_id=excluded.item_id,upgrade=excluded.upgrade""",(cid,slot,item,up))
  return True
 def socket_rows(self,cid):
  return [dict(r) for r in self.cx.execute("SELECT slot,socket_index,gem_id FROM equipment_sockets WHERE character_id=? ORDER BY slot,socket_index",(cid,))]
 def socket_gem(self,cid,slot,index,gem):
  from equipment_rules import GEMS
  if gem not in GEMS or index not in (0,1,2) or self._count(cid,gem,0)<1:return False
  equipped=self.cx.execute("SELECT 1 FROM equipped WHERE character_id=? AND slot=?",(cid,slot)).fetchone()
  if not equipped:return False
  occupied=self.cx.execute("SELECT 1 FROM equipment_sockets WHERE character_id=? AND slot=? AND socket_index=?",(cid,slot,index)).fetchone()
  if occupied:return False
  with self.cx:
   if not self._take(cid,gem,1,0):return False
   self.cx.execute("INSERT INTO equipment_sockets(character_id,slot,socket_index,gem_id) VALUES(?,?,?,?)",(cid,slot,index,gem))
  return True
 def server_stats(self,cid):
  from equipment_rules import stats
  c=self.character(cid)
  return stats(c,self.equipped_rows(cid),self.socket_rows(cid)) if c else {}
 def guild_set_rank(self,actor,target_name,rank):
  if rank not in ("Officer","Member"):return False
  g=self.guild_for(actor)
  if not g or g["rank"]!="Master":return False
  t=self.cx.execute("SELECT id FROM characters WHERE name=?",(target_name,)).fetchone()
  if not t:return False
  with self.cx:
   cur=self.cx.execute("UPDATE guild_members SET rank=? WHERE guild_id=? AND character_id=?",(rank,g["id"],t["id"]))
  return cur.rowcount>0
 def guild_invite(self,actor,target_cid):
  g=self.guild_for(actor)
  if not g or g["rank"] not in ("Master","Officer") or self.guild_for(target_cid):return False
  try:
   with self.cx:self.cx.execute("INSERT INTO guild_members(guild_id,character_id,rank) VALUES(?,?,?)",(g["id"],target_cid,"Member"))
   return True
  except sqlite3.IntegrityError:return False
 def guild_withdraw_item(self,cid,item,count,up=0):
  g=self.guild_for(cid)
  if not g or g["rank"] not in ("Master","Officer") or count<1:return False
  with self.cx:
   r=self.cx.execute("SELECT count FROM guild_bank WHERE guild_id=? AND item_id=? AND upgrade=?",(g["id"],item,up)).fetchone()
   if not r or r["count"]<count:return False
   self.cx.execute("UPDATE guild_bank SET count=count-? WHERE guild_id=? AND item_id=? AND upgrade=?",(count,g["id"],item,up))
   self._add(cid,item,count,up)
  return True
 def war_start(self,cid,enemy_guild_name):
  g=self.guild_for(cid)
  if not g or g["rank"]!="Master":return None
  e=self.cx.execute("SELECT id FROM guilds WHERE name=?",(enemy_guild_name,)).fetchone()
  if not e or e["id"]==g["id"]:return None
  with self.cx:
   cur=self.cx.execute("INSERT INTO guild_wars(guild_a,guild_b,created_at) VALUES(?,?,?)",(g["id"],e["id"],int(time.time())))
  return cur.lastrowid
 def war_for_guilds(self,ga,gb):
  return self.cx.execute("""SELECT * FROM guild_wars WHERE state='active' AND
  ((guild_a=? AND guild_b=?) OR (guild_a=? AND guild_b=?)) ORDER BY id DESC LIMIT 1""",(ga,gb,gb,ga)).fetchone()
 def war_add_kill(self,killer_cid,victim_cid):
  kg=self.guild_for(killer_cid);vg=self.guild_for(victim_cid)
  if not kg or not vg:return False
  war=self.war_for_guilds(kg["id"],vg["id"])
  if not war:return False
  col="score_a" if war["guild_a"]==kg["id"] else "score_b"
  with self.cx:self.cx.execute("UPDATE guild_wars SET "+col+"="+col+"+1 WHERE id=?",(war["id"],))
  return True
