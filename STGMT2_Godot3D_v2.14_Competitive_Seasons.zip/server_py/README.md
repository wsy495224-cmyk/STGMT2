# STGMT2 local online server

Requires only Python 3 standard library.

Windows:
`run_server.bat`

Linux/macOS:
`sh run_server.sh`

Default endpoint: 127.0.0.1:8182

The SQLite file is created automatically in this folder.
For public hosting, do not expose this development server directly to the
Internet. Use a hardened deployment architecture and move all valuable game
actions (combat, drops, upgrades, trade, market, mail) to server authority.
