import time

SEASON_SECONDS=30*24*3600
WAR_WIN_GOLD=5000
WAR_WIN_XP=1200

class Matchmaker:
    def __init__(self, db):
        self.db=db; self.queue=[]; self.matches={}; self.next_id=1
    def join(self,cid,mode='1v1'):
        if mode not in ('1v1','3v3'): return {'ok':False,'error':'mode'}
        if any(q['cid']==cid for q in self.queue): return {'ok':False,'error':'queued'}
        rating=self.db.pvp_rating(cid)
        self.queue.append({'cid':cid,'mode':mode,'rating':rating,'at':time.time()})
        return self._pair(mode) or {'ok':True,'queued':True,'mode':mode}
    def leave(self,cid):
        before=len(self.queue); self.queue=[q for q in self.queue if q['cid']!=cid]
        return before!=len(self.queue)
    def _pair(self,mode):
        qs=[q for q in self.queue if q['mode']==mode]
        need=2 if mode=='1v1' else 6
        if len(qs)<need:return None
        qs.sort(key=lambda q:(q['rating'],q['at']))
        chosen=qs[:need]; ids=[q['cid'] for q in chosen]
        self.queue=[q for q in self.queue if q['cid'] not in ids]
        mid=self.next_id;self.next_id+=1
        teams=[ids[:1],ids[1:]] if mode=='1v1' else [ids[:3],ids[3:]]
        self.matches[mid]={'id':mid,'mode':mode,'teams':teams,'state':'ready','created_at':int(time.time())}
        return {'ok':True,'queued':False,'match':self.matches[mid]}

def ensure_schema(db):
    db.cx.executescript('''
    CREATE TABLE IF NOT EXISTS pvp_seasons(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,start_at INTEGER NOT NULL,end_at INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'active');
    CREATE TABLE IF NOT EXISTS season_scores(season_id INTEGER NOT NULL,character_id INTEGER NOT NULL,wins INTEGER NOT NULL DEFAULT 0,losses INTEGER NOT NULL DEFAULT 0,points INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(season_id,character_id));
    CREATE TABLE IF NOT EXISTS guild_war_rewards(war_id INTEGER PRIMARY KEY,winner_guild_id INTEGER NOT NULL,gold INTEGER NOT NULL,xp INTEGER NOT NULL,awarded_at INTEGER NOT NULL);
    ''');db.cx.commit()
    row=db.cx.execute("SELECT * FROM pvp_seasons WHERE state='active' ORDER BY id DESC LIMIT 1").fetchone()
    if not row:
        now=int(time.time());db.cx.execute("INSERT INTO pvp_seasons(name,start_at,end_at) VALUES(?,?,?)",('Season 1',now,now+SEASON_SECONDS));db.cx.commit()

def active_season(db):
    ensure_schema(db);r=db.cx.execute("SELECT * FROM pvp_seasons WHERE state='active' ORDER BY id DESC LIMIT 1").fetchone();return dict(r)

def record_match(db,winner_ids,loser_ids):
    s=active_season(db);sid=s['id']
    with db.cx:
        for cid in winner_ids: db.cx.execute('INSERT INTO season_scores(season_id,character_id,wins,points) VALUES(?,?,1,25) ON CONFLICT(season_id,character_id) DO UPDATE SET wins=wins+1,points=points+25',(sid,cid))
        for cid in loser_ids: db.cx.execute('INSERT INTO season_scores(season_id,character_id,losses,points) VALUES(?,?,1,5) ON CONFLICT(season_id,character_id) DO UPDATE SET losses=losses+1,points=points+5',(sid,cid))
    return True

def season_leaderboard(db,limit=20):
    s=active_season(db);limit=max(1,min(int(limit),50))
    rows=db.cx.execute('''SELECT c.name,c.class_name,c.level,ss.wins,ss.losses,ss.points FROM season_scores ss JOIN characters c ON c.id=ss.character_id WHERE ss.season_id=? ORDER BY ss.points DESC,ss.wins DESC,c.name LIMIT ?''',(s['id'],limit)).fetchall()
    return {'season':s,'rows':[dict(r) for r in rows]}

def settle_guild_war(db,war_id):
    from guild_wars_v25 import war_state
    w=war_state(db,war_id)
    if not w or w.get('state')!='finished':return {'ok':False,'error':'not finished'}
    winner=w.get('winner_guild_id',0)
    if not winner:return {'ok':True,'draw':True}
    if db.cx.execute('SELECT 1 FROM guild_war_rewards WHERE war_id=?',(war_id,)).fetchone():return {'ok':False,'error':'already rewarded'}
    with db.cx:
        db.cx.execute('UPDATE guilds SET gold=gold+?,xp=xp+? WHERE id=?',(WAR_WIN_GOLD,WAR_WIN_XP,winner))
        db.cx.execute('INSERT INTO guild_war_rewards VALUES(?,?,?,?,?)',(war_id,winner,WAR_WIN_GOLD,WAR_WIN_XP,int(time.time())))
    return {'ok':True,'winner_guild_id':winner,'gold':WAR_WIN_GOLD,'xp':WAR_WIN_XP}
