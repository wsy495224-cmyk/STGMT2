import time
SCORE_TO_WIN=10
WAR_SECONDS=900

def war_state(db,war_id):
    row=db.cx.execute('SELECT * FROM guild_wars WHERE id=?',(war_id,)).fetchone()
    if not row:return None
    d=dict(row); created=float(d.get('created_at') or 0); now=time.time()
    if d['state']=='active' and (d['score_a']>=SCORE_TO_WIN or d['score_b']>=SCORE_TO_WIN or (created and now-created>=WAR_SECONDS)):
        if d['score_a']>d['score_b']: winner=d['guild_a']
        elif d['score_b']>d['score_a']: winner=d['guild_b']
        else:winner=0
        db.cx.execute("UPDATE guild_wars SET state='finished' WHERE id=?",(war_id,));db.cx.commit();d['state']='finished';d['winner_guild_id']=winner
    return d
