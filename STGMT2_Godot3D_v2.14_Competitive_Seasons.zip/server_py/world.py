import math, time, random
from boss_system_v25 import boss_special, phase_for
class World:
 def __init__(self,db):
  self.db=db;self.mobs={};self.respawn_normal=12.0;self.respawn_boss=45.0
 def spawn_demo(self):
  self.mobs={"mob_1":{"kind":"normal","hp":100,"max_hp":100,"x":8.0,"z":8.0,"spawn_x":8.0,"spawn_z":8.0,"alive":True,"map_name":"Green Valley"},"boss_1":{"kind":"boss","hp":800,"max_hp":800,"x":18.0,"z":-12.0,"spawn_x":18.0,"spawn_z":-12.0,"alive":True,"map_name":"Green Valley"}}
 def snapshot(self,map_name=None):
  return [{"id":k,**v} for k,v in self.mobs.items() if map_name is None or v.get("map_name")==map_name]
 def _kill(self,m):
  m["alive"]=False;m["dead_at"]=time.monotonic();m["target_id"]=None;m["hp"]=0
 def attack(self,cid,mob_id):
  m=self.mobs.get(mob_id);c=self.db.character(cid)
  if not m or not c or not m["alive"]:return {"ok":False,"error":"invalid target"}
  if m.get("map_name",c.get("map_name"))!=c.get("map_name"):return {"ok":False,"error":"wrong map"}
  if math.hypot(float(c["x"])-m["x"],float(c["z"])-m["z"])>4.2:return {"ok":False,"error":"out of range"}
  stats=self.db.server_stats(cid);dmg=max(1,int(stats.get("atk",24)))
  m["hp"]=max(0,m["hp"]-dmg);dead=m["hp"]<=0
  result={"ok":True,"mob_id":mob_id,"damage":dmg,"hp":m["hp"],"dead":dead}
  if dead:
   self._kill(m);result["reward"]=self.db.grant_drop(cid,m["kind"]);self.db.quest_event(cid,"kill",m["kind"],1)
  return result
 def tick(self,runtime,dt=0.2):
  now=time.monotonic();events=[]
  for mid,m in self.mobs.items():
   if m.get("kind")=="boss" and m.get("alive"):
    events.extend(boss_special(self,mid,m,runtime,self.db,now))
   if not m["alive"]:
    wait=self.respawn_boss if m["kind"]=="boss" else self.respawn_normal
    if now-m.get("dead_at",now)>=wait:
     m.update(alive=True,hp=m["max_hp"],x=m.get("spawn_x",m["x"]),z=m.get("spawn_z",m["z"]),target_id=None,statuses={});events.append({"type":"mob_respawn","mob_id":mid,"map_name":m.get("map_name"),"hp":m["hp"],"x":m["x"],"z":m["z"]})
    continue
   statuses=m.setdefault("statuses",{});statuses={k:v for k,v in statuses.items() if v>now};m["statuses"]=statuses
   if "stun" in statuses:continue
   candidates=[]
   for cid,r in runtime.players.items():
    c=self.db.character(cid)
    if c and c["map_name"]==m.get("map_name") and r.get("hp",0)>0:
     d=math.hypot(c["x"]-m["x"],c["z"]-m["z"])
     if d<=12.0:candidates.append((d,cid,c,r))
   if not candidates:m["target_id"]=None;continue
   d,cid,c,r=min(candidates,key=lambda x:x[0]);m["target_id"]=cid
   if d>2.3:
    speed=(1.4 if m["kind"]=="boss" else 1.9)*(0.55 if "slow" in statuses else 1.0);step=min(d-2.0,speed*dt)
    if d>0:m["x"]+=(c["x"]-m["x"])/d*step;m["z"]+=(c["z"]-m["z"])/d*step
   elif now>=m.get("next_attack",0):
    m["next_attack"]=now+(2.2 if m["kind"]=="boss" else 1.7);stats=self.db.server_stats(cid);raw=(32 if m["kind"]=="boss" else 12)+int(m["max_hp"]/350);dmg=max(1,int(raw-stats.get("def",0)*0.35));r["hp"]=max(0,r["hp"]-dmg);dead=r["hp"]<=0
    ev={"type":"mob_attack","mob_id":mid,"target_id":cid,"damage":dmg,"player_hp":int(r["hp"]),"dead":dead,"map_name":m.get("map_name")};events.append(ev)
    if dead:
     r["hp"]=r["max_hp"];r["mp"]=r["max_mp"];self.db.save_position(cid,0,1,0);events.append({"type":"player_respawn","id":cid,"hp":int(r["hp"]),"mp":int(r["mp"]),"x":0,"y":1,"z":0,"map_name":m.get("map_name")})
  return events
