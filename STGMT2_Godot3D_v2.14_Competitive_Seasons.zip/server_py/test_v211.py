import os,tempfile,random
fd,path=tempfile.mkstemp();os.close(fd);os.unlink(path)
import database
from economy_v211 import roll_rarity,market_tax,expired
D=database.DB(path); aid,_=D.register('econuser','password123'); cid=D.create_character(aid,'EconHero','Blade')
D._add(cid,'Upgrade Stone',3);D.cx.commit(); lid=D.market_list(cid,'Upgrade Stone',2,0,100);assert lid
before=D._count(cid,'Upgrade Stone');assert D.market_cancel(cid,lid);assert D._count(cid,'Upgrade Stone')==before+2
assert market_tax(1000)==30 and expired(1,700000)
class R:
 def choices(self,names,weights,k): return ['Relic']
assert roll_rarity(True,R())=='Relic'
r=D.grant_drop(cid,'boss');assert r['rarity_roll'] in ('Common','Medium','Rare','Legendary','Mythic','Relic')
print('v2.11 economy/rarity smoke PASS')
D.cx.close();os.remove(path)
