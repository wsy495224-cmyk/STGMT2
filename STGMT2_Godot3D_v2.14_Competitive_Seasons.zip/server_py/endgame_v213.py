import time

DUNGEONS={
 'Green Valley': {'name':'Valley Depths','min_level':5,'boss':'Valley Guardian','gold':450,'xp':350,'loot':[('Upgrade Stone',2),('Rare Gem',1)]},
 'Red Dunes': {'name':'Tyrant Tomb','min_level':10,'boss':'Sand Tyrant','gold':700,'xp':600,'loot':[('Upgrade Stone',3),('Legendary Fragment',1)]},
 'Mist Forest': {'name':'Ancient Root','min_level':15,'boss':'Ancient Treant','gold':950,'xp':900,'loot':[('Rare Gem',1),('Legendary Fragment',2)]},
 'Frozen Pass': {'name':'Frozen Citadel','min_level':20,'boss':'Ice Warden','gold':1300,'xp':1250,'loot':[('Upgrade Stone',4),('Mythic Essence',1)]},
 'Sunset Ruins': {'name':'Colossus Vault','min_level':25,'boss':'Sunset Colossus','gold':1750,'xp':1700,'loot':[('Legendary Fragment',3),('Mythic Essence',1)]},
 'Dark Marsh': {'name':'Sovereign Mire','min_level':30,'boss':'Bog Sovereign','gold':2300,'xp':2300,'loot':[('Mythic Essence',2),('Relic Core',1)]},
 'Sky Plateau': {'name':'Storm Throne','min_level':35,'boss':'Storm Emperor','gold':3200,'xp':3200,'loot':[('Mythic Essence',3),('Relic Core',1)]},
}

def dungeon_reward(db,cid,map_name,run_id):
 cfg=DUNGEONS.get(map_name); c=db.character(cid)
 if not cfg or not c or c['level']<cfg['min_level']: return {'ok':False,'error':'not eligible'}
 with db.cx:
  exists=db.cx.execute('SELECT 1 FROM dungeon_claims WHERE run_id=? AND character_id=?',(run_id,cid)).fetchone()
  if exists:return {'ok':False,'error':'already claimed'}
  db.cx.execute('INSERT INTO dungeon_claims(run_id,character_id,claimed_at) VALUES(?,?,?)',(run_id,cid,int(time.time())))
  db.cx.execute('UPDATE characters SET gold=gold+?,xp=xp+? WHERE id=?',(cfg['gold'],cfg['xp'],cid))
  for item,count in cfg['loot']: db._add(cid,item,count,0)
 return {'ok':True,'gold':cfg['gold'],'xp':cfg['xp'],'loot':[{'item':i,'count':n} for i,n in cfg['loot']]}

def pvp_leaderboard(db,limit=20):
 limit=max(1,min(int(limit),50))
 rows=db.cx.execute('''SELECT c.name,c.class_name,c.level,COALESCE(p.kills,0) kills,COALESCE(p.deaths,0) deaths,
 COALESCE(p.rating,1000) rating FROM characters c LEFT JOIN pvp_stats p ON p.character_id=c.id
 ORDER BY rating DESC,kills DESC,deaths ASC,c.name ASC LIMIT ?''',(limit,)).fetchall()
 return [dict(r) for r in rows]

def guild_leaderboard(db,limit=20):
 limit=max(1,min(int(limit),50))
 rows=db.cx.execute('''SELECT g.name,g.level,g.xp,g.gold,COUNT(gm.character_id) members FROM guilds g
 LEFT JOIN guild_members gm ON gm.guild_id=g.id GROUP BY g.id ORDER BY g.level DESC,g.xp DESC,g.gold DESC,g.name ASC LIMIT ?''',(limit,)).fetchall()
 return [dict(r) for r in rows]

def record_pvp(db,killer,victim):
 with db.cx:
  db.cx.execute('''INSERT INTO pvp_stats(character_id,kills,deaths,rating) VALUES(?,1,0,1015)
   ON CONFLICT(character_id) DO UPDATE SET kills=kills+1,rating=rating+15''',(killer,))
  db.cx.execute('''INSERT INTO pvp_stats(character_id,kills,deaths,rating) VALUES(?,0,1,990)
   ON CONFLICT(character_id) DO UPDATE SET deaths=deaths+1,rating=MAX(100,rating-10)''',(victim,))
