import json, os, time, math
MAP_FILE=os.path.join(os.path.dirname(__file__),'maps_v21.json')
MAPS=json.load(open(MAP_FILE,encoding='utf-8'))
MAP_BY_NAME={m['name']:m for m in MAPS}
ORDER=[m['name'] for m in MAPS]
PORTALS={}
for i,name in enumerate(ORDER):
    links=[]
    if i>0: links.append({'to':ORDER[i-1],'x':-8.0,'z':0.0})
    if i<len(ORDER)-1: links.append({'to':ORDER[i+1],'x':8.0,'z':0.0})
    PORTALS[name]=links

def teleport(db,cid,destination):
    c=db.character(cid); target=MAP_BY_NAME.get(destination)
    if not c or not target:return {'ok':False,'error':'invalid destination'}
    if destination not in [p['to'] for p in PORTALS.get(c['map_name'],[])]:return {'ok':False,'error':'portal not connected'}
    if c['level']<int(target['min_level']):return {'ok':False,'error':'level too low','required_level':target['min_level']}
    with db.cx:
        db.cx.execute("UPDATE characters SET map_name=?,x=0,y=1,z=0 WHERE id=?",(destination,cid))
    return {'ok':True,'map_name':destination,'x':0,'y':1,'z':0}

def leaderboard(db,limit=20):
    limit=max(1,min(int(limit),50))
    rows=db.cx.execute("SELECT name,class_name,level,xp FROM characters ORDER BY level DESC,xp DESC,name ASC LIMIT ?",(limit,)).fetchall()
    return [dict(r) for r in rows]

class DungeonManager:
    def __init__(self):self.instances={};self.next_id=1
    def create(self,leader_id,member_ids,map_name='Green Valley'):
        ids=[]
        for x in [leader_id]+list(member_ids or []):
            if x not in ids:ids.append(x)
        if len(ids)>5:return None
        iid=self.next_id;self.next_id+=1
        self.instances[iid]={'id':iid,'leader_id':leader_id,'members':ids,'stage':1,'max_stage':3,'created_at':time.time(),'map_name':map_name,'complete':False}
        return self.instances[iid]
    def progress(self,iid,cid):
        d=self.instances.get(iid)
        if not d or cid not in d['members'] or d['complete']:return None
        d['stage']+=1
        if d['stage']>d['max_stage']:d['stage']=d['max_stage'];d['complete']=True
        return d

def boss_phase(mob):
    if mob.get('kind')!='boss' or mob.get('max_hp',0)<=0:return 1
    ratio=mob['hp']/mob['max_hp']
    return 4 if ratio<=.25 else 3 if ratio<=.50 else 2 if ratio<=.75 else 1
