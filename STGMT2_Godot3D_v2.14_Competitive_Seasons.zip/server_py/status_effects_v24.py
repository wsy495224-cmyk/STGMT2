import time

def apply_status(target,status,duration,power=0):
    now=time.monotonic(); target.setdefault('statuses',{})[status]={'until':now+float(duration),'power':power,'next_tick':now+1.0}

def tick_statuses(target,now=None):
    now=now or time.monotonic();events=[];statuses=target.setdefault('statuses',{})
    for name,data in list(statuses.items()):
        # Backward compatibility with v2.3 numeric expiries.
        if isinstance(data,(int,float)):
            if data<=now:statuses.pop(name,None)
            continue
        if data['until']<=now:statuses.pop(name,None);events.append({'status':name,'ended':True});continue
        if name in ('bleed','burn') and now>=data.get('next_tick',now+1):
            dmg=max(1,int(data.get('power',3)));target['hp']=max(0,target['hp']-dmg);data['next_tick']=now+1.0;events.append({'status':name,'damage':dmg,'hp':target['hp']})
    return events
