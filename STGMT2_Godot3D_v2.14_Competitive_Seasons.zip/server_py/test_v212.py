import os,tempfile
fd,path=tempfile.mkstemp(suffix='.db');os.close(fd);os.unlink(path)
from database import DB,ITEMS
from equipment_rules import EQUIPMENT
D=DB(path);aid,_=D.register('settester','password123');cid=D.create_character(aid,'SetHero','Blade')
# old compatibility test still works
D._add(cid,'Iron Vanguard',1);D.cx.commit();assert D.equip_item(cid,'Iron Vanguard');assert D.server_stats(cid)['atk']>=56
# Endgame registry includes 30 new pieces (3 classes x 5 slots x 2 tiers).
end=[n for n,r in EQUIPMENT.items() if r['rarity'] in ('Mythic','Relic')];assert len(end)==30
# Raise level and equip 3 Mythic Blade pieces to activate 2/3 piece bonuses.
D.cx.execute('UPDATE characters SET level=50 WHERE id=?',(cid,));D.cx.commit()
myth=[n for n,r in EQUIPMENT.items() if r['class']=='Blade' and r['rarity']=='Mythic'][:3]
for n in myth:D._add(cid,n,1)
D.cx.commit()
for n in myth:assert D.equip_item(cid,n)
st=D.server_stats(cid);assert 'Mythic2' in st['set_bonus'] and 'Mythic3' in st['set_bonus']
# Socket a gem and prove it changes authoritative stats.
D._add(cid,'Ruby Gem',1);D.cx.commit();before=D.server_stats(cid)['atk'];assert D.socket_gem(cid,'weapon',0,'Ruby Gem');after=D.server_stats(cid)['atk'];assert after>=before+8
assert D._count(cid,'Ruby Gem')==0
print('v2.12 endgame equipment/set/socket stats PASS')
D.cx.close();os.remove(path)
