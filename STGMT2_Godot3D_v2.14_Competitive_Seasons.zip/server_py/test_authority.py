import os,tempfile
fd,path=tempfile.mkstemp(suffix=".db");os.close(fd)
try:
 from database import DB
 d=DB(path)
 aid,err=d.register("tester","password123")
 cid=d.create_character(aid,"HeroTest","Blade")
 assert cid and d.wallet(cid)==250
 assert d.inventory(cid)[0]["item_id"]=="HP Potion"
 drop=d.grant_drop(cid,"boss");assert drop["gold"]>0
 assert d.wallet(cid)>250
 print("authority smoke test PASS")
finally:
 try:os.remove(path)
 except OSError:pass
