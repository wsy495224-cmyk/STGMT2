import os,tempfile
fd,path=tempfile.mkstemp(suffix=".db");os.close(fd)
try:
 from database import DB
 from gameplay import runtime
 from pvp import PvP
 d=DB(path);a,_=d.register("alpha","password123");b,_=d.register("bravo","password123")
 ca=d.create_character(a,"AlphaHero","Blade");cb=d.create_character(b,"BravoHero","Archer")
 d._add(ca,"Iron Vanguard",1);d.cx.commit();assert d.equip_item(ca,"Iron Vanguard",0)
 assert d.server_stats(ca)["atk"]>=56
 runtime.enter(d.character(ca));runtime.enter(d.character(cb))
 d.save_position(ca,30,1,30);d.save_position(cb,32,1,30)
 p=PvP(d,runtime);r=p.attack(ca,cb);assert r["ok"]
 ga=d.guild_create(ca,"AlphaGuild");gb=d.guild_create(cb,"BravoGuild");assert ga and gb
 wid=d.war_start(ca,"BravoGuild");assert wid
 assert d.war_add_kill(ca,cb)
 print("v2.1 PvP/guild/equipment smoke PASS")
finally:
 try:os.remove(path)
 except OSError:pass
