import json, os
CLASS_BASE={
"Blade":{"hp":420,"mp":170,"atk":42,"def":12,"crit":.08,"dodge":.04},
"Archer":{"hp":320,"mp":250,"atk":36,"def":7,"crit":.12,"dodge":.08},
"Mystic":{"hp":285,"mp":350,"atk":33,"def":6,"crit":.09,"dodge":.05}}
RARITY_BONUS={"Easy":0.00,"Common":0.01,"Medium":0.02,"Rare":0.04,"Legendary":0.07,"Mythic":0.11,"Relic":0.16}
_DATA=os.path.join(os.path.dirname(__file__),"..","data","equipment_v12.json")
with open(_DATA,encoding="utf-8") as f:_rows=json.load(f)
EQUIPMENT={r["name"]:{"id":r["id"],"class":r["class"],"slot":r["slot"],"rarity":r["rarity"],"level":int(r["level"]),"atk":int(r.get("attack",0)),"def":int(r.get("defense",0)),"hp":int(r.get("hp",0)),"mp":int(r.get("mp",0)),"refineable":True} for r in _rows}
# Compatibility names used by earlier releases/tests.
EQUIPMENT["Iron Vanguard"]={"id":"legacy_blade_weapon","class":"Blade","slot":"weapon","rarity":"Common","level":1,"atk":14,"def":0,"hp":0,"mp":0,"refineable":True}
# v2.12 endgame tiers: derived from each class's five Legendary slot templates.
for cls in ("Blade","Archer","Mystic"):
 legends=[(n,r) for n,r in EQUIPMENT.items() if r.get("class")==cls and r.get("rarity")=="Legendary"]
 for tier,mult,level in (("Mythic",1.25,40),("Relic",1.55,50)):
  for name,r in legends:
   new=f"{tier} {name}"
   EQUIPMENT[new]={**r,"id":tier.lower()+"_"+r["id"],"rarity":tier,"level":level,
     "atk":int(r["atk"]*mult),"def":int(r["def"]*mult),"hp":int(r["hp"]*mult),"mp":int(r["mp"]*mult)}
GEMS={
 "Ruby Gem":{"atk":8},"Sapphire Gem":{"mp":80},"Emerald Gem":{"hp":120},
 "Onyx Gem":{"def":7},"Falcon Gem":{"crit":.025},"Shadow Gem":{"dodge":.02},
 "Rare Gem":{"atk":4,"hp":45}
}
def stats(character,equipped,sockets=None):
 b=dict(CLASS_BASE[character["class_name"]]);lv=int(character["level"]); b["hp"]+=(lv-1)*30;b["mp"]+=(lv-1)*12;b["atk"]+=(lv-1)*4;b["def"]+=lv-1
 b["drop_bonus"]=0.0;b["boss_bonus"]=0.0;b["set_bonus"]=""
 rarity_counts={}; socket_map={}
 for s in sockets or []: socket_map.setdefault(s["slot"],[]).append(s["gem_id"])
 for row in equipped:
  item=EQUIPMENT.get(row["item_id"],{});up=int(row.get("upgrade",0));scale=1.0+up*.06
  for k in ("hp","mp","atk","def"):b[k]+=int(item.get(k,0)*scale)
  rarity=item.get("rarity","Easy"); rarity_counts[rarity]=rarity_counts.get(rarity,0)+1
  rb=RARITY_BONUS.get(rarity,0.0);b["crit"]+=rb*.35;b["drop_bonus"]+=rb*.5;b["boss_bonus"]+=rb*.4
  for gem in socket_map.get(row["slot"],[]):
   for k,v in GEMS.get(gem,{}).items(): b[k]=b.get(k,0)+v
 # Wearing multiple pieces of the same high-end tier creates server-side set bonuses.
 for rarity in ("Relic","Mythic","Legendary"):
  n=rarity_counts.get(rarity,0)
  if n>=2: b["hp"]=int(b["hp"]*1.05);b["set_bonus"]+=f"{rarity}2 "
  if n>=3: b["atk"]=int(b["atk"]*1.06);b["def"]=int(b["def"]*1.06);b["set_bonus"]+=f"{rarity}3 "
  if n>=5: b["crit"]+=.03;b["boss_bonus"]+=.08;b["set_bonus"]+=f"{rarity}5 "
 return b
