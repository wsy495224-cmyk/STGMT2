import os,tempfile
fd,path=tempfile.mkstemp(suffix=".db");os.close(fd)
try:
 from database import DB
 from gameplay import runtime
 from world import World
 d=DB(path);aid,_=d.register("tester20","password123");cid=d.create_character(aid,"Hero20","Blade")
 c=d.character(cid);runtime.enter(c);world=World(d);world.spawn_demo()
 # put close to mob
 d.save_position(cid,8,1,8)
 r=runtime.skill(d,world,cid,"mob_1",0);assert r["ok"] and r["damage"]>0
 d._add(cid,"Crystal Shard",3);d._add(cid,"Gem Fragment",2);d.cx.commit()
 assert d.craft(cid,"upgrade_stone")
 assert d.guild_create(cid,"TestGuild")
 assert d.guild_deposit_gold(cid,10)
 print("v2.0 gameplay authority smoke PASS")
finally:
 try:os.remove(path)
 except OSError:pass
