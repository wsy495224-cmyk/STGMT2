import tempfile,os,time
from database import DB
from world import World
from gameplay import runtime
from world_v21 import populate

def main():
 fd,path=tempfile.mkstemp(suffix='.db');os.close(fd)
 try:
  db=DB(path);aid,_=db.register('v25tester','password123');cid=db.create_character(aid,'BossTester','Blade')
  db.cx.execute("UPDATE characters SET level=35,map_name='Green Valley',x=85,z=85 WHERE id=?",(cid,));db.cx.commit()
  w=World(db);populate(w);rt=runtime.enter(db.character(cid)); boss=next((m for m in w.mobs.values() if m['kind']=='boss' and m['map_name']=='Green Valley'))
  boss['hp']=int(boss['max_hp']*.3);boss['next_special']=0
  ev=w.tick(runtime,.2)
  assert boss.get('phase')==3
  assert any(x['type']=='boss_special' for x in ev),ev
  print('v2.5 boss/phase/AOE smoke PASS')
 finally:
  runtime.leave(cid)
  try:os.unlink(path)
  except:pass
if __name__=='__main__':main()
