Place original STGMT2 production models here.
Expected future structure:
characters/blade, characters/archer, characters/mystic
equipment/weapons, equipment/armor
mounts, monsters, bosses, npcs
vfx, ui, audio

The gameplay code is designed so procedural placeholders can be swapped out.
