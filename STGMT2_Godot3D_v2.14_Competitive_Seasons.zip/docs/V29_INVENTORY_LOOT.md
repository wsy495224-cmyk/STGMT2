# STGMT2 v2.9 — Inventory, Equipment & Loot

- New interactive inventory/equipment panel with item details, equip and potion-use actions.
- Class and level restrictions continue through EquipmentManager.
- Local loot foundation can roll class-appropriate equipment and weighted rarities.
- Boss loot has improved Rare/Legendary odds.
- Added explicit v2.9 drop table data for normal, elite and boss enemies.
- Fixed the known invalid GameState load-game setter syntax.

Server authority remains the target for valuable online rewards. Local loot is for offline/prototype gameplay; online drops must remain server-issued.
