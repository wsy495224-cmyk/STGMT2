# STGMT2 v2.3 — Server AI, Progression & 18 Skills

Added server-owned monster aggro/chase/attacks, player death + safe-zone respawn, timed monster/boss respawns, server XP level-ups, and all 18 original class skills (6 per class). Selected skills now carry server-side slow/stun/bleed status metadata. The server runs a 5 Hz world simulation loop and emits mob attack/respawn/player respawn events.

This is still a development MMO foundation. Monster navigation is straight-line server movement (not navmesh), status damage-over-time is not fully simulated yet, and Godot runtime startup must still be validated in a real Godot 4 environment.
