# STGMT2 v2.14 Competitive Foundation

Adds server-side 1v1/3v3 matchmaking queues, persistent 30-day PvP seasons and season scoring, plus idempotent guild-war winner rewards. This is a development foundation: matchmaking still needs arena allocation, disconnect handling, anti-win-trading rules, ready checks, and client UI/runtime validation.
