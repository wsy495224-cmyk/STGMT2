# STGMT2 Classic MMORPG Control v1.3

Primary control is now mouse-driven:
- Left-click terrain: move to clicked position.
- Left-click enemy/crystal: select it, approach automatically and auto-attack in range.
- Right mouse button + drag: orbit/rotate camera.
- Mouse wheel: zoom.
- Target panel shows selected target and HP.
- Blue click marker gives movement feedback.
- Skills remain on 1–6 and use the selected/nearest combat target logic.
- I inventory, V skills, M mount, O social, J quest claim.
- WASD remains optional as an accessibility/alternate-control option.

This implementation is original code reproducing the familiar classic MMORPG
interaction pattern; it does not contain proprietary Metin2 client code.
