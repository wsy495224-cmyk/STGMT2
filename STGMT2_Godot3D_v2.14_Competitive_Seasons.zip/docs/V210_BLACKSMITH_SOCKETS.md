# STGMT2 v2.10 — Blacksmith, Sockets & Equipment Authority

- Server equipment registry now loads all 75 class-specific equipment entries from `equipment_v12.json`.
- Server equip rules enforce class and minimum level for all registered equipment.
- Refinement is deny-by-default and only registered equipment can be refined.
- +0..+15 refinement retains server-owned chance/cost. +4..+9 requires one Upgrade Stone; +10..+14 requires two.
- Refinement result distinguishes rejected requests (`accepted=false`) from legitimate failed attempts (`accepted=true, success=false`).
- Local Godot blacksmith UI foundation includes refinement chance, sockets (max 3), gem insertion, and rolled bonus foundation.
- Rare Gem and Gem Fragment have original local stat bonus definitions.
- Runtime Godot validation remains pending until a Godot executable is available.
