# STGMT2 v2.1 — PvP, Guild Wars & Server World

Added server-side:
- Equipment slots and equipment-derived stats.
- PvP melee validation with safe zones, distance, cooldown, defense, crit and dodge.
- Death/respawn foundation.
- Seven map authority definitions with level progression, bounds and safe zones.
- Server-owned population definitions for all seven maps (12 normal mobs + boss per map).
- Movement speed validation, map bounds and client position correction.
- Guild invitations, Master/Officer/Member permissions.
- Guild-bank withdrawal restricted to Master/Officer.
- Guild-war creation and kill scoring.
- Random reconnect/session bearer tokens stored only as SHA-256 hashes server-side.
- Godot networking API expanded for equipment, PvP, guild permissions and wars.

Still not production-complete:
- Godot runtime parse/startup has not been validated here because no Godot executable is installed.
- PvP skills/status effects and ranged projectile authority need expansion.
- Server mob AI/pathfinding/respawns need a continuous simulation loop.
- Guild-war matchmaking/end conditions/rewards need completion.
- Session tokens need secure local client storage and TLS transport in deployment.
- Production database, migrations, backups, monitoring, rate limiting and load testing remain.
