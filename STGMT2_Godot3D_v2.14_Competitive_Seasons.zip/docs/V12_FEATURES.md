# STGMT2 Godot 3D v1.2 — Social, Economy & Quest Expansion

## Added
- 10-step quest progression covering hunting, crystals, collecting, bosses,
  refinement, dungeon, arena and tournament goals.
- 8 specialized merchants: general goods, armor, weapons, alchemy, mounts,
  gems, cosmetics and travel.
- 75 class-specific equipment entries across five progression categories:
  Easy/Starter, Common, Medium/Advanced, Rare and Legendary.
- Six mount types from starter horse to legendary drake/stag.
- HP/MP potions plus combat elixirs.
- Merchant buy/sell and player-trade API foundation.
- Friend request, friend list, block list and whisper API foundation.
- Social UI foundation.
- Quest claim system.
- Mount summon/dismiss with movement-speed modifier.

## Important multiplayer boundary
Whispering, friend requests and player-to-player trading cannot honestly be
called online multiplayer until an authoritative network server and accounts
exist. v1.2 provides the client/data APIs and UI model so the future server can
own and validate those actions.
