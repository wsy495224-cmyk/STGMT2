# STGMT2 v2.4 — World, Dungeon & Ranking

Server-authoritative foundations added for connected portals across all seven maps, minimum-level travel checks, leaderboard queries, party-sized dungeon instances, boss phase calculation, and status-effect ticking helpers.

Security rules: clients request destinations/actions; the server validates adjacency and level. Leaderboards are read from server data. Dungeon membership is server-owned.

Current limitation: this is backend/gameplay foundation. The seven maps still need final Godot scenes/art, dungeon scene presentation, and full runtime/UI validation in Godot.
