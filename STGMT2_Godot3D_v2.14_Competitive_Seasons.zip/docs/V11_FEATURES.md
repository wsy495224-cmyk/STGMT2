# STGMT2 Godot 3D v1.1

Integrated systems added in this pass:
- Six active skills per class with MP, range and cooldown data
- Skill casting from keys 1–6
- Class stat/equipment application service
- Inventory/equipment overlay
- Skill overlay
- Achievements, titles and monster codex logic
- Warehouse deposit/withdraw logic
- Crafting recipes
- Dedicated equipment database for Blade / Archer / Mystic
- Existing +15 blacksmith, quests, loot, crystals, boss, arena, dungeon and save/load remain

Controls:
WASD move
SPACE normal attack
1–6 skills
E interact / loot
Q HP potion
I inventory/equipment
K skill panel
P arena
F5/F9 save/load
