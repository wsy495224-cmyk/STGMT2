# STGMT2 v1.8 — Online Foundation

Added a dependency-free Python authoritative-server foundation and a Godot TCP
client layer.

Server:
- SQLite persistent accounts and characters.
- PBKDF2-SHA256 salted password hashing.
- Register/login.
- Three-class character creation.
- Character persistence.
- Enter-world session.
- Player join/leave/movement replication.
- Global chat and direct whisper routing.
- Database tables prepared for friendships, mail and market.
- Basic movement rate limiting and coordinate bounds.

Godot client:
- Login/register/character-selection UI.
- TCP JSON-line protocol.
- Remote player spawning and movement interpolation.
- Existing class visuals applied after character login.
- Movement replication at 10 updates/second.

Run local server:
Windows: server_py/run_server.bat
macOS/Linux: server_py/run_server.sh

This is an online-development foundation, NOT a production Internet MMO server.
Before public deployment it still needs TLS/reverse proxy, server-side combat,
inventory/economy authority, robust validation, migrations/backups, moderation,
rate limits, observability, load tests and hardened deployment.
