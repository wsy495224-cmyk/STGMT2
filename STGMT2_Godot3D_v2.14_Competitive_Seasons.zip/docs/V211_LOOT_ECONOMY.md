# STGMT2 v2.11 — Loot & Economy
- Server-side rarity rolls: Common, Medium, Rare, Legendary, Mythic, Relic.
- Bosses have improved high-rarity weighting.
- Mythic Essence and Relic Core are server-only boss reward materials.
- Market charges a 3% seller tax on completed purchases.
- Listings expire from browsing after 7 days.
- Sellers can cancel active listings and recover remaining items.
- Unknown item IDs remain denied by the server whitelist.
