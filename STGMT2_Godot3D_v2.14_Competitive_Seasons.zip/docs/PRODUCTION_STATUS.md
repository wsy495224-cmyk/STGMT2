# STGMT2 production status

## Playable vertical slice included
- Third-person 3D movement and camera
- Village blockout, arena and combat field
- Three original classes in the data model
- Seven-map progression database
- Enemy chase AI and boss combat
- STG crystal targets
- Physical loot pickup
- XP, levels, gold, HP and attack progression
- Inventory state
- Equipment state
- Weapon refinement +0..+15
- Merchant purchase
- NPC interaction
- Quest chain
- Arena/rating foundation
- Dungeon encounter foundation
- Save/load
- Existing v0.8 databases for costumes, equipment, drops, NPCs, arenas, skill trees, dungeons and systems

## Production-scale work that still requires an actual art/network pipeline
A commercial MMORPG is not "finished" by a code ZIP. Remaining production work
includes original rigged hero models, hundreds of animations/VFX/audio assets,
seven production maps, full UI art, multiplayer authoritative server,
accounts/database, guild persistence, chat, matchmaking, patcher, anti-cheat,
QA, balancing, localization, deployment and live operations.

The project is intentionally structured so those layers can replace the
placeholders without discarding the gameplay design.
