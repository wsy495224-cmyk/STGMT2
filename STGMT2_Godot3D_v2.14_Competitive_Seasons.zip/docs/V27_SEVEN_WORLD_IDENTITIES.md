# STGMT2 v2.7 — Seven World Identities

This release adds an original procedural visual identity layer for all seven maps, visible portal objects, local/offline portal traversal fallback, server portal request integration, and a player-centered minimap with portal markers.

Map identities:
- Green Valley: green woodland and stone gate landmark.
- Red Dunes: warm desert palette and ruined pillars.
- Mist Forest: dark woodland and ancient tree landmark.
- Frozen Pass: ice palette and crystal formations.
- Sunset Ruins: sunset palette and broken monumental gate.
- Dark Marsh: dark wetland pools and muted vegetation.
- Sky Plateau: cool highland palette and elevated shrine platform.

All visuals are generated from Godot primitives and original code. No Metin2 proprietary assets are included.
