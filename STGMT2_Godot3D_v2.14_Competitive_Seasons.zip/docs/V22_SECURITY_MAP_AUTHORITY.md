# STGMT2 v2.2 — Map Authority & Security Hardening

- World snapshots are filtered to the active character map.
- Basic attacks reject mobs on another map.
- Skills reject mobs on another map.
- Market listings deny unknown item IDs by default.
- Refinement now rejects non-equipment/unknown items.
- Godot runtime validation remains pending because no Godot executable is available in the build environment.
