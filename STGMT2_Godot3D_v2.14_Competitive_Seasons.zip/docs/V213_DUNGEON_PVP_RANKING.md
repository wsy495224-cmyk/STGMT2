# STGMT2 v2.13 — Dungeon, PvP & Ranking

- Seven server-side dungeon reward profiles tied to the seven world maps.
- Idempotent dungeon reward claims: one claim per character per run.
- Endgame rewards include Upgrade Stones, Rare Gems, Legendary Fragments, Mythic Essence and Relic Cores.
- Persistent PvP kills/deaths/rating foundation.
- PvP and Guild leaderboard query foundations.
- This is server-authoritative foundation code; production matchmaking, seasonal resets, anti-win-trading and full party instance networking remain future work.
