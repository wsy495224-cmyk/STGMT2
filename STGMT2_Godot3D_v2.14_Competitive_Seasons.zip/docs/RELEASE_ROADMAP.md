# Road to a public alpha

## Client
Replace primitive meshes with verified free CC0 models; retarget animations;
add hit/VFX/audio; build seven production maps; add complete menus/tooltips.

## Gameplay
Wire all skill-tree nodes, item rarity/affixes, sockets/gems, pets/mounts,
crafting, fishing, alchemy, guild UI, event scheduler and full dungeon rules.

## Multiplayer
Authoritative server; account/login; character persistence; chat/party/guild;
instance service; arena matchmaking; transaction ledger; anti-duplication;
server-side damage/drop/refinement validation.

## Shipping
Launcher/patching, crash logs, accessibility, localization, performance tiers,
automated tests, moderation/admin tools, backups and deployment.
