# STGMT2 v2.5 — Boss Combat & Guild War Rules

This release deepens the authoritative combat simulation without proprietary Metin2 content.

- Seven map bosses now have three server-controlled HP phases.
- Bosses execute original map-themed AoE specials; phase 3 is the enrage phase with shorter special cooldowns.
- Specials apply server-owned damage and status effects and use the existing safe respawn flow on player death.
- Guild-war rules define a 10-kill target and a 15-minute maximum duration, with a reusable state resolver.
- Existing party-dungeon and PvP foundations remain compatible with the authoritative server model.

Production caveat: this is still a development server. TLS, persistent dungeon instances, guild-war acceptance/rewards/audit logs, load testing and full Godot runtime validation remain required.
