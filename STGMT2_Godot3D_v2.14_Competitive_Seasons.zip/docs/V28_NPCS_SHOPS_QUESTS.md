# STGMT2 v2.8 — NPCs, Shops & Regional Life

Adds original regional NPC populations across all seven worlds, a reusable NPC interaction window, role-based shops, blacksmith interaction, warehouse foundation, skill/alchemy/mount vendors, and repeatable local assignments. All names/dialogue/content are original placeholders and no proprietary Metin2 assets are included.

This remains a development build. Godot runtime validation is required before claiming the client is release-ready.
