# STGMT2 v1.7 — World & Community Systems

Added:
- Pet collection, summon, leveling and passive bonuses.
- Party foundation (5 players, leader, loot modes).
- Guild foundation (levels, treasury, members, research branches).
- Crafting, alchemy, gathering and fishing foundations.
- Mailbox with gold/item attachments.
- Five world-event definitions and runtime event manager.
- Community UI panels.
- Visible procedural companion pet.
- Pet XP from combat.

Keys:
G Guild, P Party, C Crafting, L Mail, N Events, F Fishing, H Gathering.
Existing: T Skill Tree, B Market, classic mouse movement/targeting.

Online party/guild/mail/event synchronization still requires the authoritative
server/database phase. These modules define the gameplay/data layer first.
