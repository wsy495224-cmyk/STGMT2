# Free-first asset policy

1. Build gameplay/code/procedural placeholders ourselves whenever practical.
2. Only add external assets whose license is verified and compatible with the project.
3. Keep a source/license record for every external asset.
4. Never copy proprietary Metin2 models, maps, textures, sounds, quests or code.
5. Prefer CC0/public-domain style resources for production where possible.
6. External assets belong in assets/free_external and must have a LICENSE_SOURCE.txt beside them.

Current v0.1 deliberately contains no third-party art: terrain, arena, NPCs,
player, enemies and drops are generated from Godot primitives/materials.
