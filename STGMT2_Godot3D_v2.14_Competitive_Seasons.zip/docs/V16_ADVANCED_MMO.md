# STGMT2 v1.6 Advanced MMORPG Systems

This pass adds the requested missing pillars:
- Skill mastery: each active skill can level 1–20 by use.
- Expanded class skill trees with prerequisites and passive bonuses.
- Player market / auction-house data model.
- Minimap with player, monsters and STG Crystals.
- Daily missions, bounty board and reputation.
- Socket/gem and collection foundations.
- Advanced UI panels for skill tree and market.
- Keys: T skill tree, B market.

Also preserved: classic mouse control, equipment, rarity, +15, merchants,
quests, mounts, potions, social, trade, arenas, dungeons, bosses, combat polish.

The feature matrix separates systems already built from the work that genuinely
requires production art and/or a real authoritative online server.
