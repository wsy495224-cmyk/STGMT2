# v1.4 Combat & Presentation Pass

Added:
- Floating damage numbers.
- Critical-hit presentation and multiplier.
- World-space enemy and STG Crystal health bars.
- Glowing target-selection ring.
- Hit flash VFX.
- Rarity-colored loot labels.
- HUD HP and MP bars.
- Animation state abstraction for future rigged characters.
- Audio event API prepared for original/verified CC0 sound.
- Classic click-to-move / click-to-target controls remain primary.

This pass intentionally does not bundle random web audio/models. Production
assets will only be imported after their license and source are recorded.
