# STGMT2 v2.0 — Authoritative Gameplay

Server authority expanded to:
- Skills: server validates class skill, range, mana and cooldown.
- Critical chance and skill damage are calculated by server.
- Runtime HP/MP and MP regeneration foundation.
- Server-controlled mob death rewards.
- Server quest progress and reward claims.
- Server crafting recipes and material consumption.
- Transactional player-to-player trade foundation with two-party acceptance.
- Persistent guild creation, treasury and guild-bank deposits.
- Existing server-authoritative inventory, gold, refinement, market and mail.

Important remaining production work:
- Replace demo world mobs with complete server-owned map populations.
- Equipment-derived server stats and status-effect simulation.
- Player-vs-player combat and safe-zone rules.
- Guild invitations/ranks/withdrawal permissions/wars.
- Trade cancellation/timeouts and both-party completion notifications.
- Server navigation and stronger movement reconciliation.
- Reconnect/session tokens, TLS deployment, production DB, monitoring and load tests.
