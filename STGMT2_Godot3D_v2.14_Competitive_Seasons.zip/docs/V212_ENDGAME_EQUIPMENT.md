# STGMT2 v2.12 — Endgame Equipment

- 30 new server-authoritative Mythic/Relic equipment variants: 3 classes × 5 slots × 2 tiers.
- High-end same-rarity set bonuses at 2/3/5 equipped pieces.
- Three server-owned socket positions per equipped slot.
- Gems now alter authoritative HP/MP/ATK/DEF/crit/dodge stats.
- Added six specialized gems plus backwards-compatible Rare Gem.
- Restored compatibility for the legacy `Iron Vanguard` server test fixture.
- Clients cannot invent gem effects; the server consumes the gem and calculates final stats.
