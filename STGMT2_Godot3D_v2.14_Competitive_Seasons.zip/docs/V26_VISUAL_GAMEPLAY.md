# STGMT2 v2.6 — Visual Gameplay Foundation

This release upgrades the original procedural client presentation without bundling copyrighted or third-party game assets.

- Original class silhouettes with visible Blade / Bow / Staff identity.
- Improved procedural enemy and boss silhouettes.
- Expanded village dressing, lamps, ruins and lighting helpers.
- New cleaner MMO HUD foundation and six-slot skill hotbar.
- Lightweight procedural movement animation foundation.
- Existing server-authoritative v2.5 systems remain included.

Important: these are still procedural prototype visuals, not final production character art or animation assets. Godot runtime validation requires a Godot 4 executable and was not available in the build environment.
