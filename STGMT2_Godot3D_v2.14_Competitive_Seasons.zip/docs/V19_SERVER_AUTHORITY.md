# STGMT2 v1.9 — Server Authority

The valuable economy/combat actions have started moving away from client trust.

Implemented server-side:
- Inventory persisted in SQLite.
- Gold wallet persisted in SQLite.
- Server-selected monster drops and XP/gold rewards.
- Server-side combat damage calculation + range validation for server mobs.
- +0..+15 refinement success/cost/downgrade controlled by server.
- Transactional market listing and buying.
- Transactional mail attachments and one-time claim.
- Client cannot submit arbitrary damage, drop rewards, refinement success or
  arbitrary gold values for these actions.
- Server-authority Godot bridge keeps a read model of inventory/gold/mobs.

Still required before public production:
- Make ALL spawned game monsters server entities, not only authority-demo mobs.
- Server-side skill cooldown/mana/status/crit/dodge calculations.
- Server-side equipment stats, quests, crafting, guild banks and player trades.
- Movement speed/navmesh/teleport validation and reconciliation.
- Authentication session tokens/reconnect handling.
- TLS at deployment edge, secrets/config management, database migrations/backups.
- PostgreSQL or equivalent production database architecture.
- Abuse/rate limiting, logs, admin/moderation, metrics, load tests.
- Do not expose the included development TCP server directly to the Internet.
