# Zero-budget production plan

Use self-built code and procedural placeholders first.
Only import external assets after checking their current license.
Preferred pool: CC0 assets from Quaternius, Kenney, Poly Haven and ambientCG.
Keep each external asset's source/license beside the imported files.

Priority:
1. Rigged humanoid + animation retargeting.
2. Medieval village/environment kit.
3. PBR ground/stone/wood materials.
4. Original class silhouettes, weapons and armor variants.
5. Monster families and bosses.
6. VFX/audio/UI.
7. Multiplayer backend after the single-player combat vertical slice is stable.
