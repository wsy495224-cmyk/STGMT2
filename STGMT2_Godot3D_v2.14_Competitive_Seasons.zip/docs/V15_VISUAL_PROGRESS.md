# v1.5 Visual Equipment & Mount Pass

Added:
- Procedural visible class armor, helmet and weapon.
- Blade gets sword silhouette, Archer bow silhouette, Mystic staff silhouette.
- Visible procedural starter mount under the player.
- Mount leveling/training foundation (level 1–20).
- Equipment stat manager with class/level restrictions.
- 8 monster-family definitions across the seven-map progression.
- 7 boss definitions with increasing phases/rewards.
- Procedural trees and rocks to make the test world less empty.
- Existing classic mouse controls, combat polish, quests, merchants, social,
  trading, mounts, potions and 75-item equipment progression remain.

The procedural meshes are deliberately placeholders. They allow gameplay,
equipment visibility and mount logic to be developed without paying for art.
They can later be replaced by original or verified-free rigged models.
