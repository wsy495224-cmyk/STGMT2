# STGMT2 Godot 3D v2.13 — Dungeon / PvP / Ranking

STGMT2 Godot3D v2.6 — Visual Gameplay Foundation

# STGMT2 Godot 3D v2.4 — World / Dungeons / Ranking

STGMT2 Godot 3D v2.3 — Server AI, Progression & 18 Skills

# STGMT2 Godot 3D v1.7 — World & Community Systems

This version expands the MMORPG layer with pets, party, guilds, crafting,
alchemy, fishing, gathering, mail and world events while preserving the
classic mouse-control combat, skill mastery/tree, minimap, market, quests,
merchants, equipment, mounts and combat polish.

Open `project.godot` in Godot 4.

Important: social/economy systems are currently local gameplay foundations.
A production MMORPG requires the next authoritative server + account/database
phase before they can safely synchronize between real players.

## v2.5
Server-authoritative three-phase bosses, original AoE boss specials/status effects, enrage timing, and formal guild-war win/time rules. See `docs/V25_BOSS_PVP_GUILD.md`.

## v2.8 — NPCs, Shops & Regional Life
- Regional NPC populations for all seven worlds.
- Reusable NPC dialogue and interaction UI.
- Merchant, Alchemist, Skill Master and Mount shops.
- Blacksmith and warehouse interaction foundations.
- Local quest assignment flow.

## v2.9
Interactive inventory/equipment foundation, potion use, weighted class equipment loot, boss rarity bonuses, and a GameState load syntax repair.


## v2.11
Server-authoritative rarity loot and safer market economy: Mythic/Relic reward materials, 3% market tax, 7-day listing visibility, seller cancellation.

## v2.12 Endgame Equipment
Adds server-authoritative Mythic/Relic gear, 2/3/5-piece set bonuses and stat-bearing equipment sockets/gems. See `docs/V212_ENDGAME_EQUIPMENT.md`.


## v2.13
See `docs/V213_DUNGEON_PVP_RANKING.md`.

## v2.14 Competitive Foundation
Server-side 1v1/3v3 matchmaking queue, persistent PvP seasons/leaderboards, and one-time guild-war winner rewards. Godot runtime validation is still pending.
