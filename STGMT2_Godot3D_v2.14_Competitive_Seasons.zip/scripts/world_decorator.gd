extends Node
func mat(c):
	var m=StandardMaterial3D.new();m.albedo_color=c;m.roughness=.9;return m
func tree(parent,pos):
	var trunk=MeshInstance3D.new();var c=CylinderMesh.new();c.top_radius=.18;c.bottom_radius=.25;c.height=2.5;trunk.mesh=c;trunk.position=pos+Vector3(0,1.25,0);trunk.material_override=mat(Color("#65452e"));parent.add_child(trunk)
	var crown=MeshInstance3D.new();var s=SphereMesh.new();s.radius=1.1;s.height=2.0;crown.mesh=s;crown.position=pos+Vector3(0,3,0);crown.material_override=mat(Color("#3e703b"));parent.add_child(crown)
func rock(parent,pos,scale=1.0):
	var m=MeshInstance3D.new();var s=SphereMesh.new();s.radius=.65*scale;s.height=1.1*scale;m.mesh=s;m.position=pos;m.scale=Vector3(1.3,.8,1);m.material_override=mat(Color("#666a69"));parent.add_child(m)
func decorate(parent):
	var rng=RandomNumberGenerator.new();rng.seed=8182
	for i in range(34):tree(parent,Vector3(rng.randf_range(-39,39),0,rng.randf_range(-39,39)))
	for i in range(22):rock(parent,Vector3(rng.randf_range(-40,40),.45,rng.randf_range(-40,40)),rng.randf_range(.6,1.5))
