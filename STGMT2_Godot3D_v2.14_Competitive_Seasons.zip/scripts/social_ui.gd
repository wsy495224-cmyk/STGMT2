extends CanvasLayer
var box
var edit
func _ready():
	box=Panel.new();box.position=Vector2(300,120);box.size=Vector2(650,430);box.visible=false;add_child(box)
	var title=Label.new();title.text="STGMT2 Social / Trade";title.position=Vector2(20,15);title.add_theme_font_size_override("font_size",25);box.add_child(title)
	edit=LineEdit.new();edit.position=Vector2(20,65);edit.size=Vector2(400,38);edit.placeholder_text="Player name or whisper message";box.add_child(edit)
	var info=Label.new();info.name="Info";info.position=Vector2(20,120);info.size=Vector2(600,260);box.add_child(info)
func toggle():
	box.visible=!box.visible;refresh()
func refresh():
	var x=box.get_node("Info")
	x.text="Friends: %s\nPending: %s\n\nWhispers stored: %d\n\nNetwork note:\nFriend requests, whispers and player-to-player trading are implemented as a local data/API layer. In the MMORPG server build these actions must be validated and delivered by the authoritative server."%[", ".join(SocialSystem.friends),", ".join(SocialSystem.pending),SocialSystem.whispers.size()]
