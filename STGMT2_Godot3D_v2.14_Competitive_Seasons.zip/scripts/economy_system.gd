extends Node
var warehouse={}
var recipes={
	"Greater HP Potion":{"HP Potion":3,"Crystal Shard":1},
	"Polished Gem":{"Gem Fragment":5},
	"Upgrade Stone":{"Crystal Shard":3}
}
func deposit(item,count=1):
	if GameState.inventory.get(item,0)<count:return false
	GameState.inventory[item]-=count;warehouse[item]=warehouse.get(item,0)+count;return true
func withdraw(item,count=1):
	if warehouse.get(item,0)<count:return false
	warehouse[item]-=count;GameState.add_item(item,count);return true
func craft(name):
	if not recipes.has(name):return false
	for k in recipes[name]:
		if GameState.inventory.get(k,0)<recipes[name][k]:return false
	for k in recipes[name]:GameState.inventory[k]-=recipes[name][k]
	GameState.add_item(name);return true
