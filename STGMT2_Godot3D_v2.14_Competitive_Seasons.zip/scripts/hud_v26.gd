extends Control

var game
var panel: PanelContainer
var stats: Label
var target: Label
var quest: Label
var hotbar: HBoxContainer

func setup(g) -> void:
	game = g
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel = PanelContainer.new(); panel.position = Vector2(18, 18); panel.size = Vector2(390, 128); add_child(panel)
	var vb := VBoxContainer.new(); panel.add_child(vb)
	stats = Label.new(); stats.add_theme_font_size_override("font_size", 18); vb.add_child(stats)
	quest = Label.new(); quest.add_theme_font_size_override("font_size", 15); vb.add_child(quest)
	target = Label.new(); target.position = Vector2(465, 18); target.size = Vector2(360, 54); target.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; target.add_theme_font_size_override("font_size", 19); add_child(target)
	hotbar = HBoxContainer.new(); hotbar.position = Vector2(430, 620); add_child(hotbar)
	for i in range(6):
		var b := Button.new(); b.text = str(i + 1); b.custom_minimum_size = Vector2(58, 48); b.mouse_filter = Control.MOUSE_FILTER_IGNORE; hotbar.add_child(b)

func refresh() -> void:
	if not game or not game.player: return
	stats.text = "STGMT2   Lv.%d   HP %d/%d   MP %d/%d\nGold %d   ATK %d   Arena %d" % [GameState.level, GameState.hp, GameState.max_hp, GameState.mp, GameState.max_mp, GameState.gold, GameState.attack, GameState.arena_rating]
	quest.text = "Quest: %s  %d/%d" % [game.quest.name, game.quest.progress, game.quest.need]
	if game.selected_target and is_instance_valid(game.selected_target): target.text = "TARGET  •  %s" % game.selected_target.name
	else: target.text = ""
