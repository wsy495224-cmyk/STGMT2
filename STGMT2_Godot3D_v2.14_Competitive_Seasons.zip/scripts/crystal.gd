extends StaticBody3D
var game
var hp=180
var hpbar
func _ready():
	hpbar=load("res://scripts/world_healthbar.gd").new();hpbar.position=Vector3(0,2.2,0);add_child(hpbar);hpbar.setup(hp)
func damage(n):
	hp-=n
	if hpbar:hpbar.update_hp(hp)
	CombatVFX.hit_flash(get_parent(),global_position,Color("#bd68ff"))
	if hp<=0:game.crystal_defeated(self);queue_free()
