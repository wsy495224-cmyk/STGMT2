extends Node
var classes={}
func _ready():
	var f=FileAccess.open("res://data/game_database.json",FileAccess.READ)
	var d=JSON.parse_string(f.get_as_text());classes=d.classes
func apply_class(c):
	if not classes.has(c):return false
	var d=classes[c];GameState.class_name=c;GameState.max_hp=int(d.hp);GameState.hp=GameState.max_hp
	GameState.max_mp=int(d.mp);GameState.mp=GameState.max_mp;GameState.attack=int(d.attack);GameState.defense=int(d.defense)
	if c=="Blade":GameState.equipment.weapon="Iron Vanguard"
	elif c=="Archer":GameState.equipment.weapon="Hunter Longbow"
	else:GameState.equipment.weapon="Runic Staff"
	return true
