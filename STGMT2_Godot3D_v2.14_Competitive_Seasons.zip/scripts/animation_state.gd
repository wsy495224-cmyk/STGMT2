extends Node
enum State {IDLE,RUN,ATTACK,SKILL,HIT,DEAD,MOUNT}
var state=State.IDLE
var animation_player
func bind(root):
	animation_player=root.find_child("AnimationPlayer",true,false)
func set_state(s):
	if state==s:return
	state=s
	if not animation_player:return
	var map={State.IDLE:"Idle",State.RUN:"Run",State.ATTACK:"Attack",State.SKILL:"Skill",State.HIT:"Hit",State.DEAD:"Death",State.MOUNT:"Mounted"}
	var a=map.get(s,"")
	if a!="" and animation_player.has_animation(a):animation_player.play(a)
