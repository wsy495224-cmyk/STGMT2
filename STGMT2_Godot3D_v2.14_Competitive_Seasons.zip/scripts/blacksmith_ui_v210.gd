extends CanvasLayer
var panel:Panel;var item_list:ItemList;var info:RichTextLabel;var selected:=""
func _ready():
	panel=Panel.new();panel.position=Vector2(180,100);panel.size=Vector2(650,500);panel.visible=false;add_child(panel)
	var title=Label.new();title.text="Blacksmith • Refinement +0 → +15";title.position=Vector2(22,18);title.add_theme_font_size_override("font_size",24);panel.add_child(title)
	item_list=ItemList.new();item_list.position=Vector2(22,65);item_list.size=Vector2(285,330);item_list.item_selected.connect(_pick);panel.add_child(item_list)
	info=RichTextLabel.new();info.bbcode_enabled=true;info.position=Vector2(330,65);info.size=Vector2(290,245);panel.add_child(info)
	var refine=Button.new();refine.text="Refine";refine.position=Vector2(330,330);refine.size=Vector2(135,44);refine.pressed.connect(_refine);panel.add_child(refine)
	var socket=Button.new();socket.text="Add Socket";socket.position=Vector2(480,330);socket.size=Vector2(135,44);socket.pressed.connect(_socket);panel.add_child(socket)
	var gem=Button.new();gem.text="Insert Rare Gem";gem.position=Vector2(330,385);gem.size=Vector2(285,44);gem.pressed.connect(_gem);panel.add_child(gem)
func toggle():panel.visible=not panel.visible;if panel.visible:refresh()
func refresh():
	item_list.clear()
	for n in GameState.inventory:
		if int(GameState.inventory[n])>0 and not EquipmentManager.item_by_name(str(n)).is_empty():item_list.add_item(str(n)+" +"+str(GameState.upgrade_levels.get(n,0)))
	info.text="Select equipment. +4 and above require Upgrade Stones.\nOnline mode sends refinement to the authoritative server."
func _pick(i:int):selected=item_list.get_item_text(i).rsplit(" +",true,1)[0];_show()
func _show():
	if selected=="":return
	var up=int(GameState.upgrade_levels.get(selected,0));var chance=[100,100,95,90,82,74,66,58,50,42,34,27,20,14,9][min(up,14)]
	info.text="[b]%s +%d[/b]\nSuccess: %d%%\nSockets: %d/3\nGems: %s\nBonus: %s"%[selected,up,chance,int(ItemCustomization.sockets.get(selected,0)),str(ItemCustomization.gems.get(selected,[])),str(ItemCustomization.bonuses.get(selected,{}))]
func _refine():
	if selected=="":return
	var up=int(GameState.upgrade_levels.get(selected,0));if up>=15:return
	if NetworkClient.connected_ok:ServerAuthority.refine(selected,up);return
	var cost=100+up*up*55;var stones=0 if up<4 else (1 if up<10 else 2)
	if GameState.gold<cost or int(GameState.inventory.get("Upgrade Stone",0))<stones:return
	GameState.gold-=cost;GameState.inventory["Upgrade Stone"]=int(GameState.inventory.get("Upgrade Stone",0))-stones
	var chance=[1.0,1.0,.95,.90,.82,.74,.66,.58,.50,.42,.34,.27,.20,.14,.09][up]
	var success=randf()<chance;GameState.upgrade_levels[selected]=up+1 if success else (up if up<5 else max(0,up-1));_show()
func _socket():if selected!="" and ItemCustomization.add_socket(selected):_show()
func _gem():if selected!="" and ItemCustomization.insert_gem(selected,"Rare Gem"):_show()
