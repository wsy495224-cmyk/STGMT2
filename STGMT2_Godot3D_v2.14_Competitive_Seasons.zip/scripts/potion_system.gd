extends Node
var potions=[]
var cooldowns={}
func _ready():
	var f=FileAccess.open("res://data/potions_v12.json",FileAccess.READ);potions=JSON.parse_string(f.get_as_text())
func use(name):
	var p={}
	for x in potions:
		if x.name==name:p=x;break
	if p.is_empty() or GameState.inventory.get(name,0)<1:return false
	var now=Time.get_ticks_msec()/1000.0
	if now<cooldowns.get(name,0.0):return false
	GameState.inventory[name]-=1;cooldowns[name]=now+float(p.get("cooldown",1))
	if p.effect=="heal":GameState.hp=min(GameState.max_hp,GameState.hp+int(p.value))
	elif p.effect=="mana":GameState.mp=min(GameState.max_mp,GameState.mp+int(p.value))
	return true
