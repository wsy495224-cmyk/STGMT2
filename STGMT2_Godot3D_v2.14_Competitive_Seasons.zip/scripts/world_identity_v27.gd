extends Node3D

var game
var root: Node3D
var current_map := "Green Valley"

const THEMES = {
    "Green Valley": {"ground": Color("#4f7744"), "accent": Color("#8bcf72"), "sky": Color("#83a9bc"), "prop":"tree"},
    "Red Dunes": {"ground": Color("#9b6842"), "accent": Color("#e0a35b"), "sky": Color("#dca77a"), "prop":"pillar"},
    "Mist Forest": {"ground": Color("#35584a"), "accent": Color("#78a58a"), "sky": Color("#6f8f8c"), "prop":"tree"},
    "Frozen Pass": {"ground": Color("#b9d2d8"), "accent": Color("#dff6ff"), "sky": Color("#9ec4d8"), "prop":"crystal"},
    "Sunset Ruins": {"ground": Color("#765747"), "accent": Color("#e17b55"), "sky": Color("#d37c62"), "prop":"pillar"},
    "Dark Marsh": {"ground": Color("#33483c"), "accent": Color("#75905f"), "sky": Color("#526b61"), "prop":"marsh"},
    "Sky Plateau": {"ground": Color("#71867f"), "accent": Color("#b9d7d3"), "sky": Color("#7fa6bd"), "prop":"crystal"}
}

func setup(owner_game):
    game = owner_game
    root = Node3D.new()
    root.name = "WorldIdentityV27"
    add_child(root)
    apply_map("Green Valley")

func material(color: Color) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.82
    return m

func add_box(pos: Vector3, size: Vector3, color: Color):
    var mi = MeshInstance3D.new()
    var mesh = BoxMesh.new()
    mesh.size = size
    mi.mesh = mesh
    mi.material_override = material(color)
    mi.position = pos
    root.add_child(mi)

func add_crystal(pos: Vector3, color: Color):
    var mi = MeshInstance3D.new()
    var mesh = PrismMesh.new()
    mesh.size = Vector3(1.3, 3.8, 1.3)
    mi.mesh = mesh
    mi.material_override = material(color)
    mi.position = pos
    mi.rotation_degrees.y = pos.x * 7.0
    root.add_child(mi)

func apply_map(map_name: String):
    current_map = map_name if THEMES.has(map_name) else "Green Valley"
    for child in root.get_children():
        child.queue_free()
    var theme = THEMES[current_map]
    var env = game.get_node_or_null("WorldEnvironment")
    if env and env.environment:
        env.environment.background_color = theme["sky"]
        env.environment.ambient_light_color = theme["accent"].lightened(0.35)
    add_box(Vector3(0,-0.42,0), Vector3(88,0.12,88), theme["ground"])
    for i in range(22):
        var angle = TAU * float(i) / 22.0
        var radius = 28.0 + float((i * 11) % 14)
        var p = Vector3(cos(angle)*radius, 1.0, sin(angle)*radius)
        match theme["prop"]:
            "tree":
                add_box(p, Vector3(0.7,3.5,0.7), Color("#5b4735"))
                add_box(p+Vector3(0,2.5,0), Vector3(2.8,2.2,2.8), theme["accent"])
            "pillar":
                add_box(p, Vector3(1.4,4.5+float(i%3),1.4), theme["accent"].darkened(0.25))
            "crystal": add_crystal(p, theme["accent"])
            "marsh":
                add_box(p-Vector3(0,0.8,0), Vector3(4.5,0.15,3.2), theme["accent"].darkened(0.3))
    _landmark(theme)

func _landmark(theme):
    match current_map:
        "Green Valley":
            add_box(Vector3(0,2,-34), Vector3(9,4,2), theme["accent"].darkened(0.25))
        "Red Dunes":
            for x in [-8,0,8]: add_box(Vector3(x,3,-34), Vector3(3,6,3), theme["accent"].darkened(0.2))
        "Mist Forest":
            add_box(Vector3(0,3,-34), Vector3(3,7,3), Color("#4b3c30"))
            add_box(Vector3(0,7,-34), Vector3(9,4,9), theme["accent"])
        "Frozen Pass":
            for x in [-6,0,6]: add_crystal(Vector3(x,2,-34), theme["accent"])
        "Sunset Ruins":
            add_box(Vector3(-6,3,-34), Vector3(2,7,2), theme["accent"])
            add_box(Vector3(6,3,-34), Vector3(2,7,2), theme["accent"])
            add_box(Vector3(0,6,-34), Vector3(14,2,2), theme["accent"])
        "Dark Marsh":
            add_box(Vector3(0,0.1,-34), Vector3(18,0.2,10), Color("#263f38"))
        "Sky Plateau":
            add_box(Vector3(0,2,-34), Vector3(14,1,14), theme["accent"].lightened(0.1))
