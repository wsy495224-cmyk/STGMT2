extends Label3D
var rarity="Common"
func setup(item,rar="Common"):
	rarity=rar;text=item
	font_size=28;billboard=BaseMaterial3D.BILLBOARD_ENABLED
	var colors={"Easy":"#d0d0d0","Common":"#f2f2f2","Medium":"#58b7ff","Rare":"#bd68ff","Legendary":"#ffb52e"}
	modulate=Color(colors.get(rar,"#f2f2f2"))
func _process(delta):
	rotation.y+=delta*.12
