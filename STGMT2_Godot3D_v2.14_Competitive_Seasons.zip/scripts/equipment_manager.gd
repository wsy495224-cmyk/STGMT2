extends Node
var items=[]
var rarity_mult={"Easy":1.0,"Common":1.15,"Medium":1.35,"Rare":1.7,"Legendary":2.25}
func _ready():
	var f=FileAccess.open("res://data/equipment_v12.json",FileAccess.READ);items=JSON.parse_string(f.get_as_text())
func item_by_name(n):
	for i in items:
		if i.name==n:return i
	return {}
func can_equip(i):
	return i.class==GameState.class_name and GameState.level>=int(i.level)
func equip(name):
	var i=item_by_name(name)
	if i.is_empty() or not can_equip(i):return false
	GameState.equipment[i.slot]=name
	recalculate();return true
func recalculate():
	var base={"Blade":[420,170,42,12],"Archer":[320,250,36,7],"Mystic":[285,350,33,6]}[GameState.class_name]
	GameState.max_hp=base[0]+(GameState.level-1)*30;GameState.max_mp=base[1]+(GameState.level-1)*12;GameState.attack=base[2]+(GameState.level-1)*4;GameState.defense=base[3]+GameState.level-1
	for slot in GameState.equipment:
		var i=item_by_name(GameState.equipment[slot])
		if not i.is_empty():
			GameState.attack+=int(i.get("attack",0));GameState.defense+=int(i.get("defense",0));GameState.max_hp+=int(i.get("hp",0));GameState.max_mp+=int(i.get("mp",0))
	GameState.hp=min(GameState.hp,GameState.max_hp);GameState.mp=min(GameState.mp,GameState.max_mp)
