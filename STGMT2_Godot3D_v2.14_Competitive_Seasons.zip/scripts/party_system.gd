extends Node
var leader=""
var members=[]
var max_members=5
var loot_mode="Round Robin"
func create_party(name):
	leader=name;members=[name]
func invite(name):
	if leader=="" or members.size()>=max_members or name in members:return false
	members.append(name);return true
func leave(name):
	members.erase(name)
	if name==leader:leader=members[0] if not members.is_empty() else ""
func set_loot_mode(mode):
	if mode in ["Round Robin","Free","Leader"]:loot_mode=mode
