extends Node
var guild={"name":"","level":1,"xp":0,"gold":0,"members":[],"research":{"Attack":0,"Defense":0,"Drop":0}}
func create(name,owner):
	if guild.name!="" or name.strip_edges()=="":return false
	guild.name=name;guild.members=[{"name":owner,"rank":"Master"}];return true
func donate_gold(n):
	if n<=0 or GameState.gold<n:return false
	GameState.gold-=n;guild.gold+=n;guild.xp+=n/10;_level();return true
func add_member(name):
	if guild.name=="":return false
	for m in guild.members:
		if m.name==name:return false
	guild.members.append({"name":name,"rank":"Member"});return true
func research(branch):
	if not guild.research.has(branch):return false
	var lv=int(guild.research[branch]);var cost=(lv+1)*1000
	if guild.gold<cost:return false
	guild.gold-=cost;guild.research[branch]=lv+1;return true
func _level():
	while guild.xp>=guild.level*1000 and guild.level<20:guild.xp-=guild.level*1000;guild.level+=1
