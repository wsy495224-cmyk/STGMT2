extends CanvasLayer
signal world_requested(character_id)
var panel;var user;var password;var status;var list;var cname;var class_box
func _ready():
	panel=Panel.new();panel.position=Vector2(330,100);panel.size=Vector2(620,500);add_child(panel)
	var title=Label.new();title.text="STGMT2 Online";title.position=Vector2(25,20);title.add_theme_font_size_override("font_size",32);panel.add_child(title)
	user=LineEdit.new();user.placeholder_text="Username";user.position=Vector2(25,80);user.size=Vector2(270,38);panel.add_child(user)
	password=LineEdit.new();password.placeholder_text="Password (8+ characters)";password.secret=true;password.position=Vector2(310,80);password.size=Vector2(280,38);panel.add_child(password)
	var login=Button.new();login.text="Login";login.position=Vector2(25,130);login.pressed.connect(_login);panel.add_child(login)
	var reg=Button.new();reg.text="Register";reg.position=Vector2(115,130);reg.pressed.connect(_register);panel.add_child(reg)
	status=Label.new();status.position=Vector2(25,180);status.size=Vector2(560,35);panel.add_child(status)
	cname=LineEdit.new();cname.placeholder_text="New character name";cname.position=Vector2(25,230);cname.size=Vector2(260,36);panel.add_child(cname)
	class_box=OptionButton.new();class_box.position=Vector2(300,230);class_box.size=Vector2(150,36)
	for c in ["Blade","Archer","Mystic"]:class_box.add_item(c)
	panel.add_child(class_box)
	var create=Button.new();create.text="Create";create.position=Vector2(470,230);create.pressed.connect(_create);panel.add_child(create)
	list=ItemList.new();list.position=Vector2(25,285);list.size=Vector2(565,145);list.item_activated.connect(_enter);panel.add_child(list)
	NetworkClient.message_received.connect(_message)
	NetworkClient.connected_to_server.connect(func():status.text="Connected to server")
	NetworkClient.connect_server()
func _login():NetworkClient.login(user.text,password.text)
func _register():NetworkClient.register_user(user.text,password.text)
func _create():NetworkClient.create_character(cname.text,class_box.get_item_text(class_box.selected))
func _enter(index):
	var chars=NetworkClient.characters
	if index>=0 and index<chars.size():NetworkClient.enter_world(int(chars[index].id));world_requested.emit(int(chars[index].id))
func _message(m):
	var t=m.get("type","")
	if t=="login_result":
		status.text="Login successful" if m.get("ok",false) else "Login failed";_refresh()
	elif t=="register_result":status.text="Registered. You can now login." if m.get("ok",false) else str(m.get("error","Registration failed"))
	elif t=="create_character_result":status.text="Character created" if m.get("ok",false) else "Character creation failed";_refresh()
	elif t=="enter_result" and m.get("ok",false):panel.visible=false
func _refresh():
	list.clear()
	for c in NetworkClient.characters:list.add_item("%s — %s Lv.%d"%[c.name,c.class_name,c.level])
