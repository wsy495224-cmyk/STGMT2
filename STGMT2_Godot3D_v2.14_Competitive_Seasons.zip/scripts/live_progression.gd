extends Node
var daily={"kills":{"goal":20,"progress":0,"reward":300},"crystals":{"goal":3,"progress":0,"reward":250},"boss":{"goal":1,"progress":0,"reward":500}}
var reputation={"Green Valley":0,"Arena":0,"Merchants":0}
var bounties=[]
var streak=1
func progress(kind,n=1):
	if daily.has(kind):daily[kind].progress=min(daily[kind].goal,daily[kind].progress+n)
func claim(kind):
	if not daily.has(kind) or daily[kind].progress<daily[kind].goal:return false
	GameState.gold+=daily[kind].reward;daily.erase(kind);return true
func add_rep(group,n):reputation[group]=reputation.get(group,0)+n
func generate_bounty():
	bounties=[{"target":"Fang Wolf","amount":10,"reward":450},{"target":"Valley Guardian","amount":1,"reward":700}]
