extends Node
var trees={}
var levels={}
func _ready():
	var f=FileAccess.open("res://data/skill_tree_v16.json",FileAccess.READ);trees=JSON.parse_string(f.get_as_text())
func nodes():return trees.get(GameState.class_name,[])
func invest(id):
	if GameState.skill_points<1:return false
	var node={}
	for n in nodes():
		if n.id==id:node=n;break
	if node.is_empty():return false
	for req in node.requires:
		if levels.get(req,0)<1:return false
	var lv=levels.get(id,0)
	if lv>=int(node.max):return false
	levels[id]=lv+1;GameState.skill_points-=1;return true
func bonuses():
	var out={}
	for n in nodes():
		var lv=levels.get(n.id,0)
		out[n.effect]=out.get(n.effect,0.0)+lv*float(n.per_level)
	return out
