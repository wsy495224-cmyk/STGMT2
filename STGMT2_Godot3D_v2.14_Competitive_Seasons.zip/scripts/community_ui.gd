extends CanvasLayer
var panel
var text
var mode=""
func _ready():
	panel=Panel.new();panel.position=Vector2(230,80);panel.size=Vector2(800,540);panel.visible=false;add_child(panel)
	text=RichTextLabel.new();text.position=Vector2(25,25);text.size=Vector2(750,490);text.bbcode_enabled=true;panel.add_child(text)
func toggle(m):
	mode=m;panel.visible=!panel.visible
	if panel.visible:refresh()
func refresh():
	if mode=="guild":
		text.text="[font_size=28]Guild[/font_size]\nName: %s  Lv.%d\nGold: %d\nMembers: %d\nResearch: %s"%[GuildSystem.guild.name,GuildSystem.guild.level,GuildSystem.guild.gold,GuildSystem.guild.members.size(),str(GuildSystem.guild.research)]
	elif mode=="party":
		text.text="[font_size=28]Party[/font_size]\nLeader: %s\nMembers: %s\nLoot: %s"%[PartySystem.leader,", ".join(PartySystem.members),PartySystem.loot_mode]
	elif mode=="craft":
		var s="[font_size=28]Crafting / Alchemy[/font_size]\n\n"
		for r in CraftingSystem.recipes:s+="%s — %s\n"%[r.name,str(r.ingredients)]
		text.text=s
	elif mode=="mail":
		text.text="[font_size=28]Mailbox[/font_size]\nInbox: %d   Sent: %d\nAttachments can carry an item or gold."%[MailSystem.inbox.size(),MailSystem.sent.size()]
	elif mode=="events":
		var s="[font_size=28]World Events[/font_size]\n\n"
		for e in WorldEventSystem.events:s+="%s — %d min — %s\n"%[e.name,e.duration_min,e.objective]
		text.text=s
