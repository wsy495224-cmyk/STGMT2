extends Node

var equipment: Array = []
var rarity_weight := {"Easy":45,"Common":30,"Medium":16,"Rare":7,"Legendary":2}

func _ready():
	var f = FileAccess.open("res://data/equipment_v12.json", FileAccess.READ)
	if f: equipment = JSON.parse_string(f.get_as_text())

func roll_equipment(player_class: String, player_level: int, boss := false) -> Dictionary:
	var pool: Array = []
	for item in equipment:
		if str(item.get("class","")) == player_class and int(item.get("level",1)) <= player_level + 5:
			pool.append(item)
	if pool.is_empty(): return {}
	var roll = randi_range(1,100)
	var rarity = "Easy"
	if boss:
		if roll <= 12: rarity = "Legendary"
		elif roll <= 42: rarity = "Rare"
		elif roll <= 78: rarity = "Medium"
		else: rarity = "Common"
	else:
		var acc = 0
		for r in ["Legendary","Rare","Medium","Common","Easy"]:
			acc += int(rarity_weight[r])
			if roll <= acc: rarity = r; break
	var matches: Array = []
	for item in pool:
		if str(item.get("rarity","Easy")) == rarity: matches.append(item)
	if matches.is_empty(): matches = pool
	return matches[randi() % matches.size()]

func reward_local(player_class: String, player_level: int, boss := false) -> Dictionary:
	var gold = randi_range(80,180) if boss else randi_range(8,24)
	GameState.gold += gold
	var result := {"gold":gold,"item":""}
	var chance = 0.65 if boss else 0.12
	if randf() <= chance:
		var item = roll_equipment(player_class, player_level, boss)
		if not item.is_empty():
			var n = str(item.get("name","")); GameState.add_item(n,1); result["item"] = n
	return result
