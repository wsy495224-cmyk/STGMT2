extends Label3D
var velocity=Vector3(0,1.6,0)
var life=1.0
func setup(value,critical=false,heal=false):
	text=str(value)
	font_size=48 if critical else 36
	modulate=Color("#ffd34d") if critical else (Color("#63e68b") if heal else Color.WHITE)
	billboard=BaseMaterial3D.BILLBOARD_ENABLED
func _process(delta):
	position+=velocity*delta;life-=delta
	modulate.a=max(0.0,life)
	if life<=0:queue_free()
