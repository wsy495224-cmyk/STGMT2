extends Node3D

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new(); m.albedo_color = c; m.roughness = 0.75; return m

func setup(boss: bool) -> void:
	var torso := MeshInstance3D.new(); var cap := CapsuleMesh.new(); cap.radius = 0.62 if not boss else 1.0; cap.height = 1.55 if not boss else 2.7; torso.mesh = cap; torso.material_override = _mat(Color("#6d4937") if not boss else Color("#7d2e35")); add_child(torso)
	var head := MeshInstance3D.new(); var s := SphereMesh.new(); s.radius = 0.38 if not boss else 0.58; s.height = s.radius * 2.0; head.mesh = s; head.position.y = 1.15 if not boss else 1.85; head.material_override = _mat(Color("#8b654c") if not boss else Color("#a63d43")); add_child(head)
	for side in [-1, 1]:
		var horn := MeshInstance3D.new(); var c := CylinderMesh.new(); c.top_radius = 0.02; c.bottom_radius = 0.1; c.height = 0.55 if not boss else 0.9; horn.mesh = c; horn.position = Vector3(0.25 * side, 1.48 if not boss else 2.35, 0); horn.rotation_degrees.z = -28 * side; horn.material_override = _mat(Color("#d0c3a2")); add_child(horn)
