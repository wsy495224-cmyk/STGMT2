extends Node
var codex={}
func record_enemy(name):
	codex[name]=codex.get(name,0)+1
	if GameState.kills>=10 and not "First Blood" in GameState.titles:GameState.titles.append("First Blood")
	if GameState.kills>=100 and not "Hunter" in GameState.titles:GameState.titles.append("Hunter")
	if GameState.bosses>=1 and not "Boss Slayer" in GameState.achievements:GameState.achievements.append("Boss Slayer")
	if GameState.crystals>=10 and not "Crystal Hunter" in GameState.titles:GameState.titles.append("Crystal Hunter")
func set_title(t):
	if t in GameState.titles:GameState.current_title=t;return true
	return false
