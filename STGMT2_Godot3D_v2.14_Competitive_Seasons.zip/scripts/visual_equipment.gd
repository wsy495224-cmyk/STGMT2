extends Node3D
var weapon
var armor
var helmet
var mount_visual
var class_name="Blade"

func setup(c):
	class_name=c
	_rebuild()

func _mat(color,metal=.2):
	var m=StandardMaterial3D.new();m.albedo_color=color;m.metallic=metal;m.roughness=.45;return m

func _clear(node):
	if is_instance_valid(node):node.queue_free()

func _rebuild():
	_clear(weapon);_clear(armor);_clear(helmet)
	# Chest armor
	armor=MeshInstance3D.new();var chest=BoxMesh.new();chest.size=Vector3(1.15,1.15,.7);armor.mesh=chest;armor.position=Vector3(0,.25,0)
	armor.material_override=_mat(Color("#59636e") if class_name=="Blade" else (Color("#4b6b4e") if class_name=="Archer" else Color("#594c79")),0.45 if class_name=="Blade" else .1);add_child(armor)
	# Helmet
	helmet=MeshInstance3D.new();var hs=SphereMesh.new();hs.radius=.48;hs.height=.75;helmet.mesh=hs;helmet.position=Vector3(0,1.05,0)
	helmet.material_override=_mat(Color("#69747f") if class_name=="Blade" else Color("#50664e"),.4);add_child(helmet)
	# Class weapon
	weapon=MeshInstance3D.new()
	if class_name=="Blade":
		var b=BoxMesh.new();b.size=Vector3(.12,1.9,.12);weapon.mesh=b;weapon.position=Vector3(.75,.15,0);weapon.rotation_degrees.z=-18;weapon.material_override=_mat(Color("#c7d0d6"),.85)
	elif class_name=="Archer":
		var t=TorusMesh.new();t.inner_radius=.52;t.outer_radius=.58;weapon.mesh=t;weapon.position=Vector3(.72,.2,0);weapon.rotation_degrees.y=90;weapon.material_override=_mat(Color("#8a5c35"),.05)
	else:
		var b=BoxMesh.new();b.size=Vector3(.11,2.0,.11);weapon.mesh=b;weapon.position=Vector3(.72,.1,0);weapon.rotation_degrees.z=-12;weapon.material_override=_mat(Color("#8667ba"),.3)
	add_child(weapon)

func show_mount(id):
	_clear(mount_visual)
	mount_visual=Node3D.new();mount_visual.name="MountVisual";mount_visual.position=Vector3(0,-.65,0);add_child(mount_visual)
	var body=MeshInstance3D.new();var capsule=CapsuleMesh.new();capsule.radius=.7;capsule.height=1.8;body.mesh=capsule;body.rotation_degrees.z=90
	body.material_override=_mat(Color("#72513a") if "horse" in id else Color("#707680"),.05);mount_visual.add_child(body)
	for x in [-.45,.45]:
		for z in [-.45,.45]:
			var leg=MeshInstance3D.new();var b=BoxMesh.new();b.size=Vector3(.18,.85,.18);leg.mesh=b;leg.position=Vector3(x,-.65,z);leg.material_override=body.material_override;mount_visual.add_child(leg)

func hide_mount():_clear(mount_visual);mount_visual=null
