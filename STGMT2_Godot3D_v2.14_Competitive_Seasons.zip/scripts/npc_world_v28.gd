extends Node3D
var game
var db={}
var shops={}
var spawned=[]
func setup(g):
 game=g
 db=JSON.parse_string(FileAccess.get_file_as_string("res://data/npcs_v28.json"))
 shops=JSON.parse_string(FileAccess.get_file_as_string("res://data/shops_v28.json"))
 rebuild(game.current_map_v27)
func clear():
 for n in spawned:
  if is_instance_valid(n): n.queue_free()
 spawned.clear()
func rebuild(map_name):
 clear()
 for d in db.get(map_name,[]): _spawn(d)
func _spawn(d):
 var n=StaticBody3D.new(); n.name=str(d.get("id","npc")); n.position=Vector3(float(d.x),1,float(d.z)); add_child(n); spawned.append(n)
 n.set_meta("npc_data",d)
 var body=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.radius=.48; cap.height=1.7; body.mesh=cap
 var mat=StandardMaterial3D.new(); mat.albedo_color=Color("#d8b07a"); body.material_override=mat; n.add_child(body)
 var label=Label3D.new(); label.text=str(d.name)+"\n"+str(d.role); label.position=Vector3(0,1.8,0); label.billboard=BaseMaterial3D.BILLBOARD_ENABLED; label.font_size=26; n.add_child(label)
 var col=CollisionShape3D.new(); var sh=CapsuleShape3D.new(); sh.radius=.55; sh.height=1.8; col.shape=sh; n.add_child(col)
func nearest(max_dist=3.2):
 var best=null; var dist=max_dist
 for n in spawned:
  if is_instance_valid(n):
   var d=game.player.global_position.distance_to(n.global_position)
   if d<dist: best=n; dist=d
 return best
func interact_near_player():
 var n=nearest()
 if n==null:return false
 game.npc_ui_v28.open_npc(n.get_meta("npc_data"),shops)
 return true
