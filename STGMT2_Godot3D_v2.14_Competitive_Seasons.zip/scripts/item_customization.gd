extends Node
var sockets := {}
var gems := {}
var bonuses := {}
var collections := {}
const MAX_SOCKETS := 3
const GEM_BONUSES := {"Rare Gem":{"attack":6,"defense":3,"hp":45},"Gem Fragment":{"attack":2,"hp":15}}
func add_socket(item:String)->bool:
	var count:int=int(sockets.get(item,0))
	if count>=MAX_SOCKETS:return false
	sockets[item]=count+1
	return true
func insert_gem(item:String,gem:String)->bool:
	if not GEM_BONUSES.has(gem):return false
	var used:Array=gems.get(item,[])
	if int(sockets.get(item,0))<=used.size():return false
	if int(GameState.inventory.get(gem,0))<1:return false
	GameState.inventory[gem]-=1
	if not gems.has(item):gems[item]=[]
	gems[item].append(gem)
	return true
func gem_stats(item:String)->Dictionary:
	var out={"attack":0,"defense":0,"hp":0,"mp":0}
	for gem in gems.get(item,[]):
		for k in GEM_BONUSES.get(gem,{}):out[k]+=int(GEM_BONUSES[gem][k])
	return out
func roll_bonus(item:String)->Dictionary:
	var pool=["attack","defense","hp","mp"]
	var key:String=pool[randi()%pool.size()]
	var amount:int={"attack":randi_range(2,7),"defense":randi_range(1,5),"hp":randi_range(20,80),"mp":randi_range(15,60)}[key]
	bonuses[item]={key:amount}
	return bonuses[item]
func collect(group:String,item:String):
	if not collections.has(group):collections[group]=[]
	if not item in collections[group]:collections[group].append(item)
