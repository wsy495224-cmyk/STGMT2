extends Node3D

var game
var portals := []
const CONNECTIONS = {
    "Green Valley": ["Red Dunes"],
    "Red Dunes": ["Green Valley", "Mist Forest"],
    "Mist Forest": ["Red Dunes", "Frozen Pass"],
    "Frozen Pass": ["Mist Forest", "Sunset Ruins"],
    "Sunset Ruins": ["Frozen Pass", "Dark Marsh"],
    "Dark Marsh": ["Sunset Ruins", "Sky Plateau"],
    "Sky Plateau": ["Dark Marsh"]
}

func setup(owner_game):
    game = owner_game
    rebuild("Green Valley")

func rebuild(map_name: String):
    for p in portals:
        if is_instance_valid(p): p.queue_free()
    portals.clear()
    var rows = CONNECTIONS.get(map_name, [])
    for i in range(rows.size()):
        _make_portal(str(rows[i]), Vector3(-10.0 + i*20.0, 1.0, -18.0))

func _make_portal(destination: String, pos: Vector3):
    var body = Area3D.new()
    body.position = pos
    body.set_meta("destination", destination)
    add_child(body)
    portals.append(body)
    var ring = MeshInstance3D.new()
    var torus = TorusMesh.new()
    torus.inner_radius = 1.45
    torus.outer_radius = 1.8
    ring.mesh = torus
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color("#62c9ff")
    mat.emission_enabled = true
    mat.emission = Color("#3189c7")
    mat.emission_energy_multiplier = 2.2
    ring.material_override = mat
    ring.rotation_degrees.x = 90
    body.add_child(ring)
    var label = Label3D.new()
    label.text = "PORTAL\n" + destination
    label.position = Vector3(0,2.6,0)
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 30
    body.add_child(label)
    var col = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 2.2
    col.shape = shape
    body.add_child(col)

func interact_near_player() -> bool:
    if not game or not is_instance_valid(game.player): return false
    for portal in portals:
        if is_instance_valid(portal) and game.player.global_position.distance_to(portal.global_position) < 3.2:
            var destination = str(portal.get_meta("destination"))
            if NetworkClient.connected:
                NetworkClient.portal_travel_server(destination)
                game.notify("Travel request: " + destination)
            else:
                game.apply_local_map_v27(destination)
            return true
    return false
