extends CanvasLayer
var panel
var text
var mode=""
func _ready():
	panel=Panel.new();panel.position=Vector2(250,90);panel.size=Vector2(760,520);panel.visible=false;add_child(panel)
	text=RichTextLabel.new();text.position=Vector2(22,22);text.size=Vector2(715,470);text.bbcode_enabled=true;panel.add_child(text)
func toggle_skill_tree():
	mode="skills";panel.visible=!panel.visible
	if panel.visible:refresh()
func toggle_market():
	mode="market";panel.visible=!panel.visible
	if panel.visible:refresh()
func refresh():
	if mode=="skills":
		var s="[font_size=28]Skill Tree — %s[/font_size]\nSkill Points: %d\n\n"%[GameState.class_name,GameState.skill_points]
		for n in SkillTreeManager.nodes():
			s+="[b]%s[/b]  Lv.%d/%d — %s +%s/level\n"%[n.name,SkillTreeManager.levels.get(n.id,0),n.max,n.effect,n.per_level]
		text.text=s
	elif mode=="market":
		var s="[font_size=28]Player Market / Auction House[/font_size]\n\n"
		if MarketSystem.listings.is_empty():s+="No active listings in local prototype.\n"
		for l in MarketSystem.listings:s+="#%d  %s x%d — %d gold each — Seller: %s\n"%[l.id,l.item,l.count,l.unit_price,l.seller]
		s+="\nThe online release will make listings server-authoritative."
		text.text=s
