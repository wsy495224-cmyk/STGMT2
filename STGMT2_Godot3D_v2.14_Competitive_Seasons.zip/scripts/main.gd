extends Node3D
var inventory_ui_v29
var player
var hud
var enemies=[]
var drops=[]
var crystals=[]
var rng=RandomNumberGenerator.new()
var quest={"name":"First Hunt","kind":"kill","need":5,"progress":0,"reward_gold":120}
var arena_active=false
var dungeon_active=false
var event_text=""
var rpg_ui
var social_ui
var mouse_control
var target_label
var selected_target=null
var auto_attack_last=0.0
var advanced_ui
var login_ui
var remote_players
var net_move_timer=0.0
var community_ui
var pet_visual
var minimap
var current_ring=null
var visual_equipment
var hp_bar_ui
var mp_bar_ui
var hud_v26
var visual_quality_v26
var world_identity_v27
var portal_visual_v27
var npc_world_v28
var npc_ui_v28
var current_map_v27 := "Green Valley"

func _ready():
	inventory_ui_v29=preload("res://scripts/inventory_ui_v29.gd").new();add_child(inventory_ui_v29)
	rng.randomize();_world();_player();_spawn_pack();_crystals();_hud()
	visual_quality_v26=load("res://scripts/visual_quality_v26.gd").new();add_child(visual_quality_v26);visual_quality_v26.build_village(self);visual_quality_v26.build_ruins(self)
	world_identity_v27=load("res://scripts/world_identity_v27.gd").new();add_child(world_identity_v27);world_identity_v27.setup(self)
	portal_visual_v27=load("res://scripts/portal_visual_v27.gd").new();add_child(portal_visual_v27);portal_visual_v27.setup(self)
	npc_ui_v28=load("res://scripts/npc_ui_v28.gd").new();add_child(npc_ui_v28);npc_ui_v28.setup(self)
	npc_world_v28=load("res://scripts/npc_world_v28.gd").new();add_child(npc_world_v28);npc_world_v28.setup(self)
	hud_v26=load("res://scripts/hud_v26.gd").new();get_node("HUD").add_child(hud_v26);hud_v26.setup(self)
	rpg_ui=load("res://scripts/rpg_ui.gd").new();add_child(rpg_ui)
	social_ui=load("res://scripts/social_ui.gd").new();add_child(social_ui)
	advanced_ui=load("res://scripts/advanced_ui.gd").new();add_child(advanced_ui)
	minimap=load("res://scripts/minimap_v27.gd").new();minimap.game=self;minimap.position=Vector2(1080,18);get_node("HUD").add_child(minimap)
	LiveProgression.generate_bounty()
	community_ui=load("res://scripts/community_ui.gd").new();add_child(community_ui)
	pet_visual=load("res://scripts/pet_visual.gd").new();player.add_child(pet_visual);PetSystem.summon("fox_ember");pet_visual.show_pet("fox_ember")
	PartySystem.create_party(GameState.player_name)
	remote_players=load("res://scripts/remote_player_manager.gd").new();add_child(remote_players)
	login_ui=load("res://scripts/login_ui.gd").new();add_child(login_ui)
	NetworkClient.message_received.connect(_network_message)
	for q in QuestManager.available():
		if q.id=="q01":QuestManager.accept(q.id)
	notify("Welcome to STGMT2 — Green Valley")

func mat(c):
	var m=StandardMaterial3D.new();m.albedo_color=c;m.roughness=.78;return m
func mesh_box(pos,size,c):
	var x=MeshInstance3D.new();var b=BoxMesh.new();b.size=size;x.mesh=b;x.material_override=mat(c);x.position=pos;add_child(x);return x

func _world():
	var env=WorldEnvironment.new();var e=Environment.new();e.background_mode=Environment.BG_COLOR;e.background_color=Color("#83a9bc")
	e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;e.ambient_light_color=Color("#e4edf1");e.ambient_light_energy=.8;env.environment=e;add_child(env)
	var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-55,-25,0);sun.shadow_enabled=true;add_child(sun)
	mesh_box(Vector3(0,-.5,0),Vector3(90,1,90),Color("#4f7744"))
	var ground=StaticBody3D.new();ground.name="Ground";add_child(ground)
	var gc=CollisionShape3D.new();var gs=BoxShape3D.new();gs.size=Vector3(90,1,90);gc.shape=gs;gc.position=Vector3(0,-.5,0);ground.add_child(gc)
	mesh_box(Vector3(0,.01,0),Vector3(7,.06,80),Color("#8c7960"))
	# village
	for p in [Vector3(-13,1.5,-4),Vector3(-13,1.5,8),Vector3(13,1.5,-4),Vector3(13,1.5,8)]:
		mesh_box(p,Vector3(6,3,5),Color("#80644d"))
	# arena
	var a=MeshInstance3D.new();var c=CylinderMesh.new();c.top_radius=11;c.bottom_radius=11;c.height=.25;a.mesh=c;a.material_override=mat(Color("#86664d"));a.position=Vector3(28,.15,0);add_child(a)
	for i in range(30):
		var t=TAU*i/30.;mesh_box(Vector3(28+cos(t)*11.4,1.2,sin(t)*11.4),Vector3(.65,2.4,.65),Color("#3d4146"))

func _player():
	var deco=load("res://scripts/world_decorator.gd").new();add_child(deco);deco.decorate(self)
	player=CharacterBody3D.new();player.position=Vector3(0,1,9);player.set_script(load("res://scripts/player.gd"));add_child(player);player.game=self
	var avatar=load("res://scripts/character_visual_v26.gd").new();avatar.name="CharacterVisualV26";player.add_child(avatar);avatar.setup(GameState.class_name)
	visual_equipment=load("res://scripts/visual_equipment.gd").new();player.add_child(visual_equipment);visual_equipment.setup(GameState.class_name)
	var col=CollisionShape3D.new();var sh=CapsuleShape3D.new();sh.radius=.55;sh.height=1.8;col.shape=sh;player.add_child(col)
	var piv=Node3D.new();piv.position=Vector3(0,2,0);player.add_child(piv);var cam=Camera3D.new();cam.position=Vector3(0,7,11);cam.rotation_degrees=Vector3(-25,180,0);piv.add_child(cam)
	mouse_control=load("res://scripts/classic_mouse_controller.gd").new();add_child(mouse_control);mouse_control.setup(self,player,cam)

func npc(name,pos,role,c):
	var n=StaticBody3D.new();n.position=pos;n.name=name;add_child(n)
	var m=MeshInstance3D.new();var cp=CapsuleMesh.new();cp.radius=.48;cp.height=1.7;m.mesh=cp;m.material_override=mat(c);n.add_child(m)
	var l=Label3D.new();l.text=name+"\n"+role;l.position=Vector3(0,1.8,0);l.billboard=BaseMaterial3D.BILLBOARD_ENABLED;l.font_size=28;n.add_child(l)

func _npcs():
	npc("Smith Boran",Vector3(-6,1,3),"Blacksmith +15",Color("#ad6137"))
	npc("Master Arin",Vector3(6,1,3),"Skill Master",Color("#507ed0"))
	npc("Merchant Mira",Vector3(-6,1,-4),"Merchant",Color("#d3a44d"))
	npc("Arena Warden",Vector3(16,1,0),"PvP / Tournament",Color("#b84c4c"))
	npc("Keeper Sera",Vector3(6,1,-4),"Warehouse",Color("#4a9c7d"))
	npc("Gatekeeper",Vector3(4,1,-10),"Dungeon",Color("#7956a7"))

func spawn_enemy(pos,boss=false):
	var x=CharacterBody3D.new();x.position=pos;x.set_script(load("res://scripts/enemy.gd"));add_child(x);x.game=self;x.boss=boss;x.hp=450 if boss else 95
	var enemy_visual=load("res://scripts/enemy_visual_v26.gd").new();x.add_child(enemy_visual);enemy_visual.setup(boss)
	var col=CollisionShape3D.new();var sh=CapsuleShape3D.new();sh.radius=1.0 if boss else .7;sh.height=2.5 if boss else 1.4;col.shape=sh;x.add_child(col)
	enemies.append(x)

func _spawn_pack():
	for i in range(14):spawn_enemy(Vector3(rng.randf_range(-32,32),.8,rng.randf_range(-32,32)))
	spawn_enemy(Vector3(0,1,-28),true)

func _crystals():
	for p in [Vector3(-20,1,-18),Vector3(20,1,-18),Vector3(-22,1,20)]:
		var x=StaticBody3D.new();x.position=p;x.set_script(load("res://scripts/crystal.gd"));add_child(x);x.game=self
		var m=MeshInstance3D.new();var pr=PrismMesh.new();pr.size=Vector3(1.6,3,1.6);m.mesh=pr;m.material_override=mat(Color("#9a3bc0"));x.add_child(m)
		var col=CollisionShape3D.new();var sh=BoxShape3D.new();sh.size=Vector3(1.8,3.2,1.8);col.shape=sh;x.add_child(col);crystals.append(x)

func player_attack(origin):
	var best=null;var bd=3.7
	for e in enemies:
		if is_instance_valid(e):
			var d=origin.distance_to(e.global_position)
			if d<bd:best=e;bd=d
	for c in crystals:
		if is_instance_valid(c):
			var d=origin.distance_to(c.global_position)
			if d<bd:c.damage(GameState.attack);return
	if best:best.damage(GameState.attack)

func enemy_defeated(e,boss):
	enemies.erase(e);GameState.kills+=1;MetaProgression.record_enemy("Boss" if boss else "Wildling")
	LiveProgression.progress("boss" if boss else "kills");LiveProgression.add_rep("Green Valley",5 if boss else 1);PetSystem.gain_xp(35 if boss else 5)
	if not WorldEventSystem.active.is_empty():WorldEventSystem.progress(5 if boss else 1)
	QuestManager.progress("boss" if boss else "kill","Valley Guardian" if boss else "Wildling")
	if boss:GameState.bosses+=1
	GameState.gain_xp(130 if boss else 28);GameState.gold+=rng.randi_range(80,150) if boss else rng.randi_range(6,20)
	var pool=["HP Potion","MP Potion","Upgrade Stone","Gem Fragment","Skill Book"]
	if boss:pool+=["Epic Equipment","Costume Fragment","Pet Egg","Mount Token"]
	drop_item(e.global_position,pool[rng.randi_range(0,pool.size()-1)])
	if quest.kind=="kill":quest.progress=min(quest.need,quest.progress+1)
	if quest.progress>=quest.need:
		GameState.gold+=quest.reward_gold;notify("Quest complete! +%d gold"%quest.reward_gold);quest={"name":"Crystal Breaker","kind":"crystal","need":2,"progress":0,"reward_gold":220}
	refresh()

func crystal_defeated(c):
	crystals.erase(c);GameState.crystals+=1;GameState.gain_xp(65);QuestManager.progress("crystal","STG Crystal");LiveProgression.progress("crystals");drop_item(c.global_position,"Crystal Shard")
	if quest.kind=="crystal":quest.progress=min(quest.need,quest.progress+1)
	if quest.progress>=quest.need:GameState.gold+=quest.reward_gold;notify("Crystal quest complete!");quest={"name":"Boss Trial","kind":"boss","need":1,"progress":0,"reward_gold":500}
	refresh()

func drop_item(pos,item):
	var d=Area3D.new();d.position=pos+Vector3(0,.5,0);d.set_meta("item",item);add_child(d)
	var m=MeshInstance3D.new();var s=SphereMesh.new();s.radius=.22;s.height=.44;m.mesh=s;m.material_override=mat(Color("#efd04f"));d.add_child(m)
	var l=load("res://scripts/loot_label.gd").new();var rar="Legendary" if "Legendary" in item else ("Rare" if "Epic" in item or "Costume" in item else "Common")
	l.setup(item,rar);l.position=Vector3(0,.55,0);d.add_child(l);drops.append(d)

func collect_nearby():
	for d in drops.duplicate():
		if is_instance_valid(d) and player.global_position.distance_to(d.global_position)<2.3:
			var item=str(d.get_meta("item"));GameState.add_item(item);drops.erase(d);d.queue_free();notify("Loot: "+item);refresh()

func interact():
	if npc_world_v28 and npc_world_v28.interact_near_player():return
	if portal_visual_v27 and portal_visual_v27.interact_near_player():return
	collect_nearby()
	if player.global_position.distance_to(Vector3(-6,1,3))<3:open_blacksmith()
	elif player.global_position.distance_to(Vector3(-6,1,-4))<3:buy_potion()
	elif player.global_position.distance_to(Vector3(16,1,0))<4:toggle_arena()
	elif player.global_position.distance_to(Vector3(4,1,-10))<3:start_dungeon()

func buy_potion():
	if GameState.spend_gold(20):GameState.add_item("HP Potion");notify("Bought HP Potion")
	else:notify("Not enough gold");refresh()

func open_blacksmith():
	var item=GameState.equipment.weapon;var lv=int(GameState.upgrade_levels.get(item,0))
	if lv>=15:notify(item+" is already +15");return
	var stones=int(GameState.inventory.get("Upgrade Stone",0));var cost=100*(lv+1)*(lv+1)
	if stones<1 or not GameState.spend_gold(cost):notify("Need 1 Upgrade Stone and %d gold"%cost);return
	GameState.inventory["Upgrade Stone"]=stones-1
	var chance=max(.15,1.0-lv*.055)
	if rng.randf()<=chance:lv+=1;GameState.upgrade_levels[item]=lv;GameState.attack+=3;notify("Upgrade SUCCESS: %s +%d"%[item,lv])
	else:
		if lv>4:lv-=1;GameState.upgrade_levels[item]=lv
		notify("Upgrade failed"+(" — downgraded" if lv>4 else " — safe"))
	refresh()

func toggle_arena():
	arena_active=!arena_active;notify("Ranked Arena "+("ON" if arena_active else "OFF")+" | Rating %d"%GameState.arena_rating)

func start_dungeon():
	dungeon_active=true;notify("Dungeon: Moonfang Den started — defeat the enemies and boss")
	for i in range(5):spawn_enemy(Vector3(rng.randf_range(-8,8),.8,rng.randf_range(-35,-25)))
	spawn_enemy(Vector3(0,1,-38),true)

func use_potion():
	var n=int(GameState.inventory.get("HP Potion",0))
	if n>0 and GameState.hp<GameState.max_hp:GameState.inventory["HP Potion"]=n-1;GameState.hp=min(GameState.max_hp,GameState.hp+150);notify("HP restored");refresh()

func _hud():
	var l=CanvasLayer.new();l.name="HUD";add_child(l);hud=Label.new();hud.position=Vector2(18,14);hud.add_theme_font_size_override("font_size",21);l.add_child(hud)
	target_label=Label.new();target_label.position=Vector2(470,18);target_label.size=Vector2(360,70);target_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;target_label.add_theme_font_size_override("font_size",20);l.add_child(target_label)
	hp_bar_ui=ProgressBar.new();hp_bar_ui.position=Vector2(18,90);hp_bar_ui.size=Vector2(260,18);hp_bar_ui.max_value=GameState.max_hp;hp_bar_ui.show_percentage=false;l.add_child(hp_bar_ui)
	mp_bar_ui=ProgressBar.new();mp_bar_ui.position=Vector2(18,112);mp_bar_ui.size=Vector2(260,14);mp_bar_ui.max_value=GameState.max_mp;mp_bar_ui.show_percentage=false;l.add_child(mp_bar_ui)
	var msg=Label.new();msg.name="Msg";msg.position=Vector2(18,112);msg.add_theme_font_size_override("font_size",20);l.add_child(msg)
	var help=Label.new();help.position=Vector2(18,590);help.add_theme_font_size_override("font_size",17)
	help.text="LMB: Move / Target / Interact   RMB+Mouse: Rotate Camera   Wheel: Zoom   1–6 Skills
I Inventory   V Skills   M Mount   O Social   J Claim Quest   WASD optional";l.add_child(help);refresh()

func refresh():
	if hp_bar_ui:hp_bar_ui.max_value=GameState.max_hp;hp_bar_ui.value=GameState.hp
	if mp_bar_ui:mp_bar_ui.max_value=GameState.max_mp;mp_bar_ui.value=GameState.mp
	if hud_v26:hud_v26.refresh()
	if hud:
		var weap=GameState.equipment.weapon;var up=int(GameState.upgrade_levels.get(weap,0))
		hud.text="STGMT2 3D  Lv.%d  HP %d/%d  XP %d/%d  Gold %d\n%s +%d  ATK %d  Arena %d\nQuest: %s %d/%d"%[GameState.level,GameState.hp,GameState.max_hp,GameState.xp,GameState.level*150,GameState.gold,weap,up,GameState.attack,GameState.arena_rating,quest.name,quest.progress,quest.need]

func notify(t):
	var x=get_node_or_null("HUD/Msg");if x:x.text=t

func save():GameState.save_game();notify("Game saved")
func load_save():GameState.load_game();notify("Game loaded");refresh()

func cast_skill(index):
	var s=SkillSystem.cast(GameState.class_name,index)
	if s.is_empty():notify("Skill unavailable / cooldown / MP");return
	var best=null;var bd=float(s.range)
	for e in enemies:
		if is_instance_valid(e):
			var d=player.global_position.distance_to(e.global_position)
			if d<bd:best=e;bd=d
	if best:
		best.damage(int(GameState.attack*float(s.damage)*SkillMastery.damage_bonus(index)));SkillMastery.add_xp(index,15);notify(str(s.name)+" Lv."+str(SkillMastery.level(index)))
	else:notify("No target in range")
	refresh()

func toggle_inventory():
	if inventory_ui_v29: inventory_ui_v29.toggle()
func show_skills():rpg_ui.show_skills(SkillSystem)

func toggle_social():social_ui.toggle()
func mount_toggle():
	if MountSystem.active=="":
		player.speed=7.0*MountSystem.summon("horse_brown");visual_equipment.show_mount("horse_brown");notify("Mount summoned")
	else:
		player.speed=7.0*MountSystem.dismiss();visual_equipment.hide_mount();notify("Mount dismissed")
func claim_quests():
	for id in QuestManager.active.keys().duplicate():
		if QuestManager.claim(id):notify("Quest reward claimed: "+id)
	refresh()

func set_target(obj):
	if is_instance_valid(current_ring):current_ring.queue_free()
	current_ring=null;selected_target=obj
	if is_instance_valid(obj):current_ring=CombatVFX.target_ring(self,obj)
	if not target_label:return
	if obj==null or not is_instance_valid(obj):target_label.text="";return
	var n="STG Crystal" if obj in crystals else ("Boss" if obj.get("boss") else "Wildling")
	var hpv=obj.get("hp")
	target_label.text="TARGET: %s\nHP: %s"%[n,str(hpv)]

func try_auto_attack(obj):
	if not is_instance_valid(obj):return
	var now=Time.get_ticks_msec()/1000.0
	if now-auto_attack_last<.62:return
	auto_attack_last=now
	if obj in crystals:obj.damage(GameState.attack)
	elif obj in enemies:obj.damage(GameState.attack)
	set_target(obj)

func spawn_click_marker(pos):
	var marker=MeshInstance3D.new();var cyl=CylinderMesh.new();cyl.top_radius=.35;cyl.bottom_radius=.35;cyl.height=.03
	marker.mesh=cyl;marker.material_override=mat(Color(0.3,0.8,1.0,.75));marker.position=pos+Vector3(0,.05,0);add_child(marker)
	var tw=create_tween();tw.tween_property(marker,"scale",Vector3(1.8,.2,1.8),.35);tw.tween_callback(marker.queue_free)

func _process(delta):
	if selected_target!=null and not is_instance_valid(selected_target):
		selected_target=null
		if target_label:target_label.text=""

func toggle_skill_tree():advanced_ui.toggle_skill_tree()
func toggle_market():advanced_ui.toggle_market()

func toggle_guild():community_ui.toggle("guild")
func toggle_party():community_ui.toggle("party")
func toggle_crafting():community_ui.toggle("craft")
func toggle_mail():community_ui.toggle("mail")
func toggle_events():community_ui.toggle("events")
func quick_fish():notify("Fishing: "+CraftingSystem.fish());refresh()
func quick_gather():notify("Gathered: "+CraftingSystem.gather());refresh()

func _network_message(m):
	var t=m.get("type","")
	if t=="enter_result" and m.get("ok",false):
		var c=m.character
		GameState.player_name=c.name;GameState.class_name=c.class_name;GameState.level=int(c.level);GameState.xp=int(c.xp);GameState.gold=int(c.gold)
		player.global_position=Vector3(float(c.x),float(c.y),float(c.z));visual_equipment.setup(GameState.class_name);refresh()
	elif t=="player_join":
		remote_players.spawn_player(int(m.id),str(m.name),str(m.class_name),Vector3(float(m.x),float(m.y),float(m.z)))
	elif t=="player_move":remote_players.move_player(int(m.id),Vector3(float(m.x),float(m.y),float(m.z)))
	elif t=="player_leave":remote_players.remove_player(int(m.id))
	elif t=="whisper":notify("[Whisper] "+str(m.get("from",""))+": "+str(m.get("message","")))
	elif t=="chat":notify(str(m.get("from",""))+": "+str(m.get("message","")))
	elif t=="portal_result" and m.get("ok",false):
		apply_local_map_v27(str(m.get("map_name",m.get("destination","Green Valley"))))

func _physics_process(delta):
	if NetworkClient.connected:
		net_move_timer+=delta
		if net_move_timer>=.10:
			net_move_timer=0.0;NetworkClient.send_move(player.global_position)

func apply_local_map_v27(map_name: String):
	current_map_v27=map_name
	if world_identity_v27:world_identity_v27.apply_map(map_name)
	if portal_visual_v27:portal_visual_v27.rebuild(map_name)
	if npc_world_v28:npc_world_v28.rebuild(map_name)
	player.global_position=Vector3(0,1,9)
	notify("Entered: "+map_name)


func accept_local_npc_quest_v28(npc_name):
	quest={"name":"%s Assignment"%npc_name,"kind":"kill","need":5,"progress":0,"reward_gold":180+GameState.level*15}
	notify("Quest accepted: "+str(quest.name))
	refresh()
