extends Node3D
var pet
func show_pet(id):
	if is_instance_valid(pet):pet.queue_free()
	pet=MeshInstance3D.new();var s=SphereMesh.new();s.radius=.32;s.height=.64;pet.mesh=s
	var m=StandardMaterial3D.new();m.albedo_color=Color("#e78a45") if "fox" in id else Color("#8d78c9");pet.material_override=m
	pet.position=Vector3(-1.0,.45,.7);add_child(pet)
func hide_pet():
	if is_instance_valid(pet):pet.queue_free()
