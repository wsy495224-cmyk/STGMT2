extends Node
var merchants=[]
var trade_sessions={}
func _ready():
	var f=FileAccess.open("res://data/merchants_v12.json",FileAccess.READ);merchants=JSON.parse_string(f.get_as_text())
func merchant(name):
	for m in merchants:
		if m.name==name:return m
	return {}
func buy(merchant_name,item,count=1):
	var m=merchant(merchant_name)
	if m.is_empty() or not m.stock.has(item):return false
	var total=int(m.stock[item])*count
	if not GameState.spend_gold(total):return false
	GameState.add_item(item,count);return true
func sell(item,count=1,unit_price=10):
	if GameState.inventory.get(item,0)<count:return false
	GameState.inventory[item]-=count;GameState.gold+=unit_price*count;return true
# Offline-safe model for a future server-authoritative player trade.
func offer(player_id,item,count):
	if GameState.inventory.get(item,0)<count:return false
	trade_sessions[player_id]={"item":item,"count":count,"accepted":false};return true
func cancel(player_id):trade_sessions.erase(player_id)
