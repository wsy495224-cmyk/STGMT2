extends Node3D

var body: MeshInstance3D
var weapon_root: Node3D
var class_name := "Blade"

func _mat(c: Color, metallic := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.55
	m.metallic = metallic
	return m

func _mesh(mesh: PrimitiveMesh, pos: Vector3, c: Color, metallic := 0.0) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.position = pos
	n.material_override = _mat(c, metallic)
	add_child(n)
	return n

func setup(kind: String) -> void:
	class_name = kind
	for child in get_children():
		child.queue_free()
	var torso := CapsuleMesh.new()
	torso.radius = 0.48
	torso.height = 1.45
	body = _mesh(torso, Vector3(0, 0.05, 0), _class_color())
	var head := SphereMesh.new()
	head.radius = 0.34
	head.height = 0.68
	_mesh(head, Vector3(0, 1.05, 0), Color("#d8aa83"))
	var shoulder := BoxMesh.new()
	shoulder.size = Vector3(1.2, 0.18, 0.38)
	_mesh(shoulder, Vector3(0, 0.55, 0), Color("#343b45"), 0.55)
	weapon_root = Node3D.new()
	weapon_root.position = Vector3(0.62, 0.35, 0)
	add_child(weapon_root)
	_build_weapon()

func _class_color() -> Color:
	if class_name == "Archer": return Color("#315f43")
	if class_name == "Mystic": return Color("#594078")
	return Color("#334f75")

func _build_weapon() -> void:
	if class_name == "Blade":
		var blade := MeshInstance3D.new(); var box := BoxMesh.new(); box.size = Vector3(0.12, 0.12, 1.65); blade.mesh = box; blade.rotation_degrees.x = 18; blade.material_override = _mat(Color("#c7d1d7"), 0.8); weapon_root.add_child(blade)
	elif class_name == "Archer":
		var bow := MeshInstance3D.new(); var torus := TorusMesh.new(); torus.inner_radius = 0.48; torus.outer_radius = 0.55; bow.mesh = torus; bow.scale = Vector3(0.55, 1.0, 1.0); bow.rotation_degrees.y = 90; bow.material_override = _mat(Color("#7a5430")); weapon_root.add_child(bow)
	else:
		var staff := MeshInstance3D.new(); var cyl := CylinderMesh.new(); cyl.top_radius = 0.06; cyl.bottom_radius = 0.06; cyl.height = 1.9; staff.mesh = cyl; staff.position.y = 0.25; staff.material_override = _mat(Color("#58412e")); weapon_root.add_child(staff)
		var orb := MeshInstance3D.new(); var sphere := SphereMesh.new(); sphere.radius = 0.18; sphere.height = 0.36; orb.mesh = sphere; orb.position.y = 1.2; orb.material_override = _mat(Color("#79b7ff"), 0.15); weapon_root.add_child(orb)

func animate_move(moving: bool, delta: float) -> void:
	if body == null: return
	var target := 1.0 + (0.035 if moving else 0.0)
	body.scale.y = lerp(body.scale.y, target, delta * 10.0)
	if weapon_root:
		weapon_root.rotation.z = sin(Time.get_ticks_msec() * 0.008) * (0.12 if moving else 0.025)
