extends Node
var friends=[]
var blocked=[]
var whispers=[]
var pending=[]
func add_friend(name):
	if name==GameState.player_name or name in friends:return false
	if not name in pending:pending.append(name)
	return true
func accept_friend(name):
	if name in pending:
		pending.erase(name)
		if not name in friends:friends.append(name)
		return true
	return false
func remove_friend(name):
	friends.erase(name)
func block(name):
	friends.erase(name)
	if not name in blocked:blocked.append(name)
func whisper(to,message):
	if to in blocked or message.strip_edges()=="":return false
	whispers.append({"from":GameState.player_name,"to":to,"message":message,"time":Time.get_unix_time_from_system()})
	return true
