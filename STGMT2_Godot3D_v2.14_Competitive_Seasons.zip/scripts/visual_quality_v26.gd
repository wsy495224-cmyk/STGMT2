extends Node3D

func material(color: Color, metallic := 0.0, roughness := 0.65) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = roughness
	return m

func add_box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	node.material_override = material(color)
	parent.add_child(node)
	return node

func build_village(parent: Node3D) -> void:
	# Original procedural medieval-fantasy silhouettes. No third-party art.
	for p in [Vector3(-15, 0, -6), Vector3(-15, 0, 9), Vector3(15, 0, -6), Vector3(15, 0, 9)]:
		add_box(parent, p + Vector3(0, 1.5, 0), Vector3(7, 3, 5.5), Color("#6f5745"))
		add_box(parent, p + Vector3(0, 3.45, 0), Vector3(7.8, 0.45, 6.3), Color("#4a3430"))
		add_box(parent, p + Vector3(0, 1.3, 2.8), Vector3(1.4, 2.3, 0.25), Color("#3b2b24"))
	for x in [-24, -12, 0, 12, 24]:
		add_box(parent, Vector3(x, 0.5, -23), Vector3(0.45, 1.0, 0.45), Color("#544238"))
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(x, 2.1, -23)
		lamp.light_color = Color("#ffd18a")
		lamp.omni_range = 8.0
		lamp.light_energy = 1.3
		parent.add_child(lamp)

func build_ruins(parent: Node3D) -> void:
	for i in range(10):
		var a := TAU * float(i) / 10.0
		var r := 34.0
		add_box(parent, Vector3(cos(a) * r, 1.4, sin(a) * r), Vector3(1.5, 2.8 + (i % 3), 1.5), Color("#62676a"))
