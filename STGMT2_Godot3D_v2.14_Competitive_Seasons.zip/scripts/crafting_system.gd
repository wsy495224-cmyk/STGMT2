extends Node
var recipes=[]
var fishing_level=1
var alchemy_level=1
func _ready():
	var f=FileAccess.open("res://data/recipes_v17.json",FileAccess.READ);recipes=JSON.parse_string(f.get_as_text())
func craft(id):
	var r={}
	for x in recipes:
		if x.id==id:r=x;break
	if r.is_empty():return false
	for item in r.ingredients:
		if GameState.inventory.get(item,0)<int(r.ingredients[item]):return false
	for item in r.ingredients:GameState.inventory[item]-=int(r.ingredients[item])
	for item in r.result:GameState.add_item(item,int(r.result[item]))
	return true
func fish():
	var roll=randf()
	var item="Old Boot" if roll<.1 else ("Golden Fish" if roll>.94 else "Fish")
	GameState.add_item(item,1);return item
func gather():
	var item="Crystal Herb" if randf()>.88 else "Herb";GameState.add_item(item,1);return item
