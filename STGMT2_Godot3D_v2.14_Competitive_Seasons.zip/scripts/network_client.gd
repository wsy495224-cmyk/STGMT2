extends Node
signal connected_to_server
signal disconnected_from_server
signal message_received(message)
var peer=StreamPeerTCP.new()
var connected=false
var buffer=""
var host="127.0.0.1"
var port=8182
var account_ok=false
var characters=[]
func connect_server(h="127.0.0.1",p=8182):
	host=h;port=p
	var err=peer.connect_to_host(host,port)
	return err==OK
func _process(delta):
	peer.poll()
	var st=peer.get_status()
	if st==StreamPeerTCP.STATUS_CONNECTED and not connected:
		connected=true;connected_to_server.emit()
	elif connected and st!=StreamPeerTCP.STATUS_CONNECTED:
		connected=false;disconnected_from_server.emit()
	if connected and peer.get_available_bytes()>0:
		buffer+=peer.get_utf8_string(peer.get_available_bytes())
		while "\n" in buffer:
			var idx=buffer.find("\n");var line=buffer.substr(0,idx);buffer=buffer.substr(idx+1)
			var m=JSON.parse_string(line)
			if typeof(m)==TYPE_DICTIONARY:_handle(m);message_received.emit(m)
func send(m):
	if not connected:return false
	peer.put_data((JSON.stringify(m)+"\n").to_utf8_buffer());return true
func register_user(u,p):return send({"type":"register","username":u,"password":p})
func resume_session(token):return send({"type":"resume","token":token})
func login(u,p):return send({"type":"login","username":u,"password":p})
func create_character(n,c):return send({"type":"create_character","name":n,"class_name":c})
func enter_world(id):return send({"type":"enter_world","character_id":id})
func send_move(pos):return send({"type":"move","x":pos.x,"y":pos.y,"z":pos.z})
func whisper(to,msg):return send({"type":"whisper","to":to,"message":msg})
func chat(msg):return send({"type":"chat","message":msg})
func request_world():return send({"type":"world_snapshot"})
func skill_server(mob_id,index):return send({"type":"skill","mob_id":mob_id,"index":index})
func equip_server(item,upgrade=0):return send({"type":"equip","item":item,"upgrade":upgrade})
func pvp_attack_server(target_id):return send({"type":"pvp_attack","target_id":target_id})
func guild_invite_server(target):return send({"type":"guild_invite","target":target})
func guild_rank_server(target,rank):return send({"type":"guild_rank","target":target,"rank":rank})
func guild_withdraw_server(item,count,upgrade=0):return send({"type":"guild_withdraw_item","item":item,"count":count,"upgrade":upgrade})
func guild_war_start_server(enemy):return send({"type":"guild_war_start","enemy_guild":enemy})
func craft_server(recipe_id):return send({"type":"craft","recipe_id":recipe_id})
func quests_server():return send({"type":"quests"})
func quest_claim_server(id):return send({"type":"quest_claim","quest_id":id})
func trade_open_server(target):return send({"type":"trade_open","target":target})
func trade_offer_server(id,gold,items):return send({"type":"trade_offer","trade_id":id,"gold":gold,"items":items})
func trade_accept_server(id):return send({"type":"trade_accept","trade_id":id})
func guild_create_server(name):return send({"type":"guild_create","name":name})
func guild_deposit_gold_server(gold):return send({"type":"guild_deposit_gold","gold":gold})
func guild_deposit_item_server(item,count,upgrade=0):return send({"type":"guild_deposit_item","item":item,"count":count,"upgrade":upgrade})
func guild_info_server():return send({"type":"guild_info"})
func attack_server(mob_id):return send({"type":"attack","mob_id":mob_id})
func refine_server(item,upgrade):return send({"type":"refine","item":item,"upgrade":upgrade})
func market_list_server(item,count,upgrade,price):return send({"type":"market_list","item":item,"count":count,"upgrade":upgrade,"unit_price":price})
func market_browse(term=""):return send({"type":"market_browse","term":term})
func market_buy_server(id,count=1):return send({"type":"market_buy","listing_id":id,"count":count})
func mail_send_server(to,subject,body,item="",count=0,upgrade=0,gold=0):return send({"type":"mail_send","to":to,"subject":subject,"body":body,"item":item,"count":count,"upgrade":upgrade,"gold":gold})
func mail_list_server():return send({"type":"mail_list"})
func mail_claim_server(id):return send({"type":"mail_claim","mail_id":id})
func _handle(m):
	if m.get("type")=="login_result":
		account_ok=m.get("ok",false);characters=m.get("characters",[])
	elif m.get("type")=="create_character_result":characters=m.get("characters",[])

# v2.4 server-authoritative world services
func portal_list_server():
    _send({"type":"portal_list"})

func portal_travel_server(destination: String):
    _send({"type":"portal_travel", "destination":destination})

func leaderboard_server(limit: int = 20):
    _send({"type":"leaderboard", "limit":limit})

func dungeon_create_server(member_ids: Array = []):
    _send({"type":"dungeon_create", "member_ids":member_ids})

func dungeon_progress_server(dungeon_id: int):
    _send({"type":"dungeon_progress", "dungeon_id":dungeon_id})
