extends Node
var mounts=[]
var owned=["horse_brown"]
var active=""
var mount_level={"horse_brown":1}
var mount_xp={"horse_brown":0}
func _ready():
	var f=FileAccess.open("res://data/mounts_v12.json",FileAccess.READ);mounts=JSON.parse_string(f.get_as_text())
func info(id):
	for m in mounts:
		if m.id==id:return m
	return {}
func summon(id):
	if not id in owned:return 1.0
	var m=info(id)
	if m.is_empty() or GameState.level<int(m.level):return 1.0
	active=id;return float(m.speed)+(mount_level.get(id,1)-1)*.01
func dismiss():active="";return 1.0
func unlock(id):
	if not id in owned:owned.append(id);mount_level[id]=1;mount_xp[id]=0
func train(n=10):
	if active=="":return
	mount_xp[active]=mount_xp.get(active,0)+n
	var lv=mount_level.get(active,1)
	if mount_xp[active]>=lv*100:
		mount_xp[active]-=lv*100;mount_level[active]=min(20,lv+1)
