extends Node
var quests=[]
var active={}
var completed=[]
func _ready():
	var f=FileAccess.open("res://data/quests_v12.json",FileAccess.READ);quests=JSON.parse_string(f.get_as_text())
func available():
	var out=[]
	for q in quests:
		if int(q.level)<=GameState.level and not q.id in completed and not active.has(q.id):out.append(q)
	return out
func accept(id):
	var q=next_quest(id)
	if q.is_empty():return false
	active[id]={"quest":q,"progress":0};return true
func next_quest(id):
	for q in quests:
		if q.id==id:return q
	return {}
func progress(kind,target="",n=1):
	for id in active.keys():
		var a=active[id];var q=a.quest
		if q.type==kind and (q.target==target or q.target=="any" or kind in ["upgrade","arena","dungeon","tournament"]):
			a.progress=min(int(q.amount),int(a.progress)+n);active[id]=a
func claim(id):
	if not active.has(id):return false
	var a=active[id];var q=a.quest
	if int(a.progress)<int(q.amount):return false
	GameState.gold+=int(q.rewards.get("gold",0));GameState.gain_xp(int(q.rewards.get("xp",0)))
	for item in q.rewards.get("items",{}):GameState.add_item(item,int(q.rewards.items[item]))
	active.erase(id);completed.append(id);return true
