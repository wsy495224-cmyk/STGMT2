extends Node
var game
var player
var camera
var target=null
var destination=Vector3.ZERO
var moving=false
var rotating=false
var last_mouse=Vector2.ZERO
var zoom=11.0
var pitch=-25.0
var yaw=180.0
var auto_attack=true

func setup(g,p,cam):
	game=g;player=p;camera=cam
	destination=player.global_position

func input(event):
	if event is InputEventMouseButton:
		if event.button_index==MOUSE_BUTTON_LEFT and event.pressed:
			_left_click(event.position)
		elif event.button_index==MOUSE_BUTTON_RIGHT:
			rotating=event.pressed;last_mouse=event.position
		elif event.button_index==MOUSE_BUTTON_WHEEL_UP and event.pressed:
			zoom=clamp(zoom-1.0,5.0,17.0);_camera()
		elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			zoom=clamp(zoom+1.0,5.0,17.0);_camera()
	elif event is InputEventMouseMotion and rotating:
		var d=event.position-last_mouse;last_mouse=event.position
		yaw-=d.x*.25;pitch=clamp(pitch-d.y*.18,-55.0,-12.0);_camera()

func _ray(screen_pos):
	var origin=camera.project_ray_origin(screen_pos)
	var end=origin+camera.project_ray_normal(screen_pos)*1000.0
	var q=PhysicsRayQueryParameters3D.create(origin,end)
	q.collide_with_areas=true;q.collide_with_bodies=true
	return player.get_world_3d().direct_space_state.intersect_ray(q)

func _left_click(pos):
	var hit=_ray(pos)
	if hit.is_empty():return
	var obj=hit.collider
	if obj and (obj in game.enemies or obj in game.crystals):
		set_target(obj);moving=false
	elif obj and obj.has_meta("item"):
		destination=obj.global_position;moving=true
	else:
		clear_target()
		destination=hit.position;destination.y=player.global_position.y;moving=true
		game.spawn_click_marker(hit.position)

func set_target(obj):
	target=obj;game.set_target(obj)

func clear_target():
	target=null;game.set_target(null)

func physics(delta):
	if not is_instance_valid(player):return
	if is_instance_valid(target):
		var dist=player.global_position.distance_to(target.global_position)
		var attack_range=3.5
		if dist>attack_range:
			var d=target.global_position-player.global_position;d.y=0
			player.classic_move(d.normalized(),delta)
		else:
			player.classic_stop()
			if auto_attack:game.try_auto_attack(target)
	elif moving:
		var d=destination-player.global_position;d.y=0
		if d.length()>.35:player.classic_move(d.normalized(),delta)
		else:moving=false;player.classic_stop()
	else:player.classic_stop()

func _camera():
	if not camera:return
	var r=deg_to_rad(yaw);var p=deg_to_rad(pitch)
	camera.position=Vector3(sin(r)*cos(p)*zoom,-sin(p)*zoom,cos(r)*cos(p)*zoom)
	camera.look_at(Vector3.ZERO,Vector3.UP)
