extends Node
var inbox=[]
var sent=[]
func send(to,subject,body,item="",gold=0):
	if to.strip_edges()=="" or body.length()>500:return false
	if gold>0 and not GameState.spend_gold(gold):return false
	if item!="" and GameState.inventory.get(item,0)<1:return false
	if item!="":GameState.inventory[item]-=1
	sent.append({"to":to,"subject":subject,"body":body,"item":item,"gold":gold,"time":Time.get_unix_time_from_system()})
	return true
func receive(sender,subject,body,item="",gold=0):
	inbox.append({"from":sender,"subject":subject,"body":body,"item":item,"gold":gold,"claimed":false})
func claim(index):
	if index<0 or index>=inbox.size() or inbox[index].claimed:return false
	var m=inbox[index]
	if m.item!="":GameState.add_item(m.item,1)
	GameState.gold+=int(m.gold);inbox[index].claimed=true;return true
