extends Node
var pets=[]
var owned=["fox_ember"]
var active=""
var levels={"fox_ember":1}
var xp={"fox_ember":0}
func _ready():
	var f=FileAccess.open("res://data/pets_v17.json",FileAccess.READ);pets=JSON.parse_string(f.get_as_text())
func info(id):
	for p in pets:
		if p.id==id:return p
	return {}
func summon(id):
	if not id in owned:return false
	active=id;return true
func dismiss():active=""
func gain_xp(n):
	if active=="":return
	xp[active]=xp.get(active,0)+n;var lv=levels.get(active,1)
	if xp[active]>=lv*80 and lv<20:xp[active]-=lv*80;levels[active]=lv+1
func unlock(id):
	if not id in owned:owned.append(id);levels[id]=1;xp[id]=0
func bonus():return info(active).get("bonus",{}) if active!="" else {}
