extends CanvasLayer
var panel
var text
var open=false
func _ready():
	panel=ColorRect.new();panel.position=Vector2(760,80);panel.size=Vector2(490,500);panel.color=Color(0.04,0.05,0.07,.92);panel.visible=false;add_child(panel)
	text=RichTextLabel.new();text.position=Vector2(20,20);text.size=Vector2(450,455);text.bbcode_enabled=true;panel.add_child(text)
func toggle_inventory():
	open=!open;panel.visible=open
	if open:
		var s="[font_size=26]Inventory / Equipment[/font_size]\n\n"
		s+="Class: %s  Level: %d\nWeapon: %s +%d\n\n[b]Items[/b]\n"%[GameState.class_name,GameState.level,GameState.equipment.weapon,GameState.upgrade_levels.get(GameState.equipment.weapon,0)]
		for k in GameState.inventory:s+="• %s x%s\n"%[k,GameState.inventory[k]]
		s+="\nTitles: "+", ".join(GameState.titles)+"\nAchievements: "+", ".join(GameState.achievements)
		text.text=s
func show_skills(skill_node):
	panel.visible=true;open=true
	var s="[font_size=26]%s Skills[/font_size]\n\n"%GameState.class_name
	for i in range(6):
		var sk=skill_node.skill(GameState.class_name,i)
		s+="%d. %s  DMG x%.2f  MP %d  CD %.1fs\n"%[i+1,sk.name,sk.damage,sk.mana,sk.cooldown]
	text.text=s
