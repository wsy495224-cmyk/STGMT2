extends Node
var listings=[]
var next_id=1
var tax_rate=.03
func list_item(seller,item,count,unit_price):
	if count<1 or unit_price<1 or GameState.inventory.get(item,0)<count:return false
	GameState.inventory[item]-=count
	listings.append({"id":next_id,"seller":seller,"item":item,"count":count,"unit_price":unit_price,"created":Time.get_unix_time_from_system()})
	next_id+=1;return true
func buy(id,count=1):
	for l in listings:
		if int(l.id)==id:
			var qty=min(count,int(l.count));var cost=qty*int(l.unit_price)
			if not GameState.spend_gold(cost):return false
			GameState.add_item(l.item,qty);l.count-=qty
			if l.count<=0:listings.erase(l)
			return true
	return false
func cancel(id):
	for l in listings:
		if int(l.id)==id and l.seller==GameState.player_name:
			GameState.add_item(l.item,int(l.count));listings.erase(l);return true
	return false
func search(term):
	var out=[]
	for l in listings:
		if term.to_lower() in str(l.item).to_lower():out.append(l)
	return out
