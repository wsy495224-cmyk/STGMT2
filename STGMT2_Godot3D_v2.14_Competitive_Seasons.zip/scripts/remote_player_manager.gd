extends Node3D
var remotes={}
func spawn_player(id,name,class_name,pos):
	if remotes.has(id):return
	var root=Node3D.new();root.name="Remote_"+str(id);root.position=pos;add_child(root)
	var mesh=MeshInstance3D.new();var cap=CapsuleMesh.new();cap.radius=.48;cap.height=1.8;mesh.mesh=cap
	var mat=StandardMaterial3D.new();mat.albedo_color=Color("#568ac7") if class_name=="Blade" else (Color("#5ea86a") if class_name=="Archer" else Color("#906bc0"));mesh.material_override=mat;root.add_child(mesh)
	var label=Label3D.new();label.text=name;label.position=Vector3(0,1.5,0);label.billboard=BaseMaterial3D.BILLBOARD_ENABLED;root.add_child(label)
	remotes[id]=root
func move_player(id,pos):
	if not remotes.has(id):return
	var r=remotes[id];var tw=create_tween();tw.tween_property(r,"position",pos,.08)
func remove_player(id):
	if remotes.has(id):remotes[id].queue_free();remotes.erase(id)
