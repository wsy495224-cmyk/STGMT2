extends CharacterBody3D
var game
var hp=95
var boss=false
var speed=2.1
var last_hit=0.0
var hpbar
func _ready():
	hpbar=load("res://scripts/world_healthbar.gd").new();hpbar.position=Vector3(0,2.1 if not boss else 3.0,0);add_child(hpbar);hpbar.setup(hp)

func _physics_process(delta):
	if not game or not is_instance_valid(game.player):return
	var d=global_position.distance_to(game.player.global_position)
	if d<10 and d>1.7:
		var dir=(game.player.global_position-global_position);dir.y=0;velocity=dir.normalized()*speed;move_and_slide()
	elif d<=1.8:
		velocity=Vector3.ZERO
		var now=Time.get_ticks_msec()/1000.
		if now-last_hit>1.1:last_hit=now;GameState.hp=max(0,GameState.hp-(18 if boss else 7));game.refresh()
	else:velocity=Vector3.ZERO
func damage(n):
	var crit=randf()<.12
	var dealt=int(n*(1.65 if crit else 1.0));hp-=dealt
	if hpbar:hpbar.update_hp(hp)
	var ft=load("res://scripts/floating_text.gd").new();get_parent().add_child(ft);ft.global_position=global_position+Vector3(0,2.2,0);ft.setup(dealt,crit)
	CombatVFX.hit_flash(get_parent(),global_position,Color("#ffd45f") if crit else Color("#ffffff"))
	AudioEvents.play_event("critical_hit" if crit else "hit",global_position)
	if hp<=0:game.enemy_defeated(self,boss);queue_free()
