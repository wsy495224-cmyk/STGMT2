extends Control
var game
var size := 190.0
func _ready():
    custom_minimum_size=Vector2(size,size)
    mouse_filter=Control.MOUSE_FILTER_IGNORE
    queue_redraw()
func _process(_delta): queue_redraw()
func _draw():
    var center=Vector2(size/2,size/2)
    draw_circle(center,size/2,Color(0.025,0.035,0.045,.88))
    draw_arc(center,size/2-3,0,TAU,64,Color(0.55,0.72,0.82,.8),3)
    if not game or not is_instance_valid(game.player): return
    var world_scale=size/105.0
    draw_circle(center,5.5,Color("#55b7ff"))
    for e in game.enemies:
        if is_instance_valid(e):
            var rel=Vector2(e.global_position.x-game.player.global_position.x,e.global_position.z-game.player.global_position.z)*world_scale
            if rel.length()<size/2-8: draw_circle(center+rel,3.2,Color("#e75a50"))
    for c in game.crystals:
        if is_instance_valid(c):
            var rel=Vector2(c.global_position.x-game.player.global_position.x,c.global_position.z-game.player.global_position.z)*world_scale
            if rel.length()<size/2-8: draw_circle(center+rel,3.5,Color("#bd68ff"))
    if game.portal_visual_v27:
        for p in game.portal_visual_v27.portals:
            if is_instance_valid(p):
                var rel=Vector2(p.global_position.x-game.player.global_position.x,p.global_position.z-game.player.global_position.z)*world_scale
                if rel.length()<size/2-8: draw_circle(center+rel,4.0,Color("#62c9ff"))
