extends Control
var game
var size=180.0
func _ready():
	custom_minimum_size=Vector2(size,size);queue_redraw()
func _process(delta):queue_redraw()
func _draw():
	draw_circle(Vector2(size/2,size/2),size/2,Color(0.03,0.04,0.05,.78))
	draw_circle(Vector2(size/2,size/2),size/2-3,Color(0.18,0.2,0.22,.35))
	if not game or not is_instance_valid(game.player):return
	var center=Vector2(size/2,size/2)
	var scale=size/90.0
	# player
	draw_circle(center+Vector2(game.player.global_position.x,game.player.global_position.z)*scale,5,Color("#55b7ff"))
	for e in game.enemies:
		if is_instance_valid(e):draw_circle(center+Vector2(e.global_position.x,e.global_position.z)*scale,3.5,Color("#e75a50"))
	for c in game.crystals:
		if is_instance_valid(c):draw_circle(center+Vector2(c.global_position.x,c.global_position.z)*scale,4,Color("#bd68ff"))
