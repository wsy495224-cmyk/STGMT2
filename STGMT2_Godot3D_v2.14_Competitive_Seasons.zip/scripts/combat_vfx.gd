extends Node
func hit_flash(parent,pos,color=Color("#fff1b8")):
	var m=MeshInstance3D.new();var s=SphereMesh.new();s.radius=.35;s.height=.7;m.mesh=s
	var mat=StandardMaterial3D.new();mat.albedo_color=color;mat.emission_enabled=true;mat.emission=color;mat.emission_energy_multiplier=2.0
	mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;m.material_override=mat;m.global_position=pos+Vector3(0,1,0);parent.add_child(m)
	var tw=parent.create_tween();tw.tween_property(m,"scale",Vector3(2,2,2),.18);tw.parallel().tween_property(mat,"albedo_color:a",0.0,.18);tw.tween_callback(m.queue_free)
func target_ring(parent,obj):
	var m=MeshInstance3D.new();var tor=TorusMesh.new();tor.inner_radius=.72;tor.outer_radius=.86;m.mesh=tor
	var mat=StandardMaterial3D.new();mat.albedo_color=Color("#e2c84f");mat.emission_enabled=true;mat.emission=Color("#d9b52d");m.material_override=mat
	m.position=Vector3(0,.08,0);obj.add_child(m);m.name="TargetRing";return m
