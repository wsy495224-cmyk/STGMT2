extends Node
var events=[]
var active={}
func _ready():
	var f=FileAccess.open("res://data/world_events_v17.json",FileAccess.READ);events=JSON.parse_string(f.get_as_text())
func start(id):
	for e in events:
		if e.id==id:
			active={"event":e,"progress":0,"started":Time.get_unix_time_from_system()};return true
	return false
func progress(n=1):
	if not active.is_empty():active.progress=int(active.progress)+n
func finish():
	if active.is_empty():return ""
	var reward=str(active.event.reward);GameState.add_item(reward,1);active={};return reward
