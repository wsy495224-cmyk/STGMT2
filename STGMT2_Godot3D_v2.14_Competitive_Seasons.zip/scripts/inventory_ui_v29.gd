extends CanvasLayer

var panel: Panel
var list: ItemList
var details: RichTextLabel
var equip_button: Button
var use_button: Button
var selected_name := ""

func _ready():
	panel = Panel.new()
	panel.position = Vector2(90, 90)
	panel.size = Vector2(760, 520)
	panel.visible = false
	add_child(panel)
	var title = Label.new()
	title.text = "Inventory & Equipment"
	title.position = Vector2(22, 18)
	title.add_theme_font_size_override("font_size", 25)
	panel.add_child(title)
	list = ItemList.new()
	list.position = Vector2(22, 65)
	list.size = Vector2(330, 380)
	list.item_selected.connect(_selected)
	panel.add_child(list)
	details = RichTextLabel.new()
	details.bbcode_enabled = true
	details.position = Vector2(380, 65)
	details.size = Vector2(350, 300)
	panel.add_child(details)
	equip_button = Button.new()
	equip_button.text = "Equip"
	equip_button.position = Vector2(380, 385)
	equip_button.size = Vector2(150, 45)
	equip_button.pressed.connect(_equip)
	panel.add_child(equip_button)
	use_button = Button.new()
	use_button.text = "Use"
	use_button.position = Vector2(550, 385)
	use_button.size = Vector2(150, 45)
	use_button.pressed.connect(_use)
	panel.add_child(use_button)
	var hint = Label.new()
	hint.text = "I: close   •   Equipment is class/level restricted"
	hint.position = Vector2(22, 470)
	panel.add_child(hint)

func toggle():
	panel.visible = not panel.visible
	if panel.visible: refresh()

func refresh():
	list.clear()
	for slot in GameState.equipment:
		var n = str(GameState.equipment[slot])
		if n != "": list.add_item("[E] %s: %s +%d" % [slot.capitalize(), n, int(GameState.upgrade_levels.get(n, 0))])
	for n in GameState.inventory:
		if int(GameState.inventory[n]) > 0: list.add_item("%s  x%d" % [n, int(GameState.inventory[n])])
	details.text = "[b]Gold[/b]: %d\n[b]ATK[/b] %d   [b]DEF[/b] %d\n[b]HP[/b] %d/%d   [b]MP[/b] %d/%d" % [GameState.gold, GameState.attack, GameState.defense, GameState.hp, GameState.max_hp, GameState.mp, GameState.max_mp]

func _selected(index: int):
	var raw = list.get_item_text(index)
	selected_name = raw.split("  x")[0]
	if selected_name.begins_with("[E]"):
		selected_name = selected_name.split(": ", false, 1)[1].split(" +")[0]
	var item = EquipmentManager.item_by_name(selected_name)
	if item.is_empty():
		details.text = "[font_size=22]%s[/font_size]\nConsumable / material\nOwned: %d" % [selected_name, int(GameState.inventory.get(selected_name, 0))]
	else:
		details.text = "[font_size=22]%s[/font_size]\nRarity: %s\nClass: %s   Slot: %s\nRequired level: %d\nATK +%d  DEF +%d\nHP +%d  MP +%d" % [item.get("name",""), item.get("rarity","Common"), item.get("class",""), item.get("slot",""), int(item.get("level",1)), int(item.get("attack",0)), int(item.get("defense",0)), int(item.get("hp",0)), int(item.get("mp",0))]

func _equip():
	if selected_name == "": return
	if int(GameState.inventory.get(selected_name, 0)) <= 0: return
	if EquipmentManager.equip(selected_name):
		GameState.inventory[selected_name] -= 1
		refresh()

func _use():
	if selected_name == "" or int(GameState.inventory.get(selected_name, 0)) <= 0: return
	if selected_name == "HP Potion": GameState.hp = min(GameState.max_hp, GameState.hp + 120)
	elif selected_name == "MP Potion": GameState.mp = min(GameState.max_mp, GameState.mp + 90)
	else: return
	GameState.inventory[selected_name] -= 1
	refresh()
