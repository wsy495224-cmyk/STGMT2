extends Node
var skill_levels={}
var skill_xp={}
func key(index):return GameState.class_name+":"+str(index)
func level(index):return skill_levels.get(key(index),1)
func add_xp(index,n):
	var k=key(index);skill_xp[k]=skill_xp.get(k,0)+n;var lv=skill_levels.get(k,1)
	while skill_xp[k]>=lv*100 and lv<20:
		skill_xp[k]-=lv*100;lv+=1
	skill_levels[k]=lv
func damage_bonus(index):return 1.0+(level(index)-1)*.025
func mana_discount(index):return min(.20,(level(index)-1)*.01)
