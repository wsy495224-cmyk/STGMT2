extends CanvasLayer
var game
var panel
var title
var body
var buttons
var npc_data={}
var shops={}
func setup(g):
 game=g
 panel=Panel.new(); panel.position=Vector2(390,150); panel.size=Vector2(500,390); panel.visible=false; add_child(panel)
 title=Label.new(); title.position=Vector2(24,20); title.add_theme_font_size_override("font_size",28); panel.add_child(title)
 body=Label.new(); body.position=Vector2(24,65); body.size=Vector2(450,90); body.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; panel.add_child(body)
 buttons=VBoxContainer.new(); buttons.position=Vector2(24,155); buttons.size=Vector2(450,190); panel.add_child(buttons)
 var close=Button.new(); close.text="Close"; close.position=Vector2(380,350); close.pressed.connect(close_ui); panel.add_child(close)
func close_ui():panel.visible=false
func open_npc(d,s):
 npc_data=d;shops=s;panel.visible=true
 title.text=str(d.name)+" — "+str(d.role)
 body.text=_dialogue(str(d.role),str(d.name))
 for c in buttons.get_children():c.queue_free()
 var role=str(d.role)
 if role in ["Merchant","Alchemist","Mounts","Skill Master"]:
  for item in shops.get(role,{}).keys(): _add_buy(item,int(shops[role][item]))
 if role=="Blacksmith":_add_action("Refine equipped weapon",func():game.open_blacksmith())
 if role=="Warehouse":_add_action("Open warehouse",func():game.notify("Warehouse ready — secure storage foundation"))
 if role=="Quest":_add_action("Accept local assignment",func():game.accept_local_npc_quest_v28(str(d.name)))
func _dialogue(role,name):
 match role:
  "Blacksmith":return "I can strengthen your equipped weapon. Higher upgrades cost more and become riskier."
  "Warehouse":return "Your valuables belong somewhere safer than the battlefield."
  "Quest":return "The region needs capable fighters. I have work for you."
  "Skill Master":return "Train with discipline. Skill books and mastery decide difficult battles."
  "Alchemist":return "Potions are cheaper than defeat. Choose what you need."
  "Mounts":return "A trained mount makes long journeys safer and faster."
  _:return "Welcome, traveler. Supplies are available for your journey."
func _add_buy(item,price):
 _add_action("Buy %s — %d gold"%[item,price],func():buy(item,price))
func _add_action(label,callable):
 var b=Button.new();b.text=label;b.pressed.connect(callable);buttons.add_child(b)
func buy(item,price):
 if GameState.spend_gold(price):GameState.add_item(item);game.notify("Bought: "+item)
 else:game.notify("Not enough gold")
 game.refresh()
