extends Node
# Event API is ready for original/CC0 audio assets.
var enabled=true
func play_event(name,position=Vector3.ZERO):
	if not enabled:return
	# Intentionally silent until verified CC0/original audio streams are imported.
	pass
