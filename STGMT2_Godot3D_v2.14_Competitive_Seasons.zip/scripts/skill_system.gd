extends Node
var data={}
var cooldowns={}
func _ready():
	var f=FileAccess.open("res://data/skills_v11.json",FileAccess.READ)
	data=JSON.parse_string(f.get_as_text())
func skill(class_name,index):
	if not data.has(class_name) or index<0 or index>=data[class_name].size():return {}
	return data[class_name][index]
func ready(class_name,index):
	var key=class_name+":"+str(index)
	return Time.get_ticks_msec()/1000.0>=cooldowns.get(key,0.0)
func cast(class_name,index):
	var s=skill(class_name,index)
	if s.is_empty() or not ready(class_name,index):return {}
	if GameState.mp<int(s.mana):return {}
	GameState.mp-=int(s.mana)
	var key=class_name+":"+str(index)
	cooldowns[key]=Time.get_ticks_msec()/1000.0+float(s.cooldown)
	return s
func left(class_name,index):
	var key=class_name+":"+str(index)
	return max(0.0,cooldowns.get(key,0.0)-Time.get_ticks_msec()/1000.0)
